<?php
require ('mysqli_connect.php');
ob_end_clean();
include ('include/Sheader.php');
//if (!isset($page_title)){
//    $page_title = 'Account Settings & Change Password';
//}

// For account settings
if (isset($_POST['updateAccount'])){
    $username = $_POST['username'];
    $email = $_POST['email'];
    $phoneno = $_POST['phoneno'];
    
    if (!preg_match("/^[a-zA-Z-' ]*$/", $username)) {
        echo '<div class="alert">
                     <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                     <strong>Only letters and white space allowed !!!</strong> Please enter again !
               </div>';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
         echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Invalid email format !!!</strong> Please enter a valid email address !
                </div>';
     }
     if(!preg_match("/^[0-9]{10}$/", $phoneno)) {
         echo '<div class="alert">
                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                   <strong>Error !!!</strong> Please enter again ! eg. phone
                </div>';
     }
     
     // make sure the email are match from database
    $query = "SELECT * FROM staff WHERE SUsername='$username'";
    $result = mysqli_query($dbc, $query) or trigger_error("\n\nQuery: $query\n<br />MySQL Error: ".mysqli_error($dbc));
    $row = mysqli_fetch_array($result);
    if ($username == $row['SUsername']){
        mysqli_query($dbc,"UPDATE staff SET SEmailAddress='" . $email . "', SPhoneno='" . $phoneno . 
            "' WHERE SUsername='" . $username . "'");
        echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                       margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Password Changed Sucessfully !!!</strong>
              </div>';
    }
    else{
        echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Invalid !!!</strong>
                  <br>Your username entered are not matched. Please enter again !
               </div>';
    }
} // end if of isset($_POST['updateAccount'])

// For Security Settings
//$id = $_SESSION["SEmailAddress"];/* userid of the user */ //error
if (isset($_POST['changePassword'])){
    // create variable
    $email = $_POST['email1'];
    $oldpass = $_POST['oldpass'];
    $pass = $_POST['pass'];
    $passc = $_POST['passc'];
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
         echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Invalid email format !!!</strong> Please enter a valid email address !
                </div>';
     }
    if (!preg_match ('/^\w{4,20}$/', $oldpass) || !preg_match ('/^\w{4,20}$/', $pass) || !preg_match ('/^\w{4,20}$/', $passc)) {
        echo '<div class="alert">
                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                   <strong>Error !!!</strong> Please enter your password again !
               </div>';
    }
    // make sure the email are match from database
    $query = "SELECT * FROM staff WHERE SEmailAddress='$email' AND SPassword='$oldpass'";
    $result = mysqli_query($dbc, $query) or trigger_error("\n\nQuery: $query\n<br />MySQL Error: ".mysqli_error($dbc));
    $row = mysqli_fetch_array($result);
    if($oldpass == $row["SPassword"] && $pass == $passc) {
        mysqli_query($dbc,"UPDATE staff SET SPassword='" . $pass . "' WHERE SEmailAddress='" . $email . "'");
        echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                       margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Password Changed Sucessfully !!!</strong>
              </div>';
    }
    else{
        echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Invalid !!!</strong>
                  <br>Either your current password is not correct or your entered new password and confirm password
                  are not matched. Please enter again !
               </div>';
    }
}// end if isset($_POST['changePassword'])
?>
<style>
    body{
        background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: white;
        font-weight: bolder;
    }
    table{
        margin: auto;
    }
    .form-group {
        padding-left: 30px;
    }
    /*for button clicking perform other screen  */
    .form-group2 {
        padding-left: 60px;
    }
    /* For textfield */
    .container {
      height: 100%;
      display: flex;
      justify-content: center;
      align-items: center;
      padding-top: 30px;
    }
    .material-textfield {
      position: relative;  
    }
    label {
      font-size: 1rem;
      color: white;
      padding: 0 0.3rem;
      margin: 0 0.5rem;
    }
    input {
      font-size: 1rem;
      outline: none;
      border: 1px solid gray;
      border-radius: 5px;  
      padding-top: 20px;
      padding-bottom: 10px;
      padding-left: 20px;
      padding-right: 20px;
      color: black;
      transition: 0.1s ease-out;
      width: 90%;
    }
    input:focus {
      border-color:rgb(0, 115, 230, 0.6);  
    }
    input:focus + label {
      color: rgb(0, 102, 204);
      top: 0;
      transform: translateY(-50%) scale(.9);
    }
    input:not(:placeholder-shown) + label {
      top: 0;
      transform: translateY(-50%) scale(.9);
    }
    /* For display the side page */
    td {
        vertical-align: top;
    }
    #table1, #table2 {
        display: none;
    }
    table {
        padding-left: 530px;
        padding-top: 50px;
    }
    /* button style */
    button {
        padding: 10px 20px;
        border-radius: 30px;
        background-color: #3399ff;
        color: white;
        display: inline-block;
        font-family: Comic Sans Ms;
        font-size: 16px;
    }
    button:hover, button:active {
      background-color: #994d00;
    }
    /* The alert message box */
    .alert {
        padding: 10px;
        background-color: #f25555; /* Red */
        color: white;
        margin-bottom: 15px;
        /*<!-- Alert message--> */
        opacity: 1;
        transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
        margin-left: 5px;
        color: white;
        font-weight: bold;
        float: right;
        font-size: 15px;
        line-height: 20px;
        cursor: pointer;
        transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
        color: black;
    }
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;
// Loop through all close buttons
for (i = 0; i < close.length; i++) {
    // When someone clicks on a close button
    close[i].onclick = function(){
        // Get the parent of <span class="closebtn"> (<div class="alert">)
        var div = this.parentElement;
        // Set the opacity of div to 0 (transparent)
        div.style.opacity = "0";
        // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
        setTimeout(function(){ div.style.display = "none"; }, 600);
    }
}
</script>
<script type="text/javascript">
    $(function(){
        $('#eye').click(function(){
            if($(this).hasClass('fa-eye-slash')){
                $(this).removeClass('fa-eye-slash');
                $(this).addClass('fa-eye');
                $('#password').attr('type','text');
            }else{
                $(this).removeClass('fa-eye');
                $(this).addClass('fa-eye-slash');  
                $('#password').attr('type','password');
            }
        });
    });
</script>
<script type="text/javascript">
    $(function(){
        $('#eye1').click(function(){
            if($(this).hasClass('fa-eye-slash')){
                $(this).removeClass('fa-eye-slash');
                $(this).addClass('fa-eye');
                $('#pass').attr('type','text');
            }else{
                $(this).removeClass('fa-eye');
                $(this).addClass('fa-eye-slash');  
                $('#pass').attr('type','password');
            }
        });
    });
</script>
<script type="text/javascript">
    $(function(){
        $('#eye2').click(function(){
            if($(this).hasClass('fa-eye-slash')){
                $(this).removeClass('fa-eye-slash');
                $(this).addClass('fa-eye');
                $('#passc').attr('type','text');
            }else{
                $(this).removeClass('fa-eye');
                $(this).addClass('fa-eye-slash');  
                $('#passc').attr('type','password');
            }
        });
    });
</script>
<!-- For textfield -->
<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<!-- For displaying the Update Profile and Change Password -->
<script type="text/javascript">
    function show(nr) {
        document.getElementById("table1").style.display="none";
        document.getElementById("table2").style.display="none";
        document.getElementById("table"+nr).style.display="block";
    }
</script>
<br><br><br>
<table>
    <tr>
        <td style="display: block;">
            <br><br><br>
            <h3>Profile</h3>
            <div class="form-group">
                <button onclick="show(1);">Update Profile</button>
            </div>
            <br><br>
            <h3>Security</h3>
            <div class="form-group">
                <button onclick="show(2);">Change Password</button>
            </div>
        </td>
        <td>&nbsp;</td>
        <td>
            <form action=" " method="POST">
                <div class="form-group2" id="table1">
                    <h3><b>Account Settings</b></h3>
                    <div class="form-group">
                        <b><label>Username : </label></b><br>
                        <input placeholder="Type Your Current Username" type="text" name="username" 
                                   style="width: 250px; border-radius: 10px; height: 40px;" class="form-control">
                    </div>
                    <div class="form-group">
                        <b><label>E-mail : </label></b><br>
                        <input placeholder="Type Your New Email" type="text" name="email" 
                               style="width: 250px; border-radius: 10px; height: 40px;" class="form-control">
                    </div>
                    <div class="form-group">
                        <b><label>Phone No. : </label></b><br>
                        <input placeholder="Type Your New Phone No" type="text" name="phoneno" 
                               style="width: 250px; border-radius: 10px; height: 40px;" class="form-control">
                    </div>
                    <div class="form-group">
                        <button type="submit" name="updateAccount">Update Account</button>
                    </div>
                </div>
            </form>
            <form action=" " method="POST">
                <div class="form-group2" id="table2">
                    <h3><b>Security Settings</b></h3><br>
                    <div class="form-group">
                        <b>
                            <label>Email Address : </label>
                        </b><br>
                        <input class="form-control" placeholder="Type Your Email" type="text" name="email1" 
                               style="border-radius: 10px; height: 40px; width: 300px;" required="">
<!--                        <input placeholder="  Type Your Email" type="text" name="email1" 
                               style="width: 300px; border-radius: 10px; height: 50px;" required="">-->
                    </div>
                    <div class="form-group">
                        <b>
                            <label for="pass" style="background-color: transparent;">
                                Current Password&nbsp; :&nbsp; 
                            </label>
                        </b>
                        <div class="input-group mb-2 mr-sm-2" style="width: 300px;">
                            <input type="password" class="form-control" id="password" placeholder="Type Your Password" 
                                   name="oldpass" style="border-radius: 10px;" required="">
                            <div class="input-group-prepend">
                                <div class="input-group-text" 
                                     style="background-color: #F7F7F7; border: none; border-radius: 50px;">
                                    <i class="fas fa-eye-slash" id="eye" style="color: #396EB0;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <b>
                            <label for="pass" style="background-color: transparent;">
                                    New Password&nbsp; :&nbsp; 
                            </label>
                        </b><br>
                        <div class="input-group mb-2 mr-sm-2" style="width: 300px;">
                            <input type="password" class="form-control" id="pass" 
                                   placeholder="Type Your New Password" 
                                   name="pass" style="border-radius: 10px;" required="">
                            <div class="input-group-prepend">
                                <div class="input-group-text" 
                                     style="background-color: #F7F7F7; border: none; border-radius: 50px;">
                                    <i class="fas fa-eye-slash" id="eye1" style="color: #396EB0;"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <b><label>Confirm New Password :</label></b>
                            <div class="input-group mb-2 mr-sm-2" style="width: 300px;">
                                <input type="password" class="form-control" id="passc"
                                       placeholder="Type Your New Password again" name="passc"
                                       style="border-radius: 10px;" required="">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"
                                         style="background-color: #F7F7F7; border: none; border-radius: 50px;">
                                        <i class="fas fa-eye-slash" id="eye2" style="color: #396EB0;"></i>
                                    </div>
                                </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <button type="submit" name="changePassword">Save Password</button>
                    </div>
                </div>
            </form>
        </td>
    </tr>
</table>
<br><br><br><br><br><br>
<?php
include ('include/footer.php');
?>