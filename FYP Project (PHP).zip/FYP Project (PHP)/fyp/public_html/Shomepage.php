<?php
$page_title = 'Staff Home Page';
include('include/Sheader.php');
require('mysqli_connect.php');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["message"])) {
    $message = htmlspecialchars($_POST["message"]);
    $role = htmlspecialchars($_POST["role"]);

    $query = "INSERT INTO chatmessages (message, role) VALUES (?, ?)";
    $stmt = mysqli_prepare($dbc, $query);
    mysqli_stmt_bind_param($stmt, "ss", $message, $role);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    echo "Message received: " . $message;
    exit();
}

$_SESSION["role"] = "staff";

// Fetch messages from the database
$messages = [];
$query = "SELECT message, role FROM chatmessages ORDER BY created_at ASC";
$result = mysqli_query($dbc, $query);
while ($row = mysqli_fetch_assoc($result)) {
    $messages[] = $row;
}
mysqli_free_result($result);
?>

<section class="contact bgimg pt-5">
    <div class="container">
        <div class="row py-3">
            <div class="col-lg-7 mx-auto"></div>
        </div>
    </div>
</section>

<div class="container">
    <div class="open-button" onclick="openForm()">
        <i class="bi bi-chat-fill" style="color: lightblue; font-size: 30px;"></i>
    </div>
    <div class="form-popup" id="myForm">
        <form method="POST" onsubmit="sendMessage(event)">
            <div class="container-fluid" style="padding-bottom: 0px;">
                <div class="row">
                    <div class="col-md-4" style="width: 100px; padding-right: 500px;">
                        <div class="modal-dialog" style="width: 1000px;">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4>ChatBox</h4>
                                    <div class="close-button" onclick="closeForm()">
                                        <i class="bi bi-x-square-fill" style="color: lightblue; font-size: 30px;"></i>
                                    </div>
                                </div>
                                <div class="modal-body" id="msgBody" style="height: 250px;">
                                    <div id="chatMessages" class="chat-messages">
                                        <?php 
                                         foreach ($messages as $msg) {
                                             $messageClass = $msg['role'] === 'staff' ? 'staff-message' : 'member-message';
                                             echo '<div class="' . $messageClass . '">' . htmlspecialchars($msg['message']) . '</div>';
                                         } 
                                         ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <textarea id="message" class="form-control" name="message" style="height: 70px; width: 500px;"></textarea>
                                    <input type="hidden" id="role" name="role" value="<?php echo $_SESSION['role']; ?>">
                                    <button type="submit" name="send" id="send" class="btn btn-primary" style="height: 70%;">Send</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    function openForm() {
        document.getElementById("myForm").style.display = "block";
//        refreshChat();
    }

    function closeForm() {
        document.getElementById("myForm").style.display = "none";
//        clearInterval(chatRefreshInterval);
    }

    function sendMessage(event) {
        event.preventDefault();

        const messageInput = document.getElementById("message");
        const roleInput = document.getElementById("role");
        const messageText = messageInput.value.trim();
        const userRole = roleInput.value;

        if (messageText === "") {
            return;
        }

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "Shomepage.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                messageInput.value = "";
                fetchMessages(); // Fetch new messages immediately after sending
            }
        };
        xhr.send("message=" + encodeURIComponent(messageText) + "&role=" + encodeURIComponent(userRole));
    }

//    let chatRefreshInterval;
//
//    function refreshChat() {
//        chatRefreshInterval = setInterval(fetchMessages, 5000);
//    }

    function fetchMessages() {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", "function/fetch_messages.php", true);
        xhr.onreadystatechange = function () {
             if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    const messages = JSON.parse(xhr.responseText);
                    const chatMessages = document.getElementById("chatMessages");
                    chatMessages.innerHTML = "";

                    if (messages.error) {
                        console.error(messages.error);
                        return;
                    }

                    messages.forEach(function(msg) {
                        const messageContainer = document.createElement("div");
                        messageContainer.className = msg.role === "staff" ? "staff-message" : "member-message";
                        messageContainer.innerText = msg.message;
                        chatMessages.appendChild(messageContainer);
//                        const br = document.createElement("br");
//                        chatMessages.appendChild(br);
                    });

                    chatMessages.scrollTop = chatMessages.scrollHeight;
                } catch (e) {
                    console.error("Failed to parse JSON response:", e);
                }
            }
        };
        xhr.send();
    }
    
    function reloadChat() {
        fetchMessages(); // Fetch new a messages and update the chat box
    }
    
     // Set the chat to reload every 5 seconds (5000 milliseconds)
     setInterval(reloadChat, 5000);
</script>

<!--<script>
    function openForm() {
        document.getElementById("myForm").style.display = "block";
        refreshChat();
    }

    function closeForm() {
        document.getElementById("myForm").style.display = "none";
        clearInterval(chatRefreshInterval);
    }

    function sendMessage(event) {
        event.preventDefault();

        const messageInput = document.getElementById("message");
        const roleInput = document.getElementById("role");
        const messageText = messageInput.value.trim();
        const userRole = roleInput.value;

        if (messageText === "") {
            return;
        }

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "Shomepage.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                messageInput.value = "";
                refreshChat(); // Refresh chat to display the new message
            }
        };
        xhr.send("message=" + encodeURIComponent(messageText) + "&role=" + encodeURIComponent(userRole));
    }

    let chatRefreshInterval;

    function refreshChat() {
        chatRefreshInterval = setInterval(function() {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_messages.php", true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const messages = JSON.parse(xhr.responseText);
                    const chatMessages = document.getElementById("chatMessages");
                    chatMessages.innerHTML = "";

                    messages.forEach(function(msg) {
                        const messageContainer = document.createElement("div");
                        messageContainer.className = msg.role === "staff" ? "staff-message" : "member-message";
                        messageContainer.innerText = msg.message;
                        chatMessages.appendChild(messageContainer);
                        chatMessages.appendChild(document.createElement("br"));
                    });

                    chatMessages.scrollTop = chatMessages.scrollHeight;
                }
            };
            xhr.send();
        }, 5000);
    }
</script>-->

<style>
    body, html {
        height: 100%;
        margin: 0;
        font-weight: bolder;
    }

    .bgimg {
        background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%; 
    }

    .contact {
        height: 100%;
        width: 100%;
        outline: none;
        border: none;
        color: gray;
        background-color: black;
        padding: 10px;
    }

    .open-button {
        position: fixed;
        right: 50px;
        bottom: 120px;
        font-size: 60px;
        color: white;
        cursor: pointer;
        z-index: 1000;
    }

    .form-popup {
        display: none;
        position: fixed;
        bottom: 190px;
        right: 50px;
        border: none;
        z-index: 9;
        margin-right: 60px;
        margin-bottom: -100px;
    }

    .form-container {
        width: 300px;
        padding: 10px;
        background-color: #f1f1f1;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    .form-container textarea {
        width: 100%;
        padding: 10px;
        margin: 5px 0 10px 0;
        border: 1px solid #ccc;
        background: #fff;
        resize: none;
        border-radius: 10px;
    }

    .form-container textarea:focus {
        background-color: #ddd;
        outline: none;
    }

    .form-container .btn {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
        margin-bottom: 10px;
        border-radius: 10px;
    }

    .form-container .btn.cancel {
        background-color: red;
        border-radius: 10px;
    }

    .chat-messages {
        height: 220px;
        overflow-y: scroll;
        overflow-x: hidden;
        padding: 5px;
        display: flex;
        flex-direction: column;
        background: #fff;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    .chat-messages .message-container {
        display: flex;
        margin-bottom: 10px;
    }

    .chat-messages .staff-message {
        background-color: pink;
        text-align: left;
        align-self: flex-end;
        padding: 10px;
        border-radius: 10px;
        max-width: 60%;
        margin-bottom: 10px;
    }

    .chat-messages .member-message {
        background-color: lightblue;
        text-align: left;
        align-self: flex-start;
        padding: 10px;
        border-radius: 10px;
        max-width: 60%;
        margin-bottom: 10px;
    }
</style>

<?php
mysqli_close($dbc);
?>

</body>
</html>
