<?php
require ('mysqli_connect.php');
ob_end_clean();
include ('include/header.php');
?>
<style>
    body{
        background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: lightskyblue;
        font-weight: bolder;
        font-family: Comic Sans Ms;
        backdrop-filter: blur(6px);
        text-align: center;
    }
    /* Float four columns side by side */
    .col {
        float: left;
        width: 30%;
        margin-left: 100px;
        margin-right: 60px;
        padding-top: 30px;
    }
    /* Remove extra left and right margins, due to padding in columns */
    .row {
        /* margin: 0 -5px;*/
        margin: 0 -5px;
        padding-top: 20px;
        padding-right: 50px;
    }
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    /* Style the counter cards */
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
      padding-left: 30px;
      padding-right: 30px;
      padding-top: 20px;
      padding-bottom: 10px;
      text-align: left;
      background-color: rgb(41, 82, 163, 0.8); /*rgb(?, ?, ?, opacity); */
      border-radius: 60px;
      width: 100%;
    }
    label, input, option {
        font-size: 16px;
    }
    /* Responsive layout - makes the menu and the content (inside the section) sit on top of each other instead of next to each other */
    @media (max-width: 600px) {
      section {
        -webkit-flex-direction: column;
        flex-direction: column;
      }
    }
    .page-footer {
       bottom:0;
       width:100%;
    }
/*    a button 
    a {
        padding: 10px 20px;
        border-radius: 30px;
    }
    a:link, a:visited {
      background-color: #3399ff;
      color: white;
      text-align: center;
      text-decoration: none;
      display: inline-block;
    }
    a:hover, a:active {
      background-color: #994d00;
    }*/
</style>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
<style>
    /* button style */
    button {
        padding: 10px 20px;
        border-radius: 30px;
        background-color: #3399ff;
        color: white;
        display: inline-block;
        font-family: Comic Sans Ms;
        font-size: 16px;
    }
    button:hover, button:active {
      background-color: #994d00;
    }
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<form method="POST" action="CheckOut.php" id="checkout">
    <div class="row">
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="card-title"><b style="font-size: 20px; text-align: center;">Booked List</b></div>
                    <div class="card-text">
                        <h3><b>For Booked Court</b></h3><p>Half Hour - RM10</p>
                        <?php
                        $subtotal1 = 0;
                        if (isset($_COOKIE['MID'])){
                            $MID = $_COOKIE['MID'];
                            
                            $booksql = "SELECT * FROM booking WHERE MID = '$MID' AND BookDate = CURDATE()";
                                $f = mysqli_prepare($dbc, $booksql);
                                mysqli_stmt_execute($f);
                                if (mysqli_stmt_num_rows($f) >= 0){
                                    $Bookre = mysqli_stmt_get_result($f);
                                    
                                    while($brow = mysqli_fetch_array($Bookre, MYSQLI_ASSOC)){
                                        $bid = $brow['BookID'];
                                        $bcourt = $brow['CourtID'];
                                        $bbookdate = $brow['BookDate'];
                                        $bbooktime = date('H:i a', strtotime($brow['BookStartTime'])) 
                                        . " - " . date('H:i a', strtotime($brow['BookEndTime']));
                                        $bduration = date('H', strtotime($brow['BookEndTime'])) 
                                        - date('H', strtotime($brow['BookStartTime']));
                                        $bduration2 = date('i', strtotime($brow['BookEndTime'])) 
                                        - date('i', strtotime($brow['BookStartTime']));
                                        $caltime = (($bduration * 60)/30)+$bduration2/30;
                                        $btotalprice = $caltime * 10;
                                       
                                            echo "<p>CourtID : " . $bcourt . "</p>";
                                            echo "<p>Date : " . $bbookdate . "</p>";
                                            echo "<p>Time : " . $bbooktime . "</p>";
                                            echo "<p>Durations : " . $bduration . "hour(s)" . " " . $bduration2 . "mintues</p>";
                                            echo "<p>30 minutes : " . $caltime . "</p>";
                                            echo "<p>Total Price : " . $btotalprice . "</p>";
                                            echo "<br>";
                                          $subtotal1 += $btotalprice; 
                                        echo '<input type="text" name="BookID" value="'.$bid.'" /hidden>';
                                    }
                                     
                                }
                             }
                             else {
                                 echo '<div class="alert" style="padding: 10px; color: white;
                                      margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                      <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                      <strong>Not Sign in !!!</strong> Please sign in first ! 
                                   </div>'; 
                            }   
                        ?>

                        <h3><b>For Service</b></h3>
                        <h4>Accessories</h4>
                        <?php
                        $subtotal = 0;
                        $todaydate = date('d-m-Y');
                        if (isset($_COOKIE['MID'])){
                                $MID = $_COOKIE['MID'];
                                $asubtotal = 0;
                                $ssubtotal = 0;
                                // --- Accessories Part -----
                                $sql = "SELECT * "
                                        . "FROM booking b, bookaccessories ba, accessories a "
                                        . "WHERE b.BookID = ba.BookID AND ba.AID = a.AID "
                                        . "AND b.BookStatus = 'Booked' AND ba.UserID = '$MID' AND BookDate = '$todaydate'";
                                $arun = mysqli_prepare($dbc, $sql);
                                mysqli_stmt_execute($arun);
                                if (mysqli_stmt_num_rows($arun) >= 0){
                                    $aresult = mysqli_stmt_get_result($arun);
                                    
                                    while($arow = mysqli_fetch_array($aresult, MYSQLI_ASSOC)){
                                        $bid1 = $arow['BookID'];
                                        $abookdate = $arow['BookDate'];
                                        $aname = $arow['AName'];
                                        $atotalqty = $arow['ATotalQty'];
                                        $atotalprice = $arow['ATotalPrice'];
                                        echo "<p>Date : " . $abookdate . "</p>";
                                        echo "<p>Name : " . $aname . "</p>";
                                        echo "<p>Total Quantity : " . $atotalqty . "</p>";
                                        echo "<p>Total Price : " . $atotalprice . "</p>";
                                        echo "<br>";
                                        $asubtotal += $atotalprice;
                                        echo '<input type="text" name="BookID" value="'.$bid1.'" /hidden>';
                                    }
                                } // end if for mysqli_stmt_num_rows($run) >= 1
                                else {
                                    echo '<div class="alert" style="background-color: #FFBC97; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>No booking !!!</strong> 
                                                 Dear, you havent booked any courses, services and competitions yet. <br>
                                                 You can go to book the court or service that your want.
                                          </div>'; 
                                }
                                // --- END Accessories Part -----
                                // --- Service Part -----
                                $sql2 = "SELECT * "
                                        . "FROM booking b, bookservice bs, service s "
                                        . "WHERE b.BookID = bs.BookID AND bs.ServiceID = s.ServiceID "
                                        . "AND b.BookStatus = 'Booked' AND bs.UserID = '$MID' AND BookDate = '$todaydate'";
                                $srun = mysqli_prepare($dbc, $sql2);
                                mysqli_stmt_execute($srun);
                                if (mysqli_stmt_num_rows($srun) >= 0){
                                    $sresult = mysqli_stmt_get_result($srun);
                                    while($srow = mysqli_fetch_array($sresult, MYSQLI_ASSOC)){
                                        $bid2 = $srow['BookID'];
                                        $sname = $srow['ServiceName'];
                                        $sbooktype = $srow['BookType'];
                                        $sbookdate = $srow['BookDate'];
                                        $sbooktime = date('H:i a', strtotime($srow['BookStartTime'])) 
                                        . " - " . date('H:i a', strtotime($srow['BookEndTime']));
                                        $duration = date('H', strtotime($srow['BookEndTime'])) 
                                        - date('H', strtotime($srow['BookStartTime']));
                                        $duration2 = date('i', strtotime($srow['BookEndTime'])) 
                                        - date('i', strtotime($srow['BookStartTime']));
                                        $stotalprice = $srow['ServicePrice'];
                                        if ($sbooktype == "Repair Grip"){
                                            echo "<p>Service Type : " . $sname . "</p>";
                                            echo "<p>Date : " . $sbookdate . "</p>";
                                            echo "<p>Time : " . $sbooktime . "</p>";
                                            echo "<p>Duration : " . $duration2 . " minutes</p>";
                                            echo "<p>Total Price : " . $stotalprice . "</p>";
                                            echo "<br>";
                                            $ssubtotal += $stotalprice;
                                            echo '<input type="text" name="BookID" value="'.$bid2.'" /hidden>';
                                        }
                                        else{
                                            echo "<p>Service Type : " . $sname . "</p>";
                                            echo "<p>Date : " . $sbookdate . "</p>";
                                            echo "<p>Time : " . $sbooktime . "</p>";
                                            echo "<p>Duration : " . $duration . " hour</p>";
                                            echo "<p>Total Price : " . $stotalprice . "</p>";
                                            echo "<br>";
                                            $ssubtotal += $stotalprice;
                                            echo '<input type="text"  name="BookID" value="'.$bid2.'" /hidden>';
                                        }
                                    }
                                    
                                } // end if for mysqli_stmt_num_rows($run) >= 1
                                else {
                                    echo '<div class="alert" style="background-color: #FFBC97; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>No booking !!!</strong> 
                                                 Dear, you havent booked any courses, services and competitions yet. <br>
                                                 You can go to book the court or service that your want.
                                          </div>'; 
                                }
                                // --- END Service Part -----
                        } // end if for isset($_COOKIE['MID'])
                        else {
                            echo '<div class="alert" style="padding: 10px; color: white;
                                      margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                      <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                      <strong>Not Sign in !!!</strong> Please sign in first ! 
                                   </div>'; 
                        }
                        ?>
                        <h3><b>For Register Tournament</b></h3>
                        
                       <?php 
                       
                       $subtotal2 = 0;
                       if (isset($_COOKIE['MID'])){
                                $MID = $_COOKIE['MID'];
                       $booksql1 = "SELECT * FROM registration r, tournament t "
                               . "WHERE r.TID = t.TID AND MID = '$MID' AND RegDate = CURDATE()";
                                $f1 = mysqli_prepare($dbc, $booksql1);
                                mysqli_stmt_execute($f1);
                                if (mysqli_stmt_num_rows($f1) >= 0){
                                    $Bookre1 = mysqli_stmt_get_result($f1);
                                    
                                    while($brow1 = mysqli_fetch_array($Bookre1, MYSQLI_ASSOC)){
                        
                                        $rid = $brow1['RegID'];
                                        $rdate = $brow1['TDate'];
                                        $rtime = $brow1['TTime'];
                                        $rCat = $brow1['TCategories'];
                                        $npy = $brow1['NoOfPlayers'];
                                        $rPrice = $brow1['RegPrice'];                                        
                                       
                                            echo "<p>Tournament Date : " . $rdate . "</p>";
                                            echo "<p>Tournament Time : " . $rtime . "</p>";
                                            echo "<p>Tournament Categories : " . $rCat . "</p>";
                                            echo "<p>No Of Player : " . $npy . "</p>";
                                           echo "<p>Total Price : " . $rPrice . "</p>";
                                            
                                            echo "<br>";
                                            
                                          $subtotal2 += $rPrice; 
                                         
                                     echo '<input type="text" name="RegID" value="'.$rid.'" /hidden>';
                                    }
                                      
                                }
                                
                       }$subtotal3 = $subtotal1 + $subtotal2 + $asubtotal + $ssubtotal;
                                
                                echo "<p>ALL Total Price : ".$subtotal3."</p>";
                                
                                if (isset($_COOKIE['MID'])){
                                    $MID = $_COOKIE['MID'];
                                    $dsql = "SELECT * FROM member WHERE MID = '$MID'";
                                    $dis = mysqli_prepare($dbc, $dsql);
                                    mysqli_stmt_execute($dis);
                                    if (mysqli_stmt_num_rows($dis) >= 0){
                                        $disre = mysqli_stmt_get_result($dis);

                                        while($drow = mysqli_fetch_array($disre, MYSQLI_ASSOC)){
                                            $discount = $drow['discount'];

                                            if ($discount <= 1){
                                            echo "<p>You got this discount</p>";
                                            echo "<p>Payment Discount : " . $discount . "</p>";
                                            $ds = $subtotal3 - ($subtotal3 * $discount);
                                            }
                                            elseif ($discount > 1){
                                                echo "<p>You got this discount</p>";

                                                $udis = $discount - 1;
                                                $dfg = $discount - $udis;
                                                echo "<p>Get 100 % Offer</p>";
                                                echo "<p>Payment Discount : " . $dfg . "</p>";
                                                $ds = $subtotal3 - ($subtotal3 * $dfg);

                                                $dsdf = "UPDATE member SET discount = '$udis' WHERE MID= '$MID'";
                                                if($result = mysqli_query($dbc, $dsdf)) {

                                                }

                                             }
                                        }

                                    }
                                }
                                echo '<input type="text" name="PayTotal" value="'.$ds.'" /hidden>';
                                echo '<input type="date" name="PayDate" value="'.date('Y-m-d').'"/hidden>';
                        ?>
                    </div>
                    <div class="card-footer">
                        <p style="text-align: center; font-size: 20px; 
                           color: rgb(255, 179, 179);">Sub Total : RM <?php echo $ds; ?></p>
                    </div>
                </div>
            </div>
        </div>
        <!-- Payment -->
        <div class="col">
            <div class="card">
                <div class="card-body">
                    <div class="card-title"><b style="font-size: 30px; text-align: center;">Payment</b></div>
                    <div class="card-text">
                        <!--<label for="fname">Accepted Cards</label>-->
                        <center>
                            <div class="icon-container" style="padding-bottom: 15px;">
                                <i class="fa fa-cc-visa" style="font-size: 38px; color:lightskyblue;"></i>
                                <i class="fa fa-cc-amex" style="font-size: 38px; color:lightskyblue;"></i>
                                <i class="fa fa-cc-mastercard" style="font-size: 38px; color:lightskyblue;"></i>
                                <i class="fa fa-cc-discover" style="font-size: 38px; color:lightskyblue;"></i>
                            </div>
                        </center>
                        <div class="card-body">
                            <div class="form-group" style="padding-left: 43px; padding-bottom: 16px;">
                                <label for="cname">Name on Card : </label>
                                <input type="text" id="cname" name="cardname" required><br>
                            </div>
                            <div class="form-group" style="padding-bottom: 16px;">
                                <label for="ccnum">Credit card number : </label>
                                <input type="text" id="ccnum" name="cardnumber" 
                                       placeholder="1111-2222-3333-4444" 
                                       pattern="xxxx-xxxx-xxxx-xxxx" required>
                            </div>
                            <!--<label for="expmonth">Exp Month</label>
                            <input type="text" id="expmonth" name="expmonth" placeholder="September">-->
                            <div class="form-group" style="padding-left: 76px; padding-bottom: 16px;">
                                <label for="expyear">Exp Date : </label>
                                <!--<input type="text" id="expyear" name="expyear" placeholder="2018">-->
                                <?php
                                $month = date('m');
                                ?>
                                <select name="month" id="month">
                                    <?php
                                    if ($month > 1){
                                        echo '<option value="01" '
                                        . 'style="background-color: grey; display: none;" readonly>01 </option>';
                                    }
                                    elseif ($month == 1){
                                        echo '<option value="01">01 </option>';
                                    }
                                    if ($month > 2){
                                        echo '<option value="02" '
                                        . 'style="background-color: grey; display: none;" readonly>02 </option>';
                                    }
                                    elseif ($month == 2){
                                        echo '<option value="02">02 </option>';
                                    }
                                    elseif ($month < 2){
                                        echo '<option value="02">02 </option>';
                                    }
                                    if ($month > 3){
                                        echo '<option value="03" '
                                        . 'style="background-color: grey; display: none;" readonly>03 </option>';
                                    }
                                    elseif ($month == 3){
                                        echo '<option value="03">03 </option>';
                                    }
                                    elseif ($month < 3){
                                        echo '<option value="03">03 </option>';
                                    }
                                    if ($month > 4){
                                        echo '<option value="04" '
                                        . 'style="background-color: grey; display: none;" readonly>04 </option>';
                                    }
                                    elseif ($month == 4){
                                        echo '<option value="04">04 </option>';
                                    }
                                    elseif ($month < 4){
                                        echo '<option value="04">04 </option>';
                                    }
                                    if ($month > 5){
                                        echo '<option value="05" '
                                        . 'style="background-color: grey; display: none;" readonly>05 </option>';
                                    }
                                    elseif ($month == 5){
                                        echo '<option value="05">05 </option>';
                                    }
                                    elseif ($month < 5){
                                        echo '<option value="05">05 </option>';
                                    }
                                    if ($month > 6){
                                        echo '<option value="06" '
                                        . 'style="background-color: grey; display: none;" readonly>06 </option>';
                                    }
                                    elseif ($month == 6){
                                        echo '<option value="06">06 </option>';
                                    }
                                    elseif ($month < 6){
                                        echo '<option value="06">06 </option>';
                                    }
                                    if ($month > 7){
                                        echo '<option value="07" '
                                        . 'style="background-color: grey; display: none;" readonly>07 </option>';
                                    }
                                    elseif ($month == 7){
                                        echo '<option value="07">07 </option>';
                                    }
                                    elseif ($month < 7){
                                        echo '<option value="07">07 </option>';
                                    }
                                    if ($month > 8){
                                        echo '<option value="08" '
                                        . 'style="background-color: grey; display: none;" readonly>08 </option>';
                                    }
                                    elseif ($month == 8){
                                        echo '<option value="08">08 </option>';
                                    }
                                    elseif ($month < 8){
                                        echo '<option value="08">08 </option>';
                                    }
                                    if ($month > 9){
                                        echo '<option value="09" '
                                        . 'style="background-color: grey; display: none;" readonly>09 </option>';
                                    }
                                    elseif ($month == 9){
                                        echo '<option value="09">09 </option>';
                                    }
                                    elseif ($month < 9){
                                        echo '<option value="09">09 </option>';
                                    }
                                    if ($month > 10){
                                        echo '<option value="10" '
                                        . 'style="background-color: grey; display: none;" readonly>10 </option>';
                                    }
                                    elseif ($month == 10){
                                        echo '<option value="10">10 </option>';
                                    }
                                    elseif ($month < 10){
                                        echo '<option value="10">10 </option>';
                                    }
                                    if ($month > 11){
                                        echo '<option value="11" '
                                        . 'style="background-color: grey; display: none;" readonly>11 </option>';
                                    }
                                    elseif ($month == 11){
                                        echo '<option value="11">11 </option>';
                                    }
                                    elseif ($month < 11){
                                        echo '<option value="11">11 </option>';
                                    }
                                    if ($month <= 12){
                                        echo '<option value="12">12 </option>';
                                    }
                                    ?>
                                </select>
                                <?php
                                $year = date("Y");
                                ?>
                                <select name="year" id="year">
                                    <option value="21">21</option>
                                    <option value="22">22</option>
                                    <option value="23">23</option>
                                    <option value="24">24</option>
                                    <option value="25">25</option>
                                    <option value="26">26</option>
                                    <option value="27">27</option>
                                    <option value="28">28</option>
                                    <option value="29">29</option>
                                </select>
                            </div>
                            <div class ="cv" style="padding-left: 116px;">
                                <label for="cvv" >CVV : </label>
                                <input type="text" id="cvv" name="cvv" placeholder="XXXX" 
                                       pattern="xxxx" required>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer" style="padding-top: 16px;">
                        <p style="text-align: center;"><button type="submit" name="submit" >Checkout</button></p>
                    </div>
                </div>
            </div>
        </div>
        <!--</aside>-->
    </div>
</form>

<?php
include('include/footer.php');
// if (isset($_COOKIE['MID'])){
//    $MID = $_COOKIE['MID'];
//            $em = "SELECT * From member WHERE MID = '$MID'";
//            $er = mysqli_prepare($dbc, $em);
//                                mysqli_stmt_execute($er);
//                                if (mysqli_stmt_num_rows($er) >= 0){
//                                    $re = mysqli_stmt_get_result($er);
//                                    
//                                    while($erow = mysqli_fetch_array($re, MYSQLI_ASSOC)){
//                                        $email = $erow['MEmailAddress'];
//                                        
//                                        echo '<input type="text" name="MEmailAddress" value="'.$email.'" /hidden>';
//                                    }
//                                }
                                
// }
//            $email = $_POST['MEmailAddress'];
//            echo $email;
//            if(isset($_POST['sendmail'])){
//            if(mail($_POST['MEmailAddress'], "The Challenger Sport Center ", "Dear Customer, Your Payment are completed.")){
//                echo "MAIL send";
//            }else{
//                echo "Failed";
//            }
//            }
            
?>