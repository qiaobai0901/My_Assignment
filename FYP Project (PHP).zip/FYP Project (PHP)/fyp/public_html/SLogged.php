<?php
if(!isset($_COOKIE['SID'])){
    require('function/login_function.php');
    redirect_user();
}
echo '<script language="javascript">';
echo 'alert("Log In Successfully !")';
echo '</script>';

include('Shomepage.php');
?>
