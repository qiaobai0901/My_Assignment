<?php
include('include/header.php');
?>

<div class="container">
    <h2>About Us</h2>
    <p>The Challenger Sports Centre was incorporated in May 2007. Our 1st centre was located in Cheras, Taman Connaught. After 2 years of operation, we have relocated our centre to a larger piece of land in Taman Cuepacs. In April 2009, our 2nd Challenger Sports Centre branch in Section 14, Petaling Jaya began its operation.  A year later, our 3rd centre in Kepong, have also started its operation in April 2010.  Our 4th Challenger Sports Centre branch in Ampang opened in October 2012.  Our latest location of Challenger Sports Centre is located at Sg Long branch in 14th May 2016.</p>
    <p>The Challenger Sports Centre consists of indoor badminton courts, indoor futsal courts, table tennis tables, and gym with yoga & zumba sessions (at selected centres). Our premises are relatively huge and easy to locate. In addition to that, our centres have ample parking spaces which are well lighted and guarded with security surveillances to ensure customers' safety at our centres at all times.</p>
    <p>Customers' high quality satisfactions has become an important aspect in our centre as we only use rubberize mat for all our court flooring. Besides, our lighting system is also specifically designed to ensure sufficient brightness to ensure the best playing environment. After a highly satisfying game, customers could also ease themselves out with our hot shower heating facilities. After shower, customers could also proceed to our adjourned cafeteria / waiting area to grab some light food / snacks while catching up with their friends or family members. The cafeteria is well equipped with satellite TV facility and large projector screen for customers to watch live Football and Badminton matches.</p>
    <p>Add on to that, we are also providing in-house professional badminton coaching services at our centres. Training classes ranges from beginners, intermediate, advance, and state level training are available at a reasonable and affordable fees.</p>
</div>

<style>
    body{
        background-image: url('pic/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg');
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%; 
        height: 100vh;
        margin: 0;
        display: flex;
        flex-direction: column;
    }
    
    .container{
        flex: 1;
        background: rgba(255, 255, 255, 0.3);
        margin: 20px auto;
        padding: 0 100px;
        max-width: 80%;
    }

    .container h2{
        color: skyblue;
        margin-top: 50px;
        font-family: fantasy;
    }

    .container p{
        color: skyblue;
        margin-top: 20px;
        font-size: large;
        font-family: serif;
    } 
</style>
    
<?php
include('include/footer.php');
?>