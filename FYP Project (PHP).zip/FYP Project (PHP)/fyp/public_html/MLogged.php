<?php
if(!isset($_COOKIE['MID'])){
    require('function/MLogin_function.php');
    redirect_user();
}
echo '<script language="javascript">';
echo 'alert("Log In Successfully !")';
echo '</script>';

include('homepage.php');
?>