<?php

include ('include/header.php');

require ('mysqli_connect.php');

  if(isset($_COOKIE['MID'])) {
      
    $search_query = "SELECT * FROM member WHERE MID = '".$_COOKIE['MID']."'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $MName = $rows['MName'];
                        $MEmailAddress = $rows['MEmailAddress'];
                        $point = $rows['point'];
                        
                      
                    }
                    
                   
                }
            }
  }
  
  if(isset($_POST['submit'])) {
      
    if($point >= 50){
    $query = "UPDATE member SET point = point - 50, discount = discount + 0.5
    WHERE MID='".$_COOKIE['MID']."'";

    if($result = mysqli_query($dbc, $query)) {
      
      echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Exchange Successfull !!!</strong> 
                           </div>';
      }
       else {

      echo '<div class="alert" style="padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Not Successful !!!</strong> Please try again !
                           </div>';

    }
    }else{
        echo '<div class="alert" style="padding: 10px; color: white; 
                                    margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                <strong>Sorry, Your points havent more than 50 points</strong>  
                                
                          </div>';  
      
      }

  }
?>

    <style>
        
        body{
            background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
            background-attachment: fixed;
            background-size: 100% 100%;
            background-repeat: no-repeat;
            width: 100%; 
        }
        .regform{
            
            width: 500px;
            background-color: black;
            margin: auto;
            color: #ffffff;
            padding:10px 0px 10px 0px;
            text-align: center;
            
        }
        
        .main{
            
            background-color: #343a40;
            width: 500px;
            margin: auto;
            height: 550px;
            border-radius: 15px 15px 15px 15px;
            text-align: center;
            

        }
        
        
        #name{
            height:100px ;
            width: 100%;
            
        }
        
        .form-group{
            color: skyblue;
            font-family: inherit;
            font-size: 20px;
            
            
        }

            .contact{
                height: 120px;
                width: 100%;
                outline: none;
                border: none;
                color: gray;
                background-color: black;
                padding: 10px;
            }
            
            

        </style>
    
        
        <div class="regform"><h2> Exchange Discount </h2></div>
    <div class="main">
        <form class="form" action="MRexchange2.php" method="post">
            <div class="form-group">
                
                <br><br>
                
                <label class="lastlabel1">Name:</label>
                <input class="MName" type="" name="MName" value="<?php echo $MName;?>"><br><br>
                <label class="">Email Address:</label>
                <input class="email" type="" name="MEmailAddress" value="<?php echo $MEmailAddress;?>"><br><br>
                <label class="Price" style="color: white;" value="50">Get 50% Discount </label><br><br>
                
             
                <input type="submit" name="submit" class="btn btn-info btn-md" value="Comfirm">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="MyReward.php" class="btn btn-info btn-md">Cancel</a>
            </div>
                
                
   
            </form>
        </div>
<style>
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>             

<?php 

include ('include/footer.php');
  mysqli_close($dbc);
?>


