<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    //For processing the login
    require('function/login_function.php');
    //define connection to your database
    require('mysqli_connect.php');
    ob_end_clean();
        $email = $_REQUEST['email'];
        $pass = $_REQUEST['pass'];
        
        list($check,$data)=check_login($dbc,$_REQUEST['email'],$_REQUEST['pass']);
        
        if($check){ //OK
//            echo"<br>OK!!!,email=,$email and pass=,$pass";
           
            if(!empty($data['SID'])){
                setcookie ('SID',$data['SID'],time()+3600,'/','',0,0);
                setcookie ('SName',$data['SName'],time()+3600,'/','',0,0);
                setcookie ('SGender',$data['SGender'],time()+3600,'/','',0,0);
                setcookie ('SBirthDate',$data['SBirthDate'],time()+3600,'/','',0,0);
                setcookie ('SPhoneNo',$data['SPhoneNo'],time()+3600,'/','',0,0);
                setcookie ('SAddress',$data['SAddress'],time()+3600,'/','',0,0);
                setcookie ('SEmailAddress',$data['SEmailAddress'],time()+3600,'/','',0,0);
                setcookie ('SUsername',$data['SUsername'],time()+3600,'/','',0,0);
                redirect_user("SLogged.php");
            }

        }
        else{//Unsuccessful
            $errors=$data;
        }

include('SLoginPage.php');
}// End if of $_SERVER['REQUEST_METHOD']
?>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>