<?php
include('include/header.php');
require('mysqli_connect.php');
      
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $ds = $_POST['PayTotal'];
    $bid = $_POST['BookID'];
    $PayDate = $_POST['PayDate'];
    $PayType = 'Card';
    $PayStatus = 'Paid';
    $regid = isset($_POST['RegID']);
    
    $sql = "SELECT * FROM Payment WHERE PayStatus='Paid' AND BookID='$bid' OR RegID='$regid'";
    $result2 = mysqli_query($dbc, $sql);
    if(mysqli_num_rows($result2) == 1){
        echo '<div class="alert" style="padding: 10px; color: white; 
                        margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                      <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                      <strong>Not Successful !!!</strong> The Booking item(s) is already paid !
                 </div>';
    }
    else{
        $query = "UPDATE member SET point = point + 1
            WHERE MID='".$_COOKIE['MID']."'";
        if($result = mysqli_query($dbc, $query)) {
            echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                          margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                        <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                        <strong>Earn 1 point !!!</strong> 
                   </div>';
          }
          else {
              echo '<div class="alert" style="padding: 10px; color: white; 
                            margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                          <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                          <strong>Not Successful !!!</strong> Please try again !
                     </div>';
         }

         $stmt = mysqli_prepare($dbc, "SELECT PayID FROM payment ORDER BY PayID DESC LIMIT 1;");
         mysqli_stmt_execute($stmt);
         $res = mysqli_stmt_get_result($stmt);
         $i = 1;
         while ($r = mysqli_fetch_array($res)) {
             $o = preg_replace('/[^0-9]/', '', $r['PayID']); //php get only numbers from string
             $an = $o + $i;
             $id = str_pad($an, 6, "P0000", STR_PAD_LEFT); // combine int and string
         }

         if (!isset($_POST['RegID'])){
             $q = "INSERT INTO payment (PayID, PayType, PayDate, PayTotal, PayStatus, BookID) "
                     . "VALUES ('$id','$PayType','$PayDate','$ds','$PayStatus','$bid')";
             $rq = mysqli_query($dbc, $q) or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
             if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                 echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                             margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                             <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                             <strong>Successful !!!</strong> Thank you for Payment !
                        </div>';
                 echo '<div><h1>Payment Successfull</h1><br> </div>
                     <p>Thank You, Your Booking is completed.</p><br>
                     Payment Number: ' . $id . '<br>';
             }
             else { // The email address is not available.
                 echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                            margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                            <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                            <strong>not match !!!</strong>   Please enter again !
                        </div>';
             }
         }
         else{
             $rid = $_POST['RegID'];
             $q = "INSERT INTO payment (PayID, PayType, PayDate, PayTotal, PayStatus, BookID, RegID) "
                     . "VALUES ('$id','$PayType','$PayDate','$ds','$PayStatus','$bid','$rid')";
             $rq = mysqli_query($dbc, $q) or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
             if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                 echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                             margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                             <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                             <strong>Successful !!!</strong> Thank you for Payment !
                        </div>';
                 echo '<div><h1>Payment Successfull</h1><br> </div>
                     <p>Thank You, Your Booking is completed.</p><br>
                     Payment Number: ' . $id . '<br>';
             }
             else { // The email address is not available.
                 echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                            margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                            <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                            <strong>not match !!!</strong>   Please enter again !
                        </div>';
             }
         }
    } // end if(mysqli_num_rows($result2) == 1)
} //end if($_SERVER['REQUEST_METHOD']=='POST')    
?>
<style>
    body{
        background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: lightskyblue;
        font-weight: bolder;
        font-family: Comic Sans Ms;
        backdrop-filter: blur(6px);
        text-align: center;
    }
    /* Float four columns side by side */
    .col {
        float: left;
        width: 30%;
        margin-left: 100px;
        margin-right: 60px;
        padding-top: 30px;
    }
    /* Remove extra left and right margins, due to padding in columns */
    .row {
        /* margin: 0 -5px;*/
        margin: 0 -5px;
        padding-top: 20px;
        padding-right: 50px;
    }
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    /* Style the counter cards */
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
      padding-left: 30px;
      padding-right: 30px;
      padding-top: 20px;
      padding-bottom: 10px;
      text-align: left;
      background-color: rgb(41, 82, 163, 0.8); /*rgb(?, ?, ?, opacity); */
      border-radius: 60px;
      width: 100%;
    }
    label, input, option {
        font-size: 16px;
    }
    /* Responsive layout - makes the menu and the content (inside the section) sit on top of each other instead of next to each other */
    @media (max-width: 600px) {
      section {
        -webkit-flex-direction: column;
        flex-direction: column;
      }
    }
    .page-footer {
       bottom:0;
       width:100%;
    }/* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>

<!--                <p>You will receive an email confirmation</p>-->
<!--               
                <button>Exit</button>
           -->
 <?php 
include('include/footer.php');
?>
       