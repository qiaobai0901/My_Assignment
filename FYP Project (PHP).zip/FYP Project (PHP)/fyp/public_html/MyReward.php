<?php

include ('include/header.php');

require ('mysqli_connect.php');
session_start();
  if(isset($_SESSION['MID'])) {
      
    $search_query = "SELECT * FROM member WHERE MID = '".$_SESSION['MID']."'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $MName = $rows['MName'];
                        $point = $rows['point'];
                        
                      
                    }
                    
                   
                }
            }
  }
          

?>

   
        <h1 style="color: skyblue; font-family:fantasy">My Rewards</h1>
                        <h3 style="color: skyblue; font-family:fantasy"><?php echo $MName;?></h3>
                        <br>
                        <div class="circular">
            <div class="inner"></div>
            <div class="outer"></div>
            <div class="numb">
   <?php
          
     echo $point;
 
     ?> points
            </div>
            <div class="circle">
               <div class="dot">
                  <span></span>
               </div>
               <div class="bar left">
                  <div class="progress"></div>
               </div>
               <div class="bar right">
                  <div class="progress"></div>
               </div>
            </div>
         </div>

         

          
                  <main role="main">
                    <div class="wrapper" style="background-color: black; margin-top: 0px;">
                        
                        <div class="album py-5 ">
                        <h2 class="text-uppercase" style="color:skyblue; font-family:serif; text-align: center;">Voucher</h2>
                        
                        <div class="container">
                        <div class="branch" style="display:flex; text-align:center; width:auto; justify-content: center;">
                            
                        <div class="row">  
                            
                                
                            <div class="branch_name" style="background: #343a40;">
                                <br><br><h4 style="color:skyblue; font-family: serif;">30% OFF Online Voucher</h4><br><br><br>
                                <p style="color:skyblue; font-family: serif;">This voucher is only for member.</p><br><br><br>
                                <p style="color:skyblue; font-family: serif;">Member must have 30 points to collect this voucher.</p>
                                <p style="color:skyblue; font-family: serif;">Term & Condition Applied</p>
                                <a type="submit" style="width:100%;" id="f1" class="btn btn-outline-primary" href="MRexchange1.php">Exchange</a>
                            </div>
                          
                        
                           <div class="branch_name" style="background: #343a40;">
                                <br><br><h4 style="color:skyblue; font-family: serif;">50% OFF Online Voucher</h4><br><br><br>
                                <p style="color:skyblue; font-family: serif;">This voucher is only for member.</p><br><br><br>
                                <p style="color:skyblue; font-family: serif;">Member must have 50 points to collect this voucher.</p>
                                <p style="color:skyblue; font-family: serif;">Term & Condition Applied</p>
                                <a type="submit" style="width:100%;" id="f2" class="btn btn-outline-primary" href="MRexchange2.php">Exchange</a>
                            </div>
                            
                            <div class="branch_name" style="background: #343a40;">
                                <br><br><h4 style="color:skyblue; font-family: serif;">70% OFF Online Voucher</h4><br><br><br>
                                <p style="color:skyblue; font-family: serif;">This voucher is only for member.</p><br><br><br>
                                <p style="color:skyblue; font-family: serif;">Member must have 70 points to collect this voucher.</p>
                                <p style="color:skyblue; font-family: serif;">Term & Condition Applied</p>
                                <a type="submit" style="width:100%;" id="f3" class="btn btn-outline-primary" href="MRexchange3.php">Exchange</a>
                            </div>
                        </div>
                       </div>   
 
                        </div>
                        </div>
                </div>
        </main>
          
          
                       
            
            
          
         
<style>
body{
 background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
    background-attachment: fixed;
    background-size: 100% 100%;
    background-repeat: no-repeat;
    width: 100%; 
  text-align: center;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins', sans-serif;
}

.circular{
  height: 100px;
  width: 100px;
  position: relative;
  margin: auto;
}
.circular .inner, .circular .outer, .circular .circle{
  position: absolute;
  z-index: 6;
  height: 100%;
  width: 100%;
  border-radius: 100%;
  box-shadow: inset 0 1px 0 rgba(0,0,0,0.2);
}
.circular .inner{
  top: 50%;
  left: 50%;
  height: 80px;
  width: 80px;
  margin: -40px 0 0 -40px;
  background-color: black;
  border-radius: 100%;
  box-shadow: 0 1px 0 rgba(0,0,0,0.2);
}
.circular .circle{
  z-index: 1;
  box-shadow: none;
}
.circular .numb{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 10;
  font-size: 15px;
  font-weight: 500;
  color: skyblue;
}
.circular .bar{
  position: absolute;
  height: 100%;
  width: 100%;
  background: #fff;
  -webkit-border-radius: 100%;
  clip: rect(0px, 100px, 100px, 50px);
}
.circle .bar .progress{
  position: absolute;
  height: 100%;
  width: 100%;
  -webkit-border-radius: 100%;
  clip: rect(0px, 50px, 100px, 0px);
}
.circle .bar .progress, .dot span{
  background: skyblue;
}
.circle .left .progress{
  z-index: 1;
  animation: left 4s linear both;
}
@keyframes left {
  100%{
    transform: rotate(180deg);
  }
}
.circle .right{
  z-index: 3;
  transform: rotate(180deg);
}
.circle .right .progress{
  animation: right 4s linear both;
  animation-delay: 4s;
}
@keyframes right {
  100%{
    transform: rotate(180deg);
  }
}
.circle .dot{
  z-index: 2;
  position: absolute;
  left: 50%;
  top: 50%;
  width: 50%;
  height: 10px;
  margin-top: -5px;
  animation: dot 8s linear both;
  transform-origin: 0% 50%;
}
.circle .dot span {
  position: absolute;
  right: 0;
  width: 10px;
  height: 10px;
  border-radius: 100%;
}
@keyframes dot{
  0% {
    transform: rotate(-90deg);
  }
  50% {
    transform: rotate(90deg);
    z-index: 4;
  }
  100% {
    transform: rotate(270deg);
    z-index: 4;
  }
}

.wrapper{
    margin-top: 10%;
    
}


.branch_name{
    background: #fff;
    margin:5px;
    margin-bottom: 50px;
    width: 300px;
    border-radius: 20px;
}

.branch .branch_name h3{
    color: activecaption;
      
}

.btn{
    border-radius: 20px;
    color: skyblue;
    
}
/*    .page-footer {
     position:absolute;
     bottom:0;
     width:100%;
    }*/

    .contact{
    height: 300px;
    width: 100%;
    outline: none;
    border: none;
    color: gray;
    background-color: black;
    padding: 10px;
    }

             </style>

    
    </body>
</html>
<?php

  mysqli_close($dbc);
include ('include/footer.php');
?>


