<?php 
include('include/header.php');
require ('mysqli_connect.php');

$search_query = "SELECT * FROM tournament WHERE TCategories = 'Child' AND TID = '4.1'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TDate1 = $rows['TDate'];
                        $TTime1 = $rows['TTime'];

                    }
                }
            }


    
    $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.1'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID43 = $rows['TID'];
                        $playername43 = $rows['PlayerName'];
                        $Score43 = $rows['Score'];
                      
                    }
                }
            }
                
    $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.2'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID44 = $rows['TID'];
                        $playername44 = $rows['PlayerName'];
                        $Score44 = $rows['Score'];
                      
                    }
                }
            }  
            
    $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.3'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID45 = $rows['TID'];
                        $playername45 = $rows['PlayerName'];
                        $Score45 = $rows['Score'];
                      
                    }
                }
            } 
            
        $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.4'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID46 = $rows['TID'];
                        $playername46 = $rows['PlayerName'];
                        $Score46 = $rows['Score'];
                      
                    }
                }
            }
        $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.5'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID47 = $rows['TID'];
                        $playername47 = $rows['PlayerName'];
                        $Score47 = $rows['Score'];
                      
                    }
                }
            }
            
                    $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.6'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID48 = $rows['TID'];
                        $playername48 = $rows['PlayerName'];
                        $Score48 = $rows['Score'];
                      
                    }
                }
            }
            
                    $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.7'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID49 = $rows['TID'];
                        $playername49 = $rows['PlayerName'];
                        $Score49 = $rows['Score'];
                      
                    }
                }
            }
            
                    $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.8'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID50 = $rows['TID'];
                        $playername50 = $rows['PlayerName'];
                        $Score50 = $rows['Score'];
                      
                    }
                }
            }
            
            $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.1.1'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID51 = $rows['TID'];
                        $playername51 = $rows['PlayerName'];
                        $Score51 = $rows['Score'];
                      
                    }
                }
            }
            
            $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.1.2'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID52 = $rows['TID'];
                        $playername52 = $rows['PlayerName'];
                        $Score52 = $rows['Score'];
                      
                    }
                }
            }
            
            $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.1.3'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID53 = $rows['TID'];
                        $playername53 = $rows['PlayerName'];
                        $Score53 = $rows['Score'];
                      
                    }
                }
            }
            
            $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.1.4'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID54 = $rows['TID'];
                        $playername54 = $rows['PlayerName'];
                        $Score54 = $rows['Score'];
                      
                    }
                }
            }
            
            $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.1.1.1'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID55 = $rows['TID'];
                        $playername55 = $rows['PlayerName'];
                        $Score55 = $rows['Score'];
                      
                    }
                }
            }
            
            $search_query = "SELECT tournament.TID, registration.Score, registration.PlayerName FROM tournament INNER JOIN registration ON tournament.TID = registration.TID WHERE tournament.TID = '4.1.1.2'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID56 = $rows['TID'];
                        $playername56 = $rows['PlayerName'];
                        $Score56 = $rows['Score'];
                     
                    }
                }
            }


?>
  
  <header class="hero">
    <div class="hero-wrap">
     <p class="intro" id="intro">BADMINTON</p><br>
     <h1 id="headline">Tournament</h1>
     <p class="year"><i class="fa fa-star"></i><?php echo $TDate1;?><i class="fa fa-star"></i></p>
     
     <p><?php echo $TTime1;?></p>
   </div>
  </header>


  <section id="bracket">
  <div class="container">
  <div class="split split-one">
    <div class="round round-one current">
      <div class="round-details">Round 1<br/><span class="date">30 minute's</span></div>
      <ul class="matchup">
          <form method="post" action="testTT.php">
          <li class="team team-top">4.1 <?php echo $playername43;?><span class="score"><?php echo $Score43;?></span></li>
        <li class="team team-bottom">4.2 <?php echo $playername44;?><span class="score"><?php echo $Score44;?></span></li>
      </form>
      </ul>
      <ul class="matchup">
        <li class="team team-top">4.3 <?php echo $playername45;?><span class="score"><?php echo $Score45;?></span></li>
        <li class="team team-bottom">4.4 <?php echo $playername46;?><span class="score"><?php echo $Score46;?></span></li>
      </ul>
           
                   
    </div>  <!-- END ROUND ONE -->

    <div class="round round-two">
      <div class="round-details">Round 2<br/><span class="date">30 minute's</span></div>     
      <ul class="matchup">
        <li class="team team-top"><?php echo $TID51;?> <?php echo $playername51;?><span class="score"><?php echo $Score51;?></span></li>
        <li class="team team-bottom"><?php echo $TID52;?> <?php echo $playername52;?><span class="score"><?php echo $Score52;?></span></li>
      </ul> 
      
                  
    </div>  <!-- END ROUND TWO -->
    
   
  </div> 

<div class="champion">

    <div class="final">
      <i class="fa fa-trophy"></i>
      <div class="round-details">championship <br/><span class="date">Congratulation!!</span></div>    
      <ul class ="matchup">
        <li class="team team-top"><?php echo $TID55;?> <?php echo $playername55;?><span class="score"><?php echo $Score55;?></span></li>
        <li class="team team-bottom"><?php echo $TID56;?> <?php echo $playername56;?><span class="score"><?php echo $Score56;?></span></li>
      </ul>
    </div> 
  </div>
      
      


  <div class="split split-two">

    <div class="round round-two">
      <div class="round-details">Round 2<br/><span class="date">30 minute's</span></div>           
      <ul class="matchup">
        <li class="team team-top"><?php echo $TID53;?> <?php echo $playername53;?><span class="score"><?php echo $Score53;?></span></li>
        <li class="team team-bottom"><?php echo $TID54;?> <?php echo $playername54;?><span class="score"><?php echo $Score54;?></span></li>
      </ul> 
      
                   
    </div>  <!-- END ROUND TWO -->
    <div class="round round-one current">
      <div class="round-details">Round 1<br/><span class="date">30 minute's</span></div>
      <ul class="matchup">
        <li class="team team-top">4.5 <?php echo $playername47;?><span class="score"><?php echo $Score47;?></span></li>
        <li class="team team-bottom">4.6 <?php echo $playername48;?><span class="score"><?php echo $Score48;?></span></li>
      </ul>
      <ul class="matchup">
        <li class="team team-top">4.7 <?php echo $playername49;?><span class="score"><?php echo $Score49;?></span></li>
        <li class="team team-bottom">4.8 <?php echo $playername50;?><span class="score"><?php echo $Score50;?></span></li>
      </ul>
          
                  
    </div>  <!-- END ROUND ONE -->                  
  </div>
      
       
  </div>
      
     
  </section>
        
          
         <center><a class="btn btn-info my-2 my-sm-0" href="MTourRegister4.php">Register</a></center>
         
         
    <style>
        body {font-family: 'Istok Web', sans-serif;background: url("http://picjumbo.com/wp-content/uploads/HNCK2189-1300x866.jpg") no-repeat #000;background-size: cover;min-height: 100%;margin: 0;}
.hero {position:relative; text-align: center; overflow: hidden; color: #fcfcfc; }
.hero h1 {font-family: 'Holtwood One SC', serif;font-weight: normal;font-size: 5.4em;margin:0 0 20px; text-shadow:0 0 12px rgba(0, 0, 0, 0.5);text-transform: uppercase;letter-spacing:-1px;}
.hero p {font-family: 'Abel', sans-serif;text-transform: uppercase; color: skyblue; letter-spacing: 6px;text-shadow:0 0 12px rgba(0, 0, 0, 0.5);font-size: 1.2em;}
.hero-wrap {padding: 3.5em 10px;}
.hero p.intro {font-family: 'Holtwood One SC', serif;text-transform: uppercase;letter-spacing: 1px;font-size: 3em;margin-bottom:-40px;}
.hero p.year {color: #fff; letter-spacing: 20px; font-size: 34px; margin: -25px 0 25px;}
.hero p.year i {font-size: 14px;vertical-align: middle;}
#bracket {overflow:hidden;background-color: #e1e1e1;background-color:rgba(225,225,225,0.9);padding-top: 20px;font-size: 12px;padding: 40px 0;}
.container {max-width: 1100px;margin: 0 auto;display:block;display: -webkit-box;display: -moz-box;display: -ms-flexbox;display: -webkit-flex;display: -webkit-flex;display: flex;-webkit-flex-direction:row;flex-direction: row;}
.split {display:block;float:left;display: -webkit-box;display: -moz-box;display: -ms-flexbox;display: -webkit-flex;display:flex;width: 30%;-webkit-flex-direction:row;-moz-flex-direction:row;flex-direction:row;}
.champion {float:left;display:block;width: 16%;-webkit-flex-direction:row;flex-direction:row;-webkit-align-self:center;align-self:center;margin-top: -15px;text-align: center;padding: 230px 0\9;} 
.champion i {color: #a0a6a8; font-size: 45px;padding: 10px 0; }
.round {display:block;float:left;display: -webkit-box;display: -moz-box;display: -ms-flexbox;display: -webkit-flex;display:flex;-webkit-flex-direction:column;flex-direction:column;width:95%;width:30.8333%\9;}
.split-two {}
.split-one .round {margin: 0 2.5% 0 0;}
.split-two .round {margin: 0 0 0 2.5%;}
.matchup {margin:0;width: 100%;padding: 10px 0;height:60px;}
.score {font-size: 11px;text-transform: uppercase;float: right;color: skyblue;font-weight: bold;font-family: 'Roboto Condensed', sans-serif;position: absolute;right: 5px;}
.team {padding: 0 5px;margin: 3px 0;height: 25px; line-height: 25px;white-space: nowrap; overflow: hidden;position: relative;color: skyblue;background-color: black;}
.round-two .matchup {margin:0; height: 60px;padding: 50px 0;}
.round-three .matchup {margin:0; height: 60px; padding: 130px 0;}
.round-details {font-family: 'Roboto Condensed', sans-serif; font-size: 13px; color: black;text-transform: uppercase;text-align: center;height: 40px;}
.champion li, .round li {background-color: black;box-shadow: none; opacity: 0.45;}
.current li {opacity: 1;}
.current li.team {background-color: black;box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);opacity: 1;}
.vote-options {display: block;height: 52px;}
.share .container {margin: 0 auto; text-align: center;}
.share-icon {font-size: 24px; color: #fff;padding: 25px;}
.share-wrap {max-width: 1100px; text-align: center; margin: 60px auto;}
.final {margin: 4.5em 0;}

@-webkit-keyframes pulse {
  0% {
    -webkit-transform: scale(1);
    transform: scale(1);
  }

  50% {
    -webkit-transform: scale(1.3);
    transform: scale(1.3);
  }

  100% {
    -webkit-transform: scale(1);
    transform: scale(1);
  }
}

@keyframes pulse {
  0% {
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
  }

  50% {
    -webkit-transform: scale(1.3);
    -ms-transform: scale(1.3);
    transform: scale(1.3);
  }

  100% {
    -webkit-transform: scale(1);
    -ms-transform: scale(1);
    transform: scale(1);
  }
}

.share-icon {color: #fff; opacity: 0.35; }
.share-icon:hover { opacity:1;  -webkit-animation: pulse 0.5s; animation: pulse 0.5s;}
.date {font-size: 10px; letter-spacing: 2px;font-family: 'Istok Web', sans-serif;color:#3F915F;}



@media screen and (min-width: 981px) and (max-width: 1099px) {
  .container {margin: 0 1%;}
  .champion {width: 14%;}
  .split {width:43%; }
  .split-one .vote-box {margin-left: 138px;}
  .hero p.intro {font-size: 28px;}
  .hero p.year {margin: 5px 0 10px;}

}

@media screen and (max-width: 980px) {
  .container {-webkit-flex-direction:column;-moz-flex-direction:column;flex-direction:column;}
  .split, .champion {width: 90%;margin: 35px 5%;}
  .champion {-webkit-box-ordinal-group:3;-moz-box-ordinal-group:3;-ms-flex-order:3;-webkit-order:3;order:3;}
  .split {border-bottom: 1px solid #b6b6b6; padding-bottom: 20px;}
  .hero p.intro {font-size: 24px;}
  .hero h1 {font-size: 3em; margin: 15px 0;}
  .hero p {font-size: 1em;}
}


@media screen and (max-width: 400px) {

  .split {width: 95%;margin: 25px 2.5%;}
  .round {width:21%;}
  .current {-webkit-flex-grow:1;-moz-flex-grow:1;flex-grow:1;}
  .hero h1 {font-size: 2.15em; letter-spacing: 0;margin:0; }
  .hero p.intro {font-size: 1.15em;margin-bottom: -10px;}
  .round-details {font-size: 90%;}
  .hero-wrap {padding: 2.5em;}
  .hero p.year {margin: 5px 0 10px; font-size: 18px;}

}
/*   .page-footer {
     position:absolute;
     bottom:0;
     width:100%;

}*/

.btn{

    margin: auto;
    color:skyblue; 
    background-color:black;

}
    </style>
<?php

include('include/footer.php');

?>




