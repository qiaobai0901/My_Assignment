<?php
if (!isset($_COOKIE['SID'])) {
    require ('function/login_function.php');
    redirect_user();
} 
else {
    setcookie ('SID','',time()-3600,'/','',0,0);
    setcookie ('SName','',time()-3600,'/','',0,0);
    setcookie ('SGender','',time()-3600,'/','',0,0);
    setcookie ('SBirthDate','',time()-3600,'/','',0,0);
    setcookie ('SPhoneNo','',time()-3600,'/','',0,0);
    setcookie ('SAddress','',time()-3600,'/','',0,0);
    setcookie ('SEmailAddress','',time()-3600,'/','',0,0);
    setcookie ('SUsername','',time()-3600,'/','',0,0);
}
//require 'mysqli_connect.php';
//$sql2 = "SELECT * FROM member";
//$members = mysqli_query($dbc, $sql2) or die("Failed to query database".mysqli_error());
//while($member = mysqli_fetch_assoc($members)){
//    $sql3 = "SELECT * FROM messages";
//    $messages = mysqli_query($dbc, $sql3) or die("Failed to query database".mysqli_error());
//    while($message = mysqli_fetch_assoc($messages)){
//        if ($member['MID'] == $message['ToUser'] && $member['MID'] == $message['FromUser'] 
//                || $_COOKIE['SID'] == $message['ToUser'] && $_COOKIE['SID'] == $message['FromUser'] ){
//            $SID = $_COOKIE['SID'];
//            $MID = $member['MID'];
//            $sql = "DELETE FROM messages WHERE (FromUser='$MID' AND ToUser='$SID') OR "
//                    . "(FromUser='$SID' AND ToUser='$MID');";
//            mysqli_query($dbc, $sql);
//        }
//    }
//}
include ('homepage.php');
echo '<script language="javascript">';
echo 'alert("Log Out Success !")';
echo '</script>';

exit();
?>