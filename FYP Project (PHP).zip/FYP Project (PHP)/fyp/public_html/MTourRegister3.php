<?php
include('include/header.php');
require ('mysqli_connect.php');
    
    $search_query = "SELECT * FROM tournament WHERE TCategories = 'Child' AND TID = '3.1'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TDate = $rows['TDate'];
                        $TCategories = $rows['TCategories'];
                        $TTime = $rows['TTime'];

                    }
                }
            }
            
$MID = "";
if (isset($_COOKIE['MID'])) {

    $search_query = "SELECT * FROM member WHERE MID = '" . $_COOKIE['MID'] . "'";
    $search_result = mysqli_query($dbc, $search_query);
    if ($search_result) {
        if (mysqli_num_rows($search_result)) {
            while ($rows = mysqli_fetch_array($search_result)) {
                $MID = $rows['MID'];
            }
        }
    }


    if (isset($_POST['submit'])) {
       

    $PlayerName = $_POST['PlayerName'];
//    $RegDate = $_POST['RegDate'];
    $ContactNo = $_POST['ContactNo'];
    if (!preg_match("/^[a-zA-Z-' ]*$/", $PlayerName)) {
            echo '<div class="alert">
                         <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                         <strong>Only letters and white space allowed !!!</strong> Please enter again !
                   </div>';
        }
        else{
            $PlayerName = mysqli_real_escape_string($dbc, $PlayerName);
        }
       
         if(!preg_match("/^[0-9]{10}$/", $ContactNo)) {
             echo '<div class="alert">
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                       <strong>Error !!!</strong> Please enter again ! eg. 012XXXXXXX
                    </div>';
         }
         else{
             $ContactNo = mysqli_real_escape_string($dbc, $ContactNo);
         }
    
    if(isset( $_POST['TID'])){
        $TID = $_POST['TID'];
 $query = "SELECT * FROM `Registration` WHERE `TID` ='$TID'";
 $result = mysqli_query($dbc,$query); 

 if (mysqli_num_rows($result)) {
             echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>Tournament No '$TID' is already exists</strong></div>";
        } 
    }

    $stmt = mysqli_prepare($dbc, "SELECT RegID FROM registration ORDER BY RegID DESC LIMIT 1;");
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $i = 1;
        while ($r = mysqli_fetch_array($res)) {
            $o = preg_replace('/[^0-9]/', '', $r['RegID']); //php get only numbers from string
            $an = $o + $i;
            $id = str_pad($an, 6, "R0000", STR_PAD_LEFT); // combine int and string
        }
    
        $m = mysqli_connect('localhost', 'root', '', 'fyp');
        $stmt = mysqli_prepare($m, "INSERT INTO registration(RegID,PlayerName,NoOfPlayers,RegDate,RegPrice,ContactNo,TID,Score,MID)VALUES(?,?,'1',SYSDATE(),'20',?,?,'',?)");
        mysqli_stmt_bind_param($stmt, 'sssss',$id, $PlayerName, $ContactNo, $TID, $MID);
        if (mysqli_stmt_execute($stmt)){
            echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Register Successfull !!!</strong> 
                             </div>';
        }
            
                    
        
        mysqli_stmt_close($stmt);
        mysqli_close($m);
        
    
    
   }
}
    else{
echo '<div class="alert" style="padding: 10px; color: white;
                                      margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                      <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                      <strong>Not Sign in !!!</strong> Please sign in first ! 
                                   </div>';
}
?>

 <style>
        
        body{
            background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
            background-attachment: fixed;
            background-size: 100% 100%;
            background-repeat: no-repeat;
            width: 100%; 
        }
        .regform{
            
            width: 500px;
            background-color: black;
            margin: auto;
            color: #ffffff;
            padding:10px 0px 10px 0px;
            text-align: center;
            
        }
        
        .main{
            
            background-color: #343a40;
            width: 500px;
            margin: auto;
            height: 700px;
            border-radius: 15px 15px 15px 15px;
            text-align: center;
            

        }
        
        
        #name{
            height:100px ;
            width: 100%;
            
        }
        
        .form-group{
            color: skyblue;
            font-family: inherit;
            font-size: 20px;
            
            
        }

        .contact{
            height: 120px;
            width: 100%;
            outline: none;
            border: none;
            color: gray;
            background-color: black;
            padding: 10px;
        }

        </style>
    
                
    <div class="regform"><h2> Register </h2></div>
    <div class="main">
        <form class="form" action="MTourRegister3.php" method="post">
            <div class="form-group">
                <br>
                <label class="Price">Tournament Date:</label>
                <label><?php echo $TDate; ?></label><br>
                <label class="Price">Tournament Time:</label>
                <label><?php echo $TTime; ?></label><br>
                <label class="Price">Categories:</label>
                <label><?php echo $TCategories; ?></label><br>
                <label class="Price">No of Player:</label>
                <label>1 Player</label><br><br>
                
                
                
                <div class="form-group">
          <label for="TID">Tournament No:</label>

          <select class="TID" name="TID">
              <option value="3.1">3.1</option>
              <option value="3.2">3.2</option>
              <option value="3.3">3.3</option>
              <option value="3.4">3.4</option>
              <option value="3.5">3.5</option>
              <option value="3.6">3.6</option>
              <option value="3.7">3.7</option>
              <option value="3.8">3.8</option>
             
              
            </select><br><br>

        </div>
                
                <label class="firstlabel">Member ID:</label>
                <input class="MID" name="MID" value="<?php echo $MID; ?>"><br><br>

                <label class="firstlabel">Player Name:</label>
                <input class="PlayerName" required type="text" name="PlayerName"><br><br>
                <label class="CN">Contact No:</label>
                <input class="CN" required type="text" name="ContactNo"><br><br>
                <label class="Date">Register Date:</label>
                <label><?php echo date('Y-m-d'); ?></label><br><br>
                <label class="Price">Register Price:</label>
                <label>RM 20 </label><br><br>
             
                <input type="submit" name="submit" class="btn btn-info btn-md" value="Comfirm">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
               <a href="MTourShow3.php" class="btn btn-info btn-md">Cancel</a>
            </div>
                 
                
   
            </form>
        </div>
    
    
<?php

include('include/footer.php');

?>