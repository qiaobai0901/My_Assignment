<?php // DONE BUT IF NEED THE FORM HAVE FOLLOW THE SELECTED DATE AND TIME THEN NO
require ('mysqli_connect.php');
ob_end_clean();
include ('include/header.php');
$duration = 30;
$cleanup = 0;
$start = "09.00";
$end = "22.00";
function timeslots($duration, $cleanup, $start, $end){
    $start = new DateTime($start);
    $end = new DateTime($end);
    $interval = new DateInterval("PT". $duration ."M");
    $cleanupInterval = new DateInterval("PT". $cleanup ."M");
    $slots = array();
    for($intStart = $start; $intStart<$end; $intStart->add($interval)->add($cleanupInterval)){
        $endPeriod = clone $intStart;
        $endPeriod -> add($interval);
        if($endPeriod > $end){
            break;
        }
        $slots[] = $intStart -> format("H:ia") . " - " . $endPeriod -> format("H:ia");
    }
    return $slots;
}
// set date time
$dt = new DateTime;
$date = new DateTime;
if (isset($_GET['year']) && isset($_GET['week'])) {
    $dt->setISODate($_GET['year'], $_GET['week']);
     $date->setISODate($_GET['year'], $_GET['week']);
} else {
    $dt->setISODate($dt->format('o'), $dt->format('W'));
    $date->setISODate($dt->format('o'), $dt->format('W'));
}
$year = $dt->format('o');
$week = $dt->format('W');
$month = $dt->format('F');
$year = $dt->format('Y');
$yearG = $date->format('o');
$weekG = $date->format('W');
$monthG = $date->format('F');
$yearG = $date->format('Y');
?>
<style>
    body{
        background-image: url('pic/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg');
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%; 
        font-weight: bolder;
        padding-bottom: 100px;
    }
    table {
        /*width: 80%;*/
        background-color: rgb(134, 88, 45, 0.6);
        /*margin-left: 10%;*/
    }
    table, th, td {
        border: 2px solid rgb(217, 179, 140, 0.2);
        border-collapse: collapse;
    }
    th {
        background-color: rgb(128, 64, 0, 0.6);
    }
    tr:hover {
        background-color: rgb(102, 153, 153, 0.6);
    }
    td {
        background-color: rgb(51, 153, 102, 0.6);
        width: 12%;
        text-align: center;
    }
    td:hover {
        background-color: #3366cc;
    }
     a {
         color: lightskyblue;
         text-align: center;
         text-decoration: none;
         display: inline-block;
         padding-top: 10px;
         padding-bottom: 10px;
     }
     a:hover{
         color: white;
     }
     a.weekButton{
          padding: 10px 20px;
          border-radius: 30px;
     }
     a.weekButton:link, a.weekButton:visited{
         background-color: #3399ff;
         color: white;
         text-align: center;
         text-decoration: none;
         display: inline-block;
     }
     a.weekButton:hover, a.weekButton:active{
         background-color: #994d00;
     }
    h1,h2{
        text-align: center;
        color: skyblue;
    }
    h4{
        text-align: center;
        color: lightpink;
    }
    /* no style for button */
    input {
        font-weight: bold;
        background: transparent;
        box-shadow: 0px 0px 0px transparent;
        border: 0px solid transparent;
        text-shadow: 0px 0px 0px transparent;
        color: white;
    }
    input:hover {
        font-weight: bold;
        background: transparent;
        box-shadow: 0px 0px 0px transparent;
        border: 0px solid transparent;
        text-shadow: 0px 0px 0px transparent;
        color: #FFCC1D;
    }
</style>
<script type="text/javascript">
    //popup window code
    function PopupBookingRepairGripService(path){
        popupWindow = window.open(path, 'popUpWindow','height=900,width=700,left=460,top=20,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
    }
</script>
<div class="container">
    <h1>Booking Repair Grip Service</h1>
        <h2>Repair Grip Service Timetable</h2>
        <h4>This service may take 5 minutes to 30 minutes for repairing.</h4>
        <div class="row">
            <div class="col-md-12">
            <center>
                <h2><?php echo "$month $year"; ?></h2>
                <a class="weekButton" href="<?php echo $_SERVER['PHP_SELF'].'?week='.($week-1).'&year='.$year; ?>">
                    Previous Week</a> <!--Previous week-->
                    <a class="weekButton" href="BookRGripService.php"> Current Week</a> <!--Current week--> 
                <a class="weekButton" href="<?php echo $_SERVER['PHP_SELF'].'?week='.($week+1).'&year='.$year; ?>">
                    Next Week</a> <!--Next week-->
            </center><br>
            
            <table class="table table-bordered">
                <thead>
                <tr class="success">
                    <th>Day / Time</th>
                    <?php
                    do {
                        if($dt->format('d-m-Y') == date('d-m-Y')){
                            echo "<th style='background:yellow;'>" . $dt->format('l') . "<br>" . 
                                    $dt->format('d-m-Y') . "</th>";
                        }
                        else{
                            echo "<th>" . $dt->format('l') . "<br>" . 
                                    $dt->format('d-m-Y') . "</th>";
                            }
                            $dt->modify('+1 day');
                     } while ($week == $dt->format('W'));  
                    ?>
                </tr>
                </thead>
                <tbody>
                    <tr>
                    <?php
                    $number = 0;
                    $timeslots = timeslots($duration, $cleanup, $start, $end);
                    foreach ($timeslots as $ts){
                    ?>
                        <th><?php echo $ts; ?></th>
                    
                    <?php
//                    echo "<tr>";
                     $dayofweek = date('w', strtotime($date->format('d-m-Y')));
                     $day = 1;
                        for ($i = 1; $i <= 7; $i++){
                            
                            $result = date('d-m-Y', strtotime(($day - $dayofweek).' day', strtotime($date->format('d-m-Y'))));
                            
                            $start1 = array($ts[0], $ts[1], $ts[2], $ts[3], $ts[4]);
                            $startTime = implode("", $start1); // combine array to string
                            $end1 = array($ts[10], $ts[11], $ts[12], $ts[13], $ts[14]);
                            $endTime = implode("", $end1);
                            $startEnd = array($ts[0], $ts[1], $ts[2], $ts[3], $ts[4], $ts[5], $ts[6], $ts[7], 
                                $ts[8], $ts[9], $ts[10], $ts[11], $ts[12], $ts[13], $ts[14], $ts[15], $ts[16]);
                            $startEnd1 = implode("", $startEnd);
                        
                            $sqlTime = "SELECT * FROM timeslots WHERE startTime = '$startTime' "
                                    . "AND endTime = '$endTime'";
                            $timeResult = mysqli_query($dbc, $sqlTime);
                            if(mysqli_num_rows($timeResult) == 1){
                            $rowtime = mysqli_fetch_array($timeResult, MYSQLI_ASSOC);
                                $sTime = $rowtime['startTime'];
                                $eTime = $rowtime['endTime'];
                                $timeID = $rowtime['timeID'];
                                $confirm1 = date('H:ia', strtotime($sTime)) . " - " . date('H:ia', strtotime($eTime));
                            
                                if ($confirm1 == $startEnd1){
                                    $sql = "SELECT BookDate, BookStartTime, BookEndTime, BookStatus, timeID "
                                          . "FROM booking "
                                          . "WHERE timeID = '$timeID'AND BookType='Repair Grip' AND BookDate='$result' "
                                            . "AND BookStartTime='$startTime' AND BookEndTime='$endTime'";
                                    $bookingResult = mysqli_query($dbc, $sql);
                                    if(mysqli_num_rows($bookingResult) == 1){
                                        $row = mysqli_fetch_array($bookingResult, MYSQLI_ASSOC);
                                        $BookStartTime = $row['BookStartTime'];
                                        $BookEndTime = $row['BookEndTime'];
                                        $confirm = date('H:ia', strtotime($row['BookStartTime'])) . " - " 
                                        . date('H:ia', strtotime($row['BookEndTime']));

                                        if ($confirm1 == $confirm){
                                            if ($row['BookDate'] == $result && $row['BookStatus'] == 'Booked'){
                                                echo "<td style='background-color: #88E0EF;'>Booked</td>";
                                            }
                                            elseif ($row['BookDate'] == $result && $row['BookStatus'] == 'Not Available'){
                                                echo "<td style='background-color: #A8383B;'>Not Available</td>";
                                            }
                                        }
                                     } 
                                     else{
                                         if (strtotime(date("d-m-Y")) > strtotime('-11 months') 
                                                 && strtotime(date("d-m-Y")) > strtotime($result)){
                                                echo "<td style='background-color: #A8383B;'>Not Available</td>";
                                         }
                                         else{
                                             echo "<form action='BookingGServiceForm.php' method='POST'>";
                                             echo "<td>"
                                             . "<input type='hidden' value='" . $result . "' class='bookdate' name='bookdate' id='bookdate'>"
                                             . "<input type='hidden' value='" . $startTime . "' class='bookstarttime' name='bookstarttime' id='bookstarttime'>"
                                             . "<input type='hidden' value='" . $endTime . "' class='bookendtime' name='bookendtime' id='bookendtime'>"
                                             . "<input type='submit' name='submitdetail' value='Available'>"
                                             . "</td>";
                                             echo "</form>";
                                         }
                                     }
                                    } // end if $confirm1 == $confirm
                                } // end if mysqli_num_rows($timeResult) == 1
                                $day++;
                             } // end for loop
                             echo "<tr></tr>";
                           } // foreach ($timeslots as $ts)
                          ?>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>
<br><br><br><br><br><br>
<?php
mysqli_close($dbc);
include ('include/footer.php');
?>