<?php
if (!isset($_COOKIE['MID'])) {
    require ('function/MLogin_function.php');
    redirect_user();
} 
else {
    setcookie ('MID','',time()-3600,'/','',0,0);
    setcookie ('MName','',time()-3600,'/','',0,0);
    setcookie ('MGender','',time()-3600,'/','',0,0);
    setcookie ('MBirthDate','',time()-3600,'/','',0,0);
    setcookie ('MPhoneNo','',time()-3600,'/','',0,0);
    setcookie ('MAddress','',time()-3600,'/','',0,0);
    setcookie ('MEmailAddress','',time()-3600,'/','',0,0);
    setcookie ('MUsername','',time()-3600,'/','',0,0);
}
//require ('mysqli_connect.php');
//$MID = $_COOKIE['MID'];
//$SID = $_COOKIE['SID'];
//$sql = "DELETE FROM messages WHERE (FromUser='$MID' AND ToUser='$SID') OR "
//        . "(FromUser='$SID' AND ToUser='$MID');";
//mysqli_query($dbc, $sql);
include ('homepage.php');
echo '<script language="javascript">';
echo 'alert("Log Out Success !")';
echo '</script>';

exit();
?>