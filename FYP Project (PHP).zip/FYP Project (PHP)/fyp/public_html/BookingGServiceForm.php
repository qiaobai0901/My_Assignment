<link rel="stylesheet" href="BRSSFCSS.css">
<style>
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }

</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<h1>Booking Repair Grip Service Form</h1>
<form action="BookRGripServiceFormAction.php" method="POST">
    <div class="form-group">
        <b><label for="name" style="padding-right: 20px;">Full Name : </label>
            <input type="text" name="name" placeholder="Please enter full name" required autofocus></b>
    </div>
    <div class="form-group" style="padding-left: 57px;">
        <label style="padding-right: 33px;">Gender : </label>
                <label class="radio-inline" style="padding-right: 30px;">
                    <input type="radio" name="gender" 
                           value="Male">Male
                </label>
                <label class="radio-inline" style="padding-right: 30px;">
                    <input type="radio" name="gender" 
                           value="Female" checked>Female
                </label>
        </div>
    <div class="form-group" style="padding-right: 5px;">
        <b><label for="tel" style="padding-right:20px;">Phone No. : </label>
            <input type="tel" name="phoneno" placeholder="eg. 0123456789" pattern="[0-9]{10}" required></b>
    </div>
    <div class="form-group" style="padding-right: 42px;">
        <b><label for="email" style="padding-right:20px;">Email Address : </label>
        <input type="text" name="email" placeholder="eg. panda6@gmail.com" 
               pattern="[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required></b>
    </div>
    <div class="form-group" style="padding-left: 135px;">
        <b><label style="padding-right: 26px;">Service Type : </label></b>
        <label class="radio-inline" style="padding-right: 30px;">
            <input type="radio" name="ST" value="Repair Grip" checked="">Repair Grip
        </label>
        <label class="radio-inline" style="padding-right: 30px;">
            <input type="radio" name="ST" value="Repair Stringing" disabled="">Repair Stringing
        </label>
    </div>
    <div class="form-group" style="padding-right: 88px;">
        <b><label>Booking Date : </label></b>
        <input type="text" name="date" placeholder="dd-mm-yyyy" value="<?php echo $_POST['bookdate']; ?>"
               readonly="" style="background-color: #dee0e6; width: 100px;">
    </div>
    <div class="form-group" style="padding-right: 140px;">
        <b><label>Booking Start Time : </label></b>
        <input type="time" name="startTime" value="<?php echo $_POST['bookstarttime'];?>" 
               readonly="" style="background-color: #dee0e6;">
    </div>
    <div class="form-group" style="padding-right: 140px;">
        <b><label>Booking End Time : </label></b>
        <input type="time" name="endTime" value="<?php echo $_POST['bookendtime'];?>" readonly="" 
               style="background-color: #dee0e6;">
    </div>
    <div class="form-group">
        <button type="submit" name="submit">Submit</button>
    </div>
</form>
<?php
//mysqli_close($dbc);
?>