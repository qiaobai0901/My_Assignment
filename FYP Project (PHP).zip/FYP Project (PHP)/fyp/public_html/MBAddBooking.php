<?php
include ('include/header.php');
$MID1= "";
$MID = "";
$MName = "";
$MPhoneNo = "";
$MEmailAddress = "";
   
  require ('mysqli_connect.php');
  if(isset($_COOKIE['MID'])) {
      
    $search_query = "SELECT * FROM member WHERE MID = '".$_COOKIE['MID']."'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $MID1 = $rows['MID'];
                        $MName = $rows['MName'];
                        $MPhoneNo = $rows['MPhoneNo']; 
                        $MEmailAddress = $rows['MEmailAddress'];
                        
                      
                    }
                    
                   
                }
            }
  

if(isset($_POST['submit'])){

    if ($_POST['BookDate'] < date("Y-m-d")){
        echo '<div class="alert" style="background-color: orrange; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Date was Expired</strong><br> 
                                                 Dear, you need to choose available date<br></div>';
    
    }else{
        $BookDate = $_POST['BookDate'];
        $starttime = $_POST['BookStartTime'];
        $endtime = $_POST['BookEndTime'];
        $CourtID = $_POST['CourtID'];
        $MID = $_POST['MID'];
       
        $query = "SELECT * FROM `booking` WHERE CourtID = '$CourtID' AND `BookDate` ='$BookDate' AND BookStartTime  >= '$starttime' AND BookEndTime <= '$endtime'";
        $result = mysqli_query($dbc, $query);

        $checkrows= mysqli_num_rows($result);
           
        if($checkrows>0) {
            
      echo '<div class="alert" style="background-color: #FFBC97; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Already Existed</strong><br> 
                                                 Dear, you need to choose another court, date or time. <br>
                                                 
                                          </div>';
   } else { 
        
        $stmt = mysqli_prepare($dbc, "SELECT BookID FROM booking ORDER BY BookID DESC LIMIT 1;");
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $i = 1;
        while ($r = mysqli_fetch_array($res)) {
            $o = preg_replace('/[^0-9]/', '', $r['BookID']); //php get only numbers from string
            $an = $o + $i;
            $id = str_pad($an, 6, "B0000", STR_PAD_LEFT); // combine int and string
        }

        $m = mysqli_connect('localhost', 'root', '', 'fyp');
        $stmt = mysqli_prepare($m, "INSERT INTO booking(BookID, BookType, BookDate, BookStartTime, BookEndTime, "
                . "BookStatus, timeID,MID,CourtID)VALUES(?,'Badminton',?,?,?,'Booked','',?,?)");
        mysqli_stmt_bind_param($stmt, 'sssssi', $id, $BookDate, $starttime, $endtime,$MID, $CourtID);

        mysqli_stmt_execute($stmt);

        mysqli_stmt_close($stmt);
        mysqli_close($m);
  
echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Booking Successfull !!!</strong> 
                             </div>';
   
}
}
  }
}else{
echo '<div class="alert" style="padding: 10px; color: white;
                                      margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                      <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                      <strong>Not Sign in !!!</strong> Please sign in first ! 
                                   </div>';
}
?>


    <div class="regform"><h2> Booking </h2></div>
<div class="main">
    <form class="form" action="MBAddBooking.php" method="post">
            <div class="form-group">
                           <form  class="form-container">
                               <div class="form-group">
                                   <br>
                                   <label for="">Court No</label>
                                   <select class="CourtID" name="CourtID">
                                       <option value="1">1</option>
                                       <option value="2">2</option>
                                       <option value="3">3</option>
                                       <option value="4">4</option>
                                       <option value="5">5</option>
                                       <option value="6">6</option>
                                       <option value="7">7</option>
                                       <option value="8">8</option>


                                   </select>
                               </div><br>
                               <div class="form-group">
                                   <label class="stlabel">Book Date:</label>
                                   <input type="date" name="BookDate" value="" min="2000-01-01" max="2100-12-31" required>
                                    </div>
                                    <label class="stlabel">Start Time:</label>
                                    <input type="time" id="BookStartTime" name="BookStartTime" min="00:00:00" max="22:00:00" required>&nbsp;&nbsp;&nbsp;
                                    <label class="timelabel">End Time:</label>
                                    <input type="time" id="BookEndTime" name="BookEndTime" required><br>
                                </div>
            <div class="form-group">
                <!--<label class="lastlabel1">Member ID:</label>-->
                <input type="hidden" name="MID" value="<?php echo $MID1;?> "><br>

                <label class="lastlabel1">Name:</label>
                <label><?php echo $MName; ?></label><br><br>
                <label class="lastlabel1">Contact No:</label>
                <label><?php echo $MPhoneNo; ?></label><br><br>
                <label class="">Email Address:</label>
                <label><?php echo $MEmailAddress; ?></label><br><br>
            </div>

                                <div class="form-group pull-right">
                                    <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>


    <style>

        body{
            background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
            background-attachment: fixed;
            background-size: 100% 100%;
            background-repeat: no-repeat;
            width: 100%;
        }
        .regform{

            width: 500px;
            background-color: black;
            margin: auto;
            color: #ffffff;
            padding:10px 0px 10px 0px;
            text-align: center;

        }

        .main{

            background-color: #343a40;
            width: 500px;
            margin: auto;
            height: 600px;
            border-radius: 15px 15px 15px 15px;
            text-align: center;


        }


        #name{
            height:100px ;
            width: 100%;

        }

        .form-group{
            color: skyblue;
            font-family: inherit;
            font-size: 20px;


        }

        .contact{
            height: 120px;
            width: 100%;
            outline: none;
            border: none;
            color: gray;
            background-color: black;
            padding: 10px;
        }

        </style>
        <style>
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<?php

include('include/footer.php');

?>