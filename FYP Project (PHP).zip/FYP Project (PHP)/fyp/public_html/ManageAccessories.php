<?php
$page_title = 'Manage Accessories For Booking';
require('mysqli_connect.php');
ob_end_clean();
include('include/Sheader.php'); // need change to staff header
// delete booking details
if (isset($_POST['delete'])){
    $bid = $_POST['BookID'];
    $aid = $_POST['AID'];
    $bookedqty = $_POST['BookedQty'];
    
    $sql = "SELECT AQty FROM accessories WHERE AID = '$aid';";
    $result = mysqli_query($dbc, $sql) 
            or trigger_error("\n\nQuery: $sql\n<br/>MySQL Error: ".mysqli_error($dbc));
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
        $aqty = $row['AQty'];
        $aqty += $bookedqty;
    } 
    
    $update = mysqli_prepare($dbc, "UPDATE accessories SET AQty='$aqty' WHERE AID = '$aid';");
    mysqli_stmt_execute($update);
    
    $delete = mysqli_prepare($dbc, "DELETE FROM bookaccessories WHERE BookID='$bid'");
    mysqli_stmt_execute($delete);;
    
    $delete2 = mysqli_prepare($dbc, "DELETE FROM booking WHERE BookID='$bid'");
    mysqli_stmt_execute($delete2);
    if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
        echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Successful !!!</strong> Delete ' . $bid . ' from database successfully !
              </div>';
    }
    else{
        echo '<div class="alert" style="padding: 10px; color: white; 
                margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Unsuccessful !!!</strong> Please try again !
              </div>';
    }
} // end if for isset()
?>
<!-- icon -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<script type="text/javascript">
    //popup window code
    function PopupEditAccessoriesForm(path){
        popupWindow = window.open(path, 'popUpWindow','height=500,width=500,left=520,top=150,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
    }
//    function PopupSignUp(path){
//        popupWindow = window.open(path, 'popUpWindow','height=900,width=700,left=460,top=20,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
//    }
</script>
<style>
    body{
        background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: white;
        font-weight: bolder;
    }

    table, th, td {
      border: 2px solid rgb(217, 179, 140, 0.2);
      border-collapse: collapse;
      background-color: rgb(0, 102, 204, 0.3);
    }
    th{
        padding-left: 10px;
        padding-right: 10px;
        padding-bottom: 5px;
        padding-top: 5px;
    }
    td{
        padding-left: 10px;
        padding-right: 10px;
        padding-bottom: 5px;
        padding-top: 5px;
    }
    .col {
        padding-left: 10px;
        padding-right: 30px;
    }
    i {
        padding-left: 5px;
        padding-right: 5px;
    }
    div {
        margin-left: 10px;
        margin-bottom: 20px;
    }
    .col2 {
        padding-left: 30px;
        padding-right: 30px;
    }
    a {
        color: white;
    }
    a:hover{
        color: #A2D2FF;
    }
    /* no style for button */
    button {
        background: transparent;
        box-shadow: 0px 0px 0px transparent;
        border: 0px solid transparent;
        text-shadow: 0px 0px 0px transparent;
        color: white;
    }
    button:hover {
        background: transparent;
        box-shadow: 0px 0px 0px transparent;
        border: 0px solid transparent;
        text-shadow: 0px 0px 0px transparent;
        color: #A2D2FF;
    }
    /* The alert message box */
    .alert {
        padding: 10px;
        background-color: #f25555; /* Red */
        color: white;
        margin-bottom: 15px;
        opacity: 1;
        transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
        margin-left: 5px;
        color: white;
        font-weight: bold;
        float: right;
        font-size: 15px;
        line-height: 20px;
        cursor: pointer;
        transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
        color: black;
    }
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
</script>
<div class="col2">
    <br><br><br>
    <h1><b> Accessories Service Management</b></h1>
    <h4>manage all type of accessories</h4>
    <form action=" " method="POST">
        <table>
            <?php 
            $q = "SELECT a.AID, a.AName, a.AQty, b.BookID, b.BookDate, 
                ba.ATotalQty, ba.ATotalPrice, m.MName, MEmailAddress
                FROM accessories a, bookaccessories ba, booking b, member m 
                WHERE a.AID = ba.AID AND ba.BookID = b.BookID AND ba.UserID = m.MID;";
            $stmt = mysqli_prepare($dbc, $q) 
                    or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            ?>
            <thead>
                <tr>
                    <th scope="col">Accessories ID</th>
                    <th scope="col" style="width: 25%; text-align: left;">Accessories Name</th>
                    <th scope="col" style="width: 6%; text-align: left;">Book ID</th>
                    <th scope="col" style="width: 8%; text-align: left;">Booked Date</th>
                    <th scope="col" style="text-align: left;">Booked Qty</th>
                    <th scope="col" style="width: 10%; text-align: left;">Total Price</th>
                    <th scope="col" style="width: 20%; text-align: left;">Member Name</th>
                    <th scope="col" style="width: 20%; text-align: left;">Member Email</th>
                    <th scope="col" style="width: 13%; text-align: center;">Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    echo "<tr>"
                        . "<th scope=\"row\"><center>{$row['AID']}</center></th>"
                        . "<td>{$row['AName']}</td>"
                        . "<td>{$row['BookID']}</td>"
                        . "<td>{$row['BookDate']}</td>"
                        . "<td>{$row['ATotalQty']}</td>"
                        . "<td>{$row['ATotalPrice']}</td>"
                        . "<td>{$row['MName']}</td>"
                        . "<td>{$row['MEmailAddress']}</td>"
                        . "<td>
                            <center>
                                 <a href=\"ServiceAccessories.php\"><i class=\"bi bi-plus-circle\" aria-hidden=\"true\" ></i></a>
                                 <a href=\"JavaScript:PopupForgetPassword('SEditAccessoriesForm.php');\"><i class=\"bi bi-pencil-square\"></i></a>
                                 <button type=\"submit\" name=\"delete\"><i class=\"bi bi-x-circle\"></i></button>
                             </center>
                           </td>
                           <input type=\"hidden\" name=\"BookID\" value=\"{$row['BookID']}\">
                           <input type=\"hidden\" name=\"AID\" value=\"{$row['AID']}\">
                           <input type=\"hidden\" name=\"BookedQty\" value=\"{$row['ATotalQty']}\">
                              </tr>"; 
                }
                mysqli_close($dbc);
                ?>
            </tbody>
        </table>
    </form>
</div>