<?php // need edit , havent add total price
require('mysqli_connect.php');
ob_end_clean();

//if (isset($_COOKIE['SID'])){
// echo $_COOKIE['SID'];
//}
//if ($_SERVER["REQUEST_METHOD"] == "POST") {
//    $getname = $_POST['name'];
//    $getgender = $_POST['gender'];
//    $getphoneno = $_POST['phoneno'];
//    $getemail = $_POST['email'];
//    $getservicetype = $_POST['ST'];
//    $getbookDate = $_POST['date'];
//    $getbookStartTime = $_POST['startTime'];
//    $getbookEndTime = $_POST['endTime'];
//    
//    if (!preg_match("/^[a-zA-Z-' ]*$/", $getname)) {
//        echo '<div class="alert">
//                     <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
//                     <strong>Only letters and white space allowed !!!</strong> Please enter again !
//               </div>';
//    }
//    else{
//        $name = mysqli_real_escape_string($dbc, $getname);
//    }
//    $gender = mysqli_real_escape_string($dbc, $getgender);
//     if(!preg_match("/^[0-9]{10}$/", $getphoneno)) {
//         echo '<div class="alert">
//                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
//                   <strong>Error !!!</strong> Please enter again ! eg. phone
//                </div>';
//     }
//     else{
//         $phoneno = mysqli_real_escape_string($dbc, $getphoneno);
//     }
//     if (!filter_var($getemail, FILTER_VALIDATE_EMAIL)) {
//         echo '<div class="alert">
//                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
//                  <strong>Invalid email format !!!</strong> Please enter a valid email address !
//                </div>';
//     }
//     else{
//         $email = mysqli_real_escape_string($dbc, $getemail);
//     }
//     $serviceType = mysqli_real_escape_string($dbc, $getservicetype);
//     $bookDate = mysqli_real_escape_string($dbc, date("d-m-Y", strtotime($getbookDate)));
//     $bookStartTime = mysqli_real_escape_string($dbc, $getbookStartTime);
//     $bookEndTime = mysqli_real_escape_string($dbc, $getbookEndTime);
//     
//     if($name && $gender && $phoneno && $email 
//             && $serviceType && $bookDate && $bookStartTime && $bookEndTime){ // IF ALL OK
//     $sql = "SELECT * "
//           . "FROM booking "
//           . "WHERE BookType = '$serviceType' AND BookDate = '$bookDate'"
//           . "AND BookStartTime = '$bookStartTime' AND BookEndTime = '$bookEndTime'";
//     $result = mysqli_query($dbc, $sql) 
//             or trigger_error("\n\nQuery: $sql\n<br />MySQL Error: ".mysqli_error($dbc));
//        if (mysqli_num_rows($result) == 0) {
//            $stmt = mysqli_prepare($dbc,"SELECT BookID FROM booking ORDER BY BookID DESC LIMIT 1;");
//            mysqli_stmt_execute($stmt);
//            $res = mysqli_stmt_get_result($stmt);
//            $i = 1;
//            while($r = mysqli_fetch_array($res)){
//                $o = preg_replace('/[^0-9]/', '', $r['BookID']); //php get only numbers from string
//                $an = $o + $i;
//                $id = str_pad($an, 6, "B0000", STR_PAD_LEFT); // combine int and string
//            }
//            $stmt2 = mysqli_prepare($dbc,"SELECT timeID FROM timeslots WHERE startTime = '$bookStartTime' "
//                    . "AND endTime = '$bookEndTime';");
//            mysqli_stmt_execute($stmt2);
//            $res2 = mysqli_stmt_get_result($stmt2);
//            while($r2 = mysqli_fetch_array($res2)){
//                $timeID = $r2['timeID'];
//            }
//            
//            // Insert the booking details to the database:
//            $q = "INSERT INTO booking (BookID, BookType, BookDate, BookStartTime, BookEndTime, "
//                    . "BookStatus, timeID) "
//                    . "VALUES ('$id', '$serviceType', '$bookDate', '$bookStartTime', '$bookEndTime', "
//                    . "'Booked', '$timeID')";
//            $rq = mysqli_query($dbc, $q) 
//                    or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
//            // get serviceID
//            $stmt3 = mysqli_prepare($dbc,"SELECT ServiceID FROM service WHERE ServiceType = '$serviceType'");
//            mysqli_stmt_execute($stmt3);
//            $res3 = mysqli_stmt_get_result($stmt3);
//            while($r3 = mysqli_fetch_array($res3)){
//                $serviceID = $r3['ServiceID'];
//            }
//            // Insert the booker details to the database:
//            $q = "INSERT INTO bookservice (BookID, ServiceID, bookerName, bookerGender, bookerPhoneNo, "
//                    . "bookerEmailAddress) "
//                    . "VALUES ('$id', '$serviceID', '$name', '$gender', '$phoneno', '$email')";
//            $rq2 = mysqli_query($dbc, $q) 
//                    or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
//            if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
//                echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
//                             margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
//                             <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
//                             <strong>Booking Successful !!!</strong> Thank you for Booking !
//                       </div>';
//             }
//             else{
//                echo '<div class="alert" style="padding: 10px; color: white; 
//                             margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
//                             <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
//                             <strong>Not Successful !!!</strong> Please try again !
//                       </div>'; 
//             }
//        } // end if (mysqli_num_rows($result) == 0)
//        else { 
//            echo '<div class="alert" style="padding: 10px; color: white; 
//                                margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
//                            <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
//                            <strong>Exist in database !!!</strong>  
//                            Please select the date, start time and end time that you want book again !
//                      </div>';
//        }
//     } // ALL user entered is ok
//} // end if $_server['request_method']

?>
<link rel="stylesheet" href="BRSSFCSS.css">
<style>
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }

</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<h1>Booking Repair Stringing Service Form</h1>
<form action=" BookingSServiceFormAction.php" method="POST">
    <div class="form-group">
        <b><label for="name" style="padding-right: 20px;">Full Name : </label>
            <input type="text" name="name" placeholder="Please enter full name" required autofocus></b>
    </div>
    <div class="form-group" style="padding-left: 57px;">
        <label style="padding-right: 33px;">Gender : </label>
        <b>
            <label class="radio-inline" style="padding-right: 30px;">
                <input type="radio" name="gender" value="Male">Male
            </label>
            <label class="radio-inline" style="padding-right: 30px;">
                <input type="radio" name="gender" value="Female" checked>Female
            </label>
        </b>
    </div>
    <div class="form-group" style="padding-right: 5px;">
        <b><label for="tel" style="padding-right:20px;">Phone No. : </label>
            <input type="tel" name="phoneno" placeholder="eg. 0123456789" pattern="[0-9]{10}" required></b>
    </div>
    <div class="form-group" style="padding-right: 42px;">
        <b><label for="email" style="padding-right:20px;">Email Address : </label>
        <input type="text" name="email" placeholder="eg. panda6@gmail.com" 
               pattern="[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required></b>
    </div>
    <div class="form-group" style="padding-left: 135px;">
        <b><label style="padding-right: 26px;">Service Type : </label></b>
        <label class="radio-inline" style="padding-right: 30px;">
            <input type="radio" name="ST" value="Repair Grip" disabled="">Repair Grip
        </label>
        <label class="radio-inline" style="padding-right: 30px;">
            <input type="radio" name="ST" value="Repair Stringing" checked="">Repair Stringing
        </label>
    </div>
    <div class="form-group" style="padding-right: 88px;">
        <b><label>Booking Date : </label></b>
        <input type="text" name="date" placeholder="dd-mm-yyyy" value="<?php echo $_POST['bookdate']; ?>"
               readonly="" style="background-color: #dee0e6; width: 100px;">
    </div>
    <div class="form-group" style="padding-right: 140px;">
        <b><label>Booking Start Time : </label></b>
        <input type="time" name="startTime" value="<?php echo $_POST['bookstarttime'];?>" 
               readonly="" style="background-color: #dee0e6;">
    </div>
    <div class="form-group" style="padding-right: 140px;">
        <b><label>Booking End Time : </label></b>
        <input type="time" name="endTime" value="<?php echo $_POST['bookendtime'];?>" readonly="" 
               style="background-color: #dee0e6;">
    </div>
    <div class="form-group">
        <button type="submit" name="submit">Submit</button>
    </div>
</form>
<?php
mysqli_close($dbc);
?>