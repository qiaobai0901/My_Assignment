<?php 
$page_title = 'Staff Profile';
include('include/Sheader.php');
?>
<link rel="stylesheet" href="StaffProfileCSS.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<style>
    body{
        background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: white;
        font-weight: bolder;
        text-align: center;
    }
    img {
        border-radius: 500px;
        width: 130%;
        height: 130%;
        display: flex;
    }
    center {
        padding-top: 38px;
    }

    *{
        box-sizing: border-box;
    }
    /* Float two columns side by side */
    .col2 {
        float: left;
        width: 30%;
        padding-left: 30px;
        padding-top: 30px;
        display: flex;
    }
    .col3 {
        float: left;
        padding-left: 50px;
        padding-top: 30px;
    }
    /* Remove extra left and right margins, due to padding in columns */
    .row {
        /* margin: 0 -5px;*/
        padding-left: 50px;
    }
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    /* Style the counter cards */
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
      padding: 16px;
      text-align: center;
      background-color: rgb(41, 82, 163, 0.8); /*rgb(?, ?, ?, opacity); */
      border-radius: 60px;
      width: 30%;
    }
    /* Style of card body */
    .card-body {
        padding-top: 38px;
        padding-bottom: 38px;
    }
    .form-group {
        padding-top: 16px;
        padding-bottom: 16px;
    }

    /* For icon space */
    i {
        padding-right: 16px;
    }

    /* Responsive columns - one column layout (vertical) on small screens */
    @media screen and (max-width: 600px) {
      .column {
        width: 100%;
        display: block;
        margin-bottom: 20px;
      }
    }
</style>
<center>
    <div class="col">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col2">
                        <img class="card-img-top" src="pic/S.png" alt="User Profile Pic">
                    </div>
                    <div class="col3">
                        <?php
                          if(isset($_COOKIE['SID'])){
                              echo "<h2><b>{$_COOKIE['SUsername']}</b></h2>"
                                   . "<h4>{$_COOKIE['SEmailAddress']}</h4>";
                           }
                        ?>
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <a href="SChangePassword.php" class="btn btn-primary"><i class='fas fa-user-cog'></i> Account Settings </a>
                    </div>
                    <div class="form-group">
                        <a href="SChangePassword.php" class="btn btn-primary"><i class="fa fa-lock"></i> Change Password</a>
                    </div>
                    <div class="form-group">
                        <a href="SLogout.php" style="padding-left: 55px; padding-right: 55px;" class="btn btn-primary"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</center>