<?php
//include('includes/header.html');
if (isset($_COOKIE['MID'])){
    $MID = $_COOKIE['MID'];
    $query = "SELECT MID FROM member WHERE MID='$MID';";
    $result = mysqli_query($dbc, $query) or trigger_error("\n\nQuery: $query\n<br />MySQL Error: ".mysqli_error($dbc));
    if (mysqli_num_rows($result) == 1) {
//        $row = mysqli_fetch_array($result);
//        $memberID = $row['MID'];
        require ('mysqli_connect.php');
        ob_end_clean();
        $Total =0;
        // Add products into the cart table
        if (isset($_GET['myid'])) {
            $aid = $_GET['myid'];
            $qty = $_POST['quantity'];
            $date = $_POST['date'];
        //    echo "<p>" . $aid . "</p>";
        //    echo "<p>" . $qty . "</p>";
        //    echo "<p>" . $date . "</p>";
            $stmt = mysqli_prepare($dbc, "SELECT * FROM accessories WHERE AID LIKE '$aid';");
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $r = mysqli_fetch_array($res);
            $code = $r['AID'];
            $name = $r['AName'];
            $status = $r['AStatus'];
            $Aqty = $r['AQty'];
            $price = $r['APrice'];
            $type = "Accessories";

            $Total += number_format($Aqty * $price, 2);

            $stmt1 = mysqli_prepare($dbc, "SELECT BookID FROM booking ORDER BY BookID DESC LIMIT 1;");
            mysqli_stmt_execute($stmt1);
            $res1 = mysqli_stmt_get_result($stmt1);
            $i = 1;
            while($r1 = mysqli_fetch_array($res1)){
                $o = preg_replace('/[^0-9]/', '', $r1['BookID']); //php get only numbers from string
                $an = $o + $i;
                $id = str_pad($an, 6, "B0000", STR_PAD_LEFT); // combine int and string
            }
            $bookstatus = "Booked";

            if ($aid == $code) {
                $sql = "INSERT INTO booking (BookID, BookType, BookDate, BookStartTime, BookEndTime, BookStatus, timeID) "
                        . "VALUES (?,?,?,'','',?,'')";
                $stmt2 = mysqli_prepare($dbc, $sql);
                mysqli_stmt_bind_param($stmt2,'ssss',$id,$type,$date,$bookstatus);
                mysqli_stmt_execute($stmt2);

                $stmt3 = mysqli_prepare($dbc,"INSERT INTO bookaccessories (BookID,AID,ATotalQty,ATotalPrice,UserID) "
                        . "VALUES (?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt3,'ssdds',$id,$aid,$Aqty,$Total,$MID);
                mysqli_stmt_execute($stmt3);
                if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                    echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                               <strong>Booking Successful !!!</strong> Thank you for Booking !
                           </div>';
                    }
                    else{
                        echo '<div class="alert" style="padding: 10px; color: white; 
                                    margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                    <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                    <strong>Not Successful !!!</strong> Please try again !
                              </div>'; 
                    }
                }
        }
    } // END if (mysqli_num_rows($result) == 1)
} // sign in alreaady
elseif (isset($_COOKIE['SID'])){
    $MID = $_COOKIE['SID'];
    $query1 = "SELECT SID FROM staff WHERE SID='$SID';";
    $result1 = mysqli_query($dbc, $query1) or trigger_error("\n\nQuery: $query1\n<br />MySQL Error: ".mysqli_error($dbc));
    if (mysqli_num_rows($result1) == 1) {
//        $row = mysqli_fetch_array($result);
//        $memberID = $row['MID'];
        require ('mysqli_connect.php');
        ob_end_clean();
        $Total =0;
        // Add products into the cart table
        if (isset($_GET['myid'])) {
            $aid = $_GET['myid'];
            $qty = $_POST['quantity'];
            $date = $_POST['date'];
        //    echo "<p>" . $aid . "</p>";
        //    echo "<p>" . $qty . "</p>";
        //    echo "<p>" . $date . "</p>";
            $stmt = mysqli_prepare($dbc, "SELECT * FROM accessories WHERE AID LIKE '$aid';");
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $r = mysqli_fetch_array($res);
            $code = $r['AID'];
            $name = $r['AName'];
            $status = $r['AStatus'];
            $Aqty = $r['AQty'];
            $price = $r['APrice'];
            $type = "Accessories";

            $Total += number_format($Aqty * $price, 2);

            $stmt1 = mysqli_prepare($dbc, "SELECT BookID FROM booking ORDER BY BookID DESC LIMIT 1;");
            mysqli_stmt_execute($stmt1);
            $res1 = mysqli_stmt_get_result($stmt1);
            $i = 1;
            while($r1 = mysqli_fetch_array($res1)){
                $o = preg_replace('/[^0-9]/', '', $r1['BookID']); //php get only numbers from string
                $an = $o + $i;
                $id = str_pad($an, 6, "B0000", STR_PAD_LEFT); // combine int and string
            }
            $bookstatus = "Booked";

            if ($aid == $code) {
                $sql = "INSERT INTO booking (BookID, BookType, BookDate, BookStartTime, BookEndTime, BookStatus, timeID) "
                        . "VALUES (?,?,?,'','',?,'')";
                $stmt2 = mysqli_prepare($dbc, $sql);
                mysqli_stmt_bind_param($stmt2,'ssss',$id,$type,$date,$bookstatus);
                mysqli_stmt_execute($stmt2);

                $stmt3 = mysqli_prepare($dbc,"INSERT INTO bookaccessories (BookID,AID,ATotalQty,ATotalPrice,UserID) "
                        . "VALUES (?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt3,'ssdds',$id,$aid,$Aqty,$Total,$SID);
                mysqli_stmt_execute($stmt3);
                if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                    echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                               <strong>Booking Successful !!!</strong> Thank you for Booking !
                           </div>';
                    }
                    else{
                        echo '<div class="alert" style="padding: 10px; color: white; 
                                    margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                    <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                    <strong>Not Successful !!!</strong> Please try again !
                              </div>'; 
                    }
                }
        }
    } // END if (mysqli_num_rows($result) == 1)
}// sign in alreaady
else {
    echo '<div class="alert" style="padding: 10px; color: white; 
              margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
              <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
               <strong>Not Sign in !!!</strong> Please sign in first ! 
           </div>'; 
//    header("Location: demo.php");
}
//mysqli_close($dbc);
//include('includes/footer.html');
?>
<style>
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>