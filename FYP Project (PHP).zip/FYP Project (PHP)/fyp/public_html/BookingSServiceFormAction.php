<?php // need edit , havent add total price
require('mysqli_connect.php');
ob_end_clean();
//if (isset($_COOKIE['SID'])){
// echo $_COOKIE['SID'];
//}
//if (isset($_POST["submit"])) {
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $getname = $_POST['name'];
    $getgender = $_POST['gender'];
    $getphoneno = $_POST['phoneno'];
    $getemail = $_POST['email'];
    $getservicetype = $_POST['ST'];
    $getbookDate = $_POST['date'];
    $getbookStartTime = $_POST['startTime'];
    $getbookEndTime = $_POST['endTime'];
    
    if (!preg_match("/^[a-zA-Z-' ]*$/", $getname)) {
        echo '<div class="alert">
                     <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                     <strong>Only letters and white space allowed !!!</strong> Please enter again !
               </div>';
    }
    else{
        $name = mysqli_real_escape_string($dbc, $getname);
    }
    $gender = mysqli_real_escape_string($dbc, $getgender);
     if(!preg_match("/^[0-9]{10}$/", $getphoneno)) {
         echo '<div class="alert">
                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                   <strong>Error !!!</strong> Please enter again ! eg. phone
                </div>';
     }
     else{
         $phoneno = mysqli_real_escape_string($dbc, $getphoneno);
     }
     if (!filter_var($getemail, FILTER_VALIDATE_EMAIL)) {
         echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Invalid email format !!!</strong> Please enter a valid email address !
                </div>';
     }
     else{
         $email = mysqli_real_escape_string($dbc, $getemail);
     }
     $serviceType = mysqli_real_escape_string($dbc, $getservicetype);
     $bookDate = mysqli_real_escape_string($dbc, date("d-m-Y", strtotime($getbookDate)));
     $bookStartTime = mysqli_real_escape_string($dbc, $getbookStartTime);
     $bookEndTime = mysqli_real_escape_string($dbc, $getbookEndTime);
     
     if($name && $gender && $phoneno && $email 
             && $serviceType && $bookDate && $bookStartTime && $bookEndTime){ // IF ALL OK
     $sql = "SELECT * "
           . "FROM booking "
           . "WHERE BookType = '$serviceType' AND BookDate = '$bookDate'"
           . "AND BookStartTime = '$bookStartTime' AND BookEndTime = '$bookEndTime'";
     $result = mysqli_query($dbc, $sql) 
             or trigger_error("\n\nQuery: $sql\n<br />MySQL Error: ".mysqli_error($dbc));
        if (mysqli_num_rows($result) == 0) {
            $stmt = mysqli_prepare($dbc,"SELECT BookID FROM booking ORDER BY BookID DESC LIMIT 1;");
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $i = 1;
            while($r = mysqli_fetch_array($res)){
                $o = preg_replace('/[^0-9]/', '', $r['BookID']); //php get only numbers from string
                $an = $o + $i;
                $id = str_pad($an, 6, "B0000", STR_PAD_LEFT); // combine int and string
            }
            $stmt2 = mysqli_prepare($dbc,"SELECT timeID FROM timeslots WHERE startTime = '$bookStartTime' "
                    . "AND endTime = '$bookEndTime';");
            mysqli_stmt_execute($stmt2);
            $res2 = mysqli_stmt_get_result($stmt2);
            while($r2 = mysqli_fetch_array($res2)){
                $timeID = $r2['timeID'];
            }
            
            // Insert the booking details to the database:
            $q = "INSERT INTO booking (BookID, BookType, BookDate, BookStartTime, BookEndTime, "
                    . "BookStatus, timeID) "
                    . "VALUES ('$id', '$serviceType', '$bookDate', '$bookStartTime', '$bookEndTime', "
                    . "'Booked', '$timeID')";
            $rq = mysqli_query($dbc, $q) 
                    or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
            // get serviceID
            $stmt3 = mysqli_prepare($dbc,"SELECT ServiceID FROM service WHERE ServiceType = '$serviceType'");
            mysqli_stmt_execute($stmt3);
            $res3 = mysqli_stmt_get_result($stmt3);
            while($r3 = mysqli_fetch_array($res3)){
                $serviceID = $r3['ServiceID'];
            }
            // Insert the booker details to the database:
            $q = "INSERT INTO bookservice (BookID, ServiceID, bookerName, bookerGender, bookerPhoneNo, "
                    . "bookerEmailAddress) "
                    . "VALUES ('$id', '$serviceID', '$name', '$gender', '$phoneno', '$email')";
            $rq2 = mysqli_query($dbc, $q) 
                    or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
            if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                             margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                             <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                             <strong>Booking Successful !!!</strong> Thank you for Booking !
                       </div>';
             }
             else{
                echo '<div class="alert" style="padding: 10px; color: white; 
                             margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                             <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                             <strong>Not Successful !!!</strong> Please try again !
                       </div>'; 
             }
        } // end if (mysqli_num_rows($result) == 0)
        else { 
            echo '<div class="alert" style="padding: 10px; color: white; 
                                margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                            <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                            <strong>Exist in database !!!</strong>  
                            Please select the date, start time and end time that you want book again !
                      </div>';
        }
     } // ALL user entered is ok
} // end if $_server['request_method']

?>