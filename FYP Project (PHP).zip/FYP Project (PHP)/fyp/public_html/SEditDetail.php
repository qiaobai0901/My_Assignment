<?php
//define page title as Login
$page_title = 'Edit Member Details page';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
     // Database Connection. 
    require ('mysqli_connect.php');

    $SID = $_POST['SID'];
    $getphoneno = $_POST["phoneno"]; 
    $getaddress = $_POST["address"]; 
    $getemail = $_POST["email"];
    $getusername = $_POST["username"]; 

    // Need to verify all variable);
    $username = mysqli_real_escape_string($dbc, $getusername);
     if(!preg_match("/^[0-9]{10}$/", $getphoneno)) {
         echo '<div class="alert">
                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                   <strong>Error !!!</strong> Please enter again ! eg. phone
                </div>';
     }
     else{
         $phoneno = mysqli_real_escape_string($dbc, $getphoneno);
     }
     $address = mysqli_real_escape_string($dbc, $getaddress);
     if (!filter_var($getemail, FILTER_VALIDATE_EMAIL)) {
         echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Invalid email format !!!</strong> Please enter a valid email address !
                </div>';
     }
     else{
         $email = mysqli_real_escape_string($dbc, $getemail);
     }
     
     $query = "SELECT * FROM staff WHERE SID='$SID'";
     $result = mysqli_query($dbc, $query) or trigger_error("\n\nQuery: $query\n<br />MySQL Error: ".mysqli_error($dbc));
     if (mysqli_num_rows($result) == 1) {
         $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
         $id = $row['SID'];
         if($SID == $id){
             // Insert the staff details to the database:
             $q = "UPDATE staff SET SName='$name', SGender='$gender', SBirthDate='$birthdate',SPhoneNo='$phoneno',"
                        . " SAddress='$address', SEmailAddress='$email', SUsername='$username', SPassword='$pass' "
                        . "WHERE SID='$SID'";
             $rq = mysqli_query($dbc, $q) or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
             if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                 echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white;
                            margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                            <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                            <strong>Successful !!!</strong> Changed !
                        </div>';
                }
                header("Location: ManageStaffAccount.php");
//                mysqli_close($dbc);
////                include 'function/config.inc.php';
////                // Redirect the user:
////                $url = BASE_URL.'ManageStaffAccount.php';
////                // Define the URL.
////                ob_end_clean( ); // Delete the buffer.
////                header("Location: $url");
////                exit( ); // Quit the script.
            }
            else { // SID is not match.
                echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                          margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                         <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                         <strong>Not exist !!!</strong> Staff ID not exist !  
                      </div>';
                
            }
        } // end if for mysqli_num_rows($result) == 1
        
}// end if for $_server['request_method']
?>
<style>
    label, input, button, h1, textarea{
        color: lightblue; 
        font-size: 16px; 
        font-family: comic sans ms;
    }
    div {
        padding: 16px;
    }
    body {
        background-image: url('pic/background.jpg');
        background-size: 100% 100%;
        background-repeat: no-repeat;
        background-attachment: fixed;
        backdrop-filter: blur(5px);
    }
    small {
        color: lightskyblue;
        font-size: 12px; 
        font-family: comic sans ms;
    }
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }

    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<center>
    <h1 style="padding-top: 20px;">Edit Member Details</h1>
    <form action="SEditDetail.php" method="POST">
       <!-- Use this instead for the time being -->
        <div class="form-group">
            <b><label for="SID" style="padding-right: 20px;">Staff ID : </label>
                <input type="text" name="SID"  
                       style="color: black; border-radius: 10px; width: 280px; height: 40px;" 
                       class="form-control"
                       placeholder="Please enter need to edit staff ID" required autofocus></b>
        </div>
        <div class="form-group" style="padding-right: 25px;">
            <b><label for="tel" style="padding-right:20px;">Phone No. : </label>
                <input type="tel" name="phoneno" style="color: black; border-radius: 10px; 
                       width: 270px; height: 40px;" 
                       class="form-control"
                       placeholder="eg. 0123456789" pattern="[0-9]{10}" required></b>
        </div>
        <div class="form-group" style="padding-left: 65px;">
            <b><label for="address" style="padding-right:20px;">Address : </label>
                <textarea name="address" style="color: black; border-radius: 10px; width: 300px; height: 100px;" 
                          class="form-control"
                          placeholder="Please enter address" required></textarea></b>
        </div>
        <div class="form-group" style="padding-right: 40px;">
            <b><label for="email" style="padding-right:20px;">Email Address : </label>
            <input type="text" name="email" style="color: black; border-radius: 10px; width: 270px; height: 40px;" 
                   class="form-control"
                   placeholder="eg. panda6@gmail.com" pattern="[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required></b>
        </div>
        <div class="form-group" style="padding-left: 25px;">
            <b><label for="username" style="padding-right:20px;">Username : </label>
                <input type="text" name="username" style="color: black; border-radius: 10px; 
                       width: 270px; height: 40px;" class="form-control"
                       placeholder="Please enter username" required></b>
        </div>
        <div class="form-group">
            <button type="submit" name="save"
                    style="border-radius: 12px; padding: 5px 16px; background-color: #004d99; ">Save</button>
        </div>
    </form>
</center>