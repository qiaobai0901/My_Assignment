<?php
//require('mysqli_connect.php');

// Include necessary files and handle errors gracefully
try {
    include('../mysqli_connect.php'); // Adjust the path as necessary
} catch (Exception $e) {
    echo json_encode(['error' => 'Failed to include mysqli_connect.php']);
    exit();
}

// Fetch messages from the database
$query = "SELECT message, role FROM chatmessages ORDER BY created_at ASC";
$result = mysqli_query($dbc, $query);

if (!$result) {
    echo json_encode(['error' => 'Failed to fetch messages']);
    exit();
}

$messages = [];
while ($row = mysqli_fetch_assoc($result)) {
    $messages[] = $row;
}

mysqli_free_result($result);
mysqli_close($dbc);

echo json_encode($messages);

////////////////////////////////////////////
//$query = "SELECT message, role FROM chatmessages ORDER BY created_at ASC";
//$result = mysqli_query($dbc, $query);
//
//$messages = [];
//while ($row = mysqli_fetch_assoc($result)) {
//    $messages[] = $row;
//}
//
//mysqli_free_result($result);
//mysqli_close($dbc);
//
//echo json_encode($messages);
?>
