<br><br><br>
 <?php
    
function redirect_user($page = 'homepage.php') { //1. defining a new function

    $url = 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']);//2. Starting define URL

    // 4. Remove any trailing slashes:
    $url = rtrim($url, '/\\');

    // 5. Add the page:
    $url .= '/' . $page;

    // 6. Redirect the user:
    header("Location: $url");
    exit( ); // Quit the script.

} // End of redirect_user( ) function.

//-----------------7. Begin new function----------------------------
function check_login($dbc,$email= '',$pass= '') {
       $errors = array( ); // Initialize error array.
       // Validate the email address:
        if (empty($email)) {
            $errors[ ] = '<div class="alert">
                       <strong>Error !!!</strong> You forgot to enter your email address !
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span>
                   </div>';
        } else {
            $e = mysqli_real_escape_string($dbc, trim($email));
        }
        // Validate the password:e
        if (empty($pass)) {
            $errors[ ] = '<div class="alert">
                       <strong>Error !!!</strong> You forgot to enter your passwords !
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span>
                   </div>';
        } else {
            $p = mysqli_real_escape_string($dbc, trim($pass));
        }
        if (empty($errors)) { // If everything's OK.
            $q = "SELECT MID, MName, MGender, MBirthDate, MPhoneNo, MAddress, MEmailAddress, MUsername "
                . "FROM member WHERE MEmailAddress='$email' AND MPassword='$p'";
            $r = @mysqli_query ($dbc, $q);
            // Check the result:
            if (mysqli_num_rows($r) == 1) {
                // Fetch the record:
                $row = mysqli_fetch_array($r, MYSQLI_ASSOC);
                // Return true and the record:
                return array(true, $row);
            } 
            else { // Not a match!
                $errors[ ] = '<div class="alert">
                       <strong>Error !!!</strong> <br>Either the email and password entered do not match. '
                . '<br>Please enter again !
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span>
                   </div>';
            }
        } // End of empty($errors) IF.
    // Return false and the errors:
    return array(false, $errors);
} // End of check_login( ) function.
//no need closing tag ?>