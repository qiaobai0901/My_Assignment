<?php 
include('include/Sheader.php');
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "fyp";

$TID = "";
$TCategories = "";
$TDate = "";
$TTime = "";


mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try{
    $dbc = mysqli_connect($servername, $username, $password, $dbname);
    
} catch (MySQLi_Sql_Exception $ex) {
   echo("error in connecting");
}

 function getData()
{
    $data = array();
    $data[0] = $_POST['TID'];
//    $data[1] = $_POST['TCategories'];
    $data[2] = $_POST['TDate'];
    $data[3] = $_POST['TTime'];

    return $data;
    
}

//search
if(isset($_POST['search']))
{
    $info = getData();
    $search_query = "SELECT * FROM tournament WHERE TID = '$info[0]'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TID = $rows['TID'];
                        $TCategories = $rows['TCategories'];
                        $TDate = $rows['TDate'];
                        $TTime = $rows['TTime'];
                        
                    }
                }else
                {
                
                    echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>No Data are Available</strong></div>";
                }
                
            } else{
                echo("result error");
            }
}


if(isset($_POST['update'])){
    $info = getData();
    $update_query = "UPDATE `tournament` SET `TDate`='$info[2]',`TTime`='$info[3]' WHERE TID = '$info[0]'";
    try{
        $update_result = mysqli_query($dbc,$update_query);
        if($update_result){
            if(mysqli_affected_rows($dbc)>0){
                echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Data Updated !</strong> 
                             </div>';
            }else{
                echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>Data Not Updated</strong></div>";
            }
        }
    } catch (Exception $ex) {
        echo("error in update".$ex -> getMessage());

    }
}
?>

        
        
        
    <div class="main">
        
        <form id="myForm" action="STTour1-1.php" method="post">
             
            <div class="form-group"><br><br>

          <label for="TID">Tournament No:</label>

          <select class="TID" name="TID">
              <option value="<?php echo $TID; ?>"><?php echo $TID; ?></option>
              <option value="1.1">1.1</option>
              <option value="1.2">1.2</option>
              <option value="1.3">1.3</option>
              <option value="1.4">1.4</option>
              <option value="1.5">1.5</option>
              <option value="1.6">1.6</option>
              <option value="1.7">1.7</option>
              <option value="1.8">1.8</option>
              <option value="1.1.1">1.1.1</option>
              <option value="1.1.2">1.1.2</option>
              <option value="1.1.3">1.1.3</option>
              <option value="1.1.4">1.1.4</option>
              <option value="1.1.1.1">1.1.1.1</option>
              <option value="1.1.1.2">1.1.1.2</option>
             
              
            </select><br><br>

                <label class="firstlabel">Tournament Categories:</label>
                <label><?php echo $TCategories; ?></label><br><br>
                <label class="CN">Tournament Date:</label>
                <input  type="date" name="TDate" value="<?php echo $TDate; ?>"><br><br>
                <label class="time">Tournament Time:</label>
                <input  type="text" name="TTime" value="<?php echo $TTime; ?>"><br><br>
                
                
                <input type="submit" name="search" class="btn btn-info btn-md" value="Search">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           
                <input type="submit" name="update" class="btn btn-info btn-md" value="Update">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <button onclick="myFunction()" value="Reset">Reset</button>
                
            </div>
            <a href='STourShow1.php' class="btn btn-info btn-md" value="Cancel">Cancel</a>
                
   
            </form>
        
        </div>
    
    <script>
function myFunction() {
    document.getElementById("myForm").reset();
}
    </script>
    <style>
        
body {
  background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
    background-attachment: fixed;
    background-size: 100% 100%;
    background-repeat: no-repeat;
    width: 100%; 
}  

        .regform{
            
            width: 500px;
            background-color: transparent;
            margin: auto;
            color: #ffffff;
            padding:10px 0px 10px 0px;
            text-align: center;
            
        }
        
        .main{
            
            background-color: #343a40;
            width: 500px;
            margin: auto;
            height: 550px;
            border-radius: 15px 15px 15px 15px;
            text-align: center;
            

        }
        
        
        #name{
            height:100px ;
            width: 100%;
            
        }
        
        .form-group{
            color: skyblue;
            font-family: inherit;
            font-size: 20px;
            
            
        }

        .contact{
            height: 120px;
            width: 100%;
            outline: none;
            border: none;
            color: gray;
            background-color: black;
            padding: 10px;
        }

 </style>
 <style>
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
    </body>
</html>


