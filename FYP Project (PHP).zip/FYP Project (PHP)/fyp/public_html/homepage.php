<?php
// Include necessary files
include('include/header.php');
require('mysqli_connect.php');

session_start();

// Check for a $page_title value
if (!isset($page_title)) {
    $page_title = 'The Challenger Sports Centre';
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["message"])) {
//    $username = htmlspecia;chars($_POST["username"]);
    $message = htmlspecialchars($_POST["message"]);
    $role = htmlspecialchars($_POST["role"]);

    $query = "INSERT INTO chatmessages (message, role) VALUES (?, ?)";
    $stmt = mysqli_prepare($dbc, $query);
    mysqli_stmt_bind_param($stmt, "ss", $message, $role);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);

    echo "Message received: " . $message;
    exit();
    
//    $message = htmlspecialchars($_POST["message"]);
//    $role = htmlspecialchars($_POST["role"]);
//
//    $query = "INSERT INTO chatmessages (message, role) VALUES (?, ?)";
//    $stmt = mysqli_prepare($dbc, $query);
//    mysqli_stmt_bind_param($stmt, "ss", $message, $role);
//    mysqli_stmt_execute($stmt);
//    mysqli_stmt_close($stmt);
//
//    echo "Message received: " . $message;
//    exit();
}

// Assuming user role is stored in session
$_SESSION["role"] = "member"; // or "staff"

// Fetch messages from the database
$messages = [];
$query = "SELECT message, role FROM chatmessages ORDER BY created_at ASC";
$result = mysqli_query($dbc, $query);
while ($row = mysqli_fetch_assoc($result)) {
    $messages[] = $row;
}
mysqli_free_result($result);

//// Retrieve chat messages from the database
//$query = "SELECT user_name, message, timestamp FROM chat_messages ORDER BY timestamp DESC";
//$result = mysqli_query($dbc, $query);

//////////////////////////////////////////////////////////////
//if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["message"])) {
//    $message = htmlspecialchars($_POST["message"]);
//    $role = htmlspecialchars($_POST["role"]);
//
//    // Insert message into database
//    $query = "INSERT INTO chatmessages (message, role) VALUES (?, ?)";
//    $stmt = mysqli_prepare($dbc, $query);
//    mysqli_stmt_bind_param($stmt, "ss", $message, $role);
//    mysqli_stmt_execute($stmt);
//    mysqli_stmt_close($stmt);
//
//    echo "Message received: " . $message;
//    exit();
//}
//
//// Assuming user role is stored in session
//// $_SESSION["role"] should be set when the user logs in
//// For this example, let's assume it's set directly
//$_SESSION["role"] = "member"; // or "staff"
//
//// Fetch messages from the database
//$messages = [];
//$query = "SELECT message, role FROM chatmessages ORDER BY created_at ASC";
//$result = mysqli_query($dbc, $query);
//while ($row = mysqli_fetch_assoc($result)) {
//    $messages[] = $row;
//}
//mysqli_free_result($result);
?>

<section class="parallex py-5">
    <div class="container py-5" style="color:skyblue;">
        <div class="row py-3">
            <div class="col-lg-9">
                <h1>Badminton</h1>
                <p class="py-3">Online booking of badminton court is available!</p>
                <a href="MBadmintonCalendar.php"><button class="btn1 mr-1">BOOK NOW</button></a>
            </div>    
        </div>
    </div>
</section>

<div class="container">
    <div class="open-button" onclick="openForm()">
        <i class="bi bi-chat-fill" style="color: lightblue; font-size: 30px;"></i>
    </div>
    <div class="form-popup" id="myForm">
        <form action=" " method="POST" onsubmit="sendMessage(event)">
            <div class="container-fluid" style="padding-bottom: 0px;">
                <div class="row">
                    <div class="col-md-4" style="width: 100px; padding-right: 500px;">
                        <div class="modal-dialog" style="width: 1000px;">  <!-- chatbox background nothing -->
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h4>ChatBox</h4>
                                    <div class="close-button" onclick="closeForm()">
                                        <i class="bi bi-x-square-fill" style="color: lightblue; font-size: 30px;"></i>
                                    </div>
                                </div>
                                <div class="modal-body" id="msgBody" 
                                     style="height: 250px;">
                                    <!-- message body-->
                                    <div id="chatMessages" class="chat-messages">
                                         <!-- Message will appear here -->
                                         <?php 
                                         foreach ($messages as $msg) {
                                             $messageClass = $msg['role'] === 'staff' ? 'staff-message' : 'member-message';
                                             echo '<div class="' . $messageClass . '">' . htmlspecialchars($msg['message']) . '</div>';
                                         } 
                                         ?>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <textarea id="message" class="form-control" name="message" style="height: 70px; width: 500px;"></textarea>
                                    <input type="hidden" id="role" name="role" value="<?php echo $_SESSION['role']; ?>">
                                    <button type="submit" name="send" id="send" class="btn btn-primary" style="height: 70%;">Send</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div> <!-- End  div: container for chat box -->

<script>
    let chatRefreshInterval;

    function openForm() {
        document.getElementById("myForm").style.display = "block";
        fetchMessages();
        refreshChat();
    }

    function closeForm() {
        document.getElementById("myForm").style.display = "none";
        clearInterval(chatRefreshInterval);
    }

    function sendMessage(event) {
        event.preventDefault();

        const messageInput = document.getElementById("message");
        const roleInput = document.getElementById("role");
        const messageText = messageInput.value.trim();
        const userRole = roleInput.value;

        if (messageText === "") {
            return;
        }

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "homepage.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                messageInput.value = "";
                fetchMessages(); // Fetch new messages immediately after sending
            }
        };
        xhr.send("message=" + encodeURIComponent(messageText) + "&role=" + encodeURIComponent(userRole));
    }

    function refreshChat() {
        chatRefreshInterval = setInterval(fetchMessages, 5000);
    }

    function fetchMessages() {
        const xhr = new XMLHttpRequest();
        xhr.open("GET", "function/fetch_messages.php", true);
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                try {
                    const messages = JSON.parse(xhr.responseText);
                    const chatMessages = document.getElementById("chatMessages");
                    chatMessages.innerHTML = "";

                    if (messages.error) {
                        console.error(messages.error);
                        return;
                    }

                    messages.forEach(function(msg) {
                        const messageContainer = document.createElement("div");
                        messageContainer.className = msg.role === "staff" ? "staff-message" : "member-message";
                        messageContainer.innerText = msg.message;
                        chatMessages.appendChild(messageContainer);
                    });

                    chatMessages.scrollTop = chatMessages.scrollHeight;
                } catch (e) {
                    console.error("Failed to parse JSON response:", e);
                }
            }
        };
        xhr.send();
    }
//    function openForm() {
//        document.getElementById("myForm").style.display = "block";
//        fetchMessages();
////        refreshChat();
//    }
//
//    function closeForm() {
//        document.getElementById("myForm").style.display = "none";
////        clearInterval(chatRefreshInterval);
//    }
//
//    function sendMessage(event) {
//        event.preventDefault();
//
//        const messageInput = document.getElementById("message");
//        const roleInput = document.getElementById("role");
//        const messageText = messageInput.value.trim();
//        const userRole = roleInput.value;
//
//        if (messageText === "") {
//            return;
//        }
//
//        const xhr = new XMLHttpRequest();
//        xhr.open("POST", "homepage.php", true);
//        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
//        xhr.onreadystatechange = function () {
//            if (xhr.readyState === 4 && xhr.status === 200) {
//                messageInput.value = "";
//                fetchMessages(); // Fetch new messages immediately after sending
//            }
//        };
//        xhr.send("message=" + encodeURIComponent(messageText) + "&role=" + encodeURIComponent(userRole));
//    }
//
////    let chatRefreshInterval;
////
////    function refreshChat() {
////        chatRefreshInterval = setInterval(fetchMessages, 5000);
////    }
//
//function fetchMessages() {
//        const xhr = new XMLHttpRequest();
//        xhr.open("GET", "function/fetch_messages.php", true);
//        xhr.onreadystatechange = function () {
//            if (xhr.readyState === 4 && xhr.status === 200) {
//                try {
//                    const messages = JSON.parse(xhr.responseText);
//                    const chatMessages = document.getElementById("chatMessages");
//                    chatMessages.innerHTML = "";
//
//                    if (messages.error) {
//                        console.error(messages.error);
//                        return;
//                    }
//
//                    messages.forEach(function(msg) {
//                        const messageContainer = document.createElement("div");
//                        messageContainer.className = msg.role === "staff" ? "staff-message" : "member-message";
//                        messageContainer.innerText = msg.message;
//                        chatMessages.appendChild(messageContainer);
////                        const br = document.createElement("br");
////                        chatMessages.appendChild(br);
//                    });
//
//                    chatMessages.scrollTop = chatMessages.scrollHeight;
//                } catch (e) {
//                    console.error("Failed to parse JSON response:", e);
//                }
//            }
//        };
//        xhr.send();
//    }
//
////    function fetchMessages() {
////        const xhr = new XMLHttpRequest();
////        xhr.open("GET", "function/fetch_messages.php", true);
////        xhr.onreadystatechange = function () {
////            if (xhr.readyState === 4 && xhr.status === 200) {
////                const messages = JSON.parse(xhr.responseText);
////                const chatMessages = document.getElementById("chatMessages");
////                chatMessages.innerHTML = "";
////
////                messages.forEach(function(msg) {
////                    const messageContainer = document.createElement("div");
////                    messageContainer.className = msg.role === "staff" ? "staff-message" : "member-message";
////                    messageContainer.innerText = msg.message;
////                    chatMessages.appendChild(messageContainer);
//////                    chatMessages.appendChild(document.createElement("br"));
////                });
////
////                chatMessages.scrollTop = chatMessages.scrollHeight;
////            }
////        };
////        xhr.send();
////    }
//    
//    function reloadChat() {
//        fetchMessages(); // Fetch new a messages and update the chat box
//    }
//    
//     // Set the chat to reload every 5 seconds (5000 milliseconds)
//     setInterval(reloadChat, 5000);
</script>

<!--<script>
    function openForm() {
        document.getElementById("myForm").style.display = "block";
        refreshChat(); // Start refreshing the chat when the chat box is opened
    }

    function closeForm() {
        document.getElementById("myForm").style.display = "none";
        clearInterval(chatRefreshInterval); // Stop refreshing the chat when the chat box is closed
    }

    function sendMessage(event) {
        event.preventDefault();

        const messageInput = document.getElementById("message");
        const roleInput = document.getElementById("role");
        const messageText = messageInput.value.trim();
        const userRole = roleInput.value;

        if (messageText === "") {
            return; // Do not send empty messages
        }

        const messageContainer = document.createElement("div");
        messageContainer.className = userRole === "staff" ? "staff-message" : "member-message";
        messageContainer.innerText = messageText;

        const chatMessages = document.getElementById("chatMessages");
        chatMessages.appendChild(messageContainer);

        // Clear the message input field
        messageInput.value = "";

        // Scroll to the bottom of the chat messages
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Send the message to the server using AJAX
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "homepage.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log(xhr.responseText);
            }
        };
        xhr.send("message=" + encodeURIComponent(messageText) + "&role=" + encodeURIComponent(userRole));
    }

    let chatRefreshInterval;

    function refreshChat() {
        chatRefreshInterval = setInterval(function() {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_messages.php", true);
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    const messages = JSON.parse(xhr.responseText);
                    const chatMessages = document.getElementById("chatMessages");
                    chatMessages.innerHTML = ""; // Clear existing messages

                    messages.forEach(function(msg) {
                        const messageContainer = document.createElement("div");
                        messageContainer.className = msg.role === "staff" ? "staff-message" : "member-message";
                        messageContainer.innerText = msg.message;
                        chatMessages.appendChild(messageContainer);
                        chatMessages.appendChild(document.createElement("br"));
                    });

                    // Scroll to the bottom of the chat messages
                    chatMessages.scrollTop = chatMessages.scrollHeight;
                }
            };
            xhr.send();
        }, 5000); // Refresh every 5 seconds
    }
</script>-->

<!--<script>
    function openForm() {
        document.getElementById("myForm").style.display = "block";
    }

    function closeForm() {
        document.getElementById("myForm").style.display = "none";
    }
    
    function sendMessage(event) {
        event.preventDefault();

        const messageInput = document.getElementById("message");
        const roleInput = document.getElementById("role");
        const messageText = messageInput.value.trim();
        const userRole = roleInput.value;

        if (messageText === "") {
            return; // Do not send empty messages
        }

        const messageContainer = document.createElement("div");
        messageContainer.className = userRole === "staff" ? "staff-message" : "member-message";
        messageContainer.innerText = messageText;

        const chatMessages = document.getElementById("chatMessages");
        chatMessages.appendChild(messageContainer);

        // Clear the message input field
        messageInput.value = "";

        // Scroll to the bottom of the chat messages
        chatMessages.scrollTop = chatMessages.scrollHeight;

        // Send the message to the server using AJAX
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "homepage.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                console.log(xhr.responseText);
            }
        };
        xhr.send("message=" + encodeURIComponent(messageText) + "&role=" + encodeURIComponent(userRole));
    }
</script>-->

<style>
    *{
        padding: 0;
        margin: 0;
        box-sizing: border-box;
    }

    .bg-img{
        background-image: url('pic/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg');
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%; 
        font-weight: bolder;
    }

    .parallex{
        background: url('pic/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg');
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%; 
    }

    .parallex h1{
        font-size: 50px;
        font-weight: 300;

    }

    .parallex p{
        font-size: 40px;
        font-weight: 200;
        justify-content: center;
    }

    .btn1{
        height: 40px;
        width: 110px;
        background: transparent;
        border: 2px solid skyblue;
        color: skyblue;
        justify-content: center;
    }

    .btn2{
        height: 45px;
        width: 160px;
        background-color: black;
        color: white;
        outline: none;
        border: none;
        cursor: pointer;
        display: inline-block;
    }
    
     /* The popup chat - hidden by default */
    .form-popup {
        display: none;
        position: fixed;
        bottom: 190px;
        right: 50px;
        border: none;
        z-index: 9;
        margin-right: 60px;
        margin-bottom: -100px;
    }

    /* Add styles to the form container */
    .form-container {
        width: 300px;
        padding: 10px;
        background-color: #f1f1f1;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    /* Full-width textarea */
    .form-container textarea {
        width: 100%;
        padding: 10px;
        margin: 5px 0 10px 0;
        border: 1px solid #ccc;
        background: #fff;
        resize: none;
        border-radius: 10px;
    }

    /* When the textarea gets focus, do something */
    .form-container textarea:focus {
        background-color: #ddd;
        outline: none;
    }

    /* Style the submit button */
    .form-container .btn {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
        margin-bottom: 10px;
        border-radius: 10px;
    }

    /* Add a red background color to the cancel button */
    .form-container .btn.cancel {
        background-color: red;
        border-radius: 10px;
    }

    /* Style the chat messages */
    .chat-messages {
        height: 230px;
        overflow-y: scroll;
        overflow-x: hidden;
        padding: 5px;
        display: flex;
        flex-direction: column;
        background: #fff;
        border: 1px solid #ccc;
        border-radius: 10px;
    }
    
    .chat-messages .message-container {
        display: flex;
        margin-bottom: 10px;
    }
    
    .chat-messages .staff-message {
        background-color: pink;
        text-align: left;
        align-self: flex-start;
        padding: 10px;
        border-radius: 10px;
        max-width: 60%;
        margin-bottom: 10px;
    }

    .chat-messages .member-message {
        background-color: lightblue;
        text-align: left;
        align-self: flex-end;
        padding: 10px;
        border-radius: 10px;
        max-width: 60%;
        margin-bottom: 10px;
    }

    .contact{
        outline: none;
        border: none;
        color: gray;
        background-color: black;
        padding: 10px;
    }
    
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: -15px;
      /*<!-- Alert message--> */
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }

    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 25px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }

    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>

<?php
mysqli_close($dbc);
include('include/footer.php');
?>
