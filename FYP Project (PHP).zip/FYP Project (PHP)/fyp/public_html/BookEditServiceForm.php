<?php // done 
require('mysqli_connect.php');
ob_end_clean();
if (isset($_COOKIE['SID'])){
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //    require('mysqli_connect.php');
        $bookid = $_POST['ID'];
        $getname = $_POST['name'];
        $getgender = $_POST['gender'];
        $getphoneno = $_POST['phoneno'];
        $getemail = $_POST['email'];
        $getservicetype = $_POST['ST'];
        $getbookDate = $_POST['date'];
        $getbookStartTime = $_POST['startTime'];
        $getbookEndTime = $_POST['endTime'];

        if (!preg_match("/^[a-zA-Z-' ]*$/", $getname)) {
            echo '<div class="alert">
                         <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                         <strong>Only letters and white space allowed !!!</strong> Please enter again !
                   </div>';
        }
        else{
            $name = mysqli_real_escape_string($dbc, $getname);
        }
        $gender = mysqli_real_escape_string($dbc, $getgender);
         if(!preg_match("/^[0-9]{10}$/", $getphoneno)) {
             echo '<div class="alert">
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                       <strong>Error !!!</strong> Please enter again ! eg. phone
                    </div>';
         }
         else{
             $phoneno = mysqli_real_escape_string($dbc, $getphoneno);
         }
         if (!filter_var($getemail, FILTER_VALIDATE_EMAIL)) {
             echo '<div class="alert">
                      <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                      <strong>Invalid email format !!!</strong> Please enter a valid email address !
                    </div>';
         }
         else{
             $email = mysqli_real_escape_string($dbc, $getemail);
         }
         $serviceType = mysqli_real_escape_string($dbc, $getservicetype);
         $bookDate = mysqli_real_escape_string($dbc, date("d-m-Y", strtotime($getbookDate)));
         $bookStartTime = mysqli_real_escape_string($dbc, $getbookStartTime);
         $bookEndTime = mysqli_real_escape_string($dbc, $getbookEndTime);
         $ID = mysqli_real_escape_string($dbc, $bookid);

         if($ID && $name && $gender && $phoneno && $email 
                 && $serviceType && $bookDate && $bookStartTime && $bookEndTime){ // IF ALL OK
             $sql = "SELECT b.BookID, t.timeID, s.ServiceID "
                     . "FROM timeslots t, booking b, bookservice bs, service s "
                     . "WHERE t.timeID = b.timeID AND b.BookID = bs.BookID AND bs.ServiceID = s.ServiceID "
                     . "AND b.BookID = '$ID'";
             $result = mysqli_query($dbc, $sql) or trigger_error("\n\nQuery: $sql\n<br/>MySQL Error: ".mysqli_error($dbc));
             if (mysqli_num_rows($result) == 1) {
                 $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                 $id = $row['BookID'];
                 $tID = $row['timeID'];
                 $sID = $row['ServiceID'];
                 if($ID == $id){
                     // Update the booking details to the database:
                     $q = "UPDATE booking SET BookType='$serviceType', BookDate='$bookDate', "
                             . "BookStartTime='$bookStartTime', BookEndTime='$bookEndTime', timeID='$tID'"
                             . "WHERE BookID='$ID'";
                     $rq = mysqli_query($dbc, $q) 
                             or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
                     $q2 = "UPDATE bookservice SET bookerName='$name', bookerGender='$gender', "
                             . "bookerPhoneNo='$phoneno', bookerEmailAddress='$email'"
                             . "WHERE BookID='$ID' AND ServiceID='$sID'";
                     $rq2 = mysqli_query($dbc, $q2) 
                             or trigger_error("\n\nQuery: $q2\n<br/>MySQL Error: ".mysqli_error($dbc));

                     if (mysqli_affected_rows($dbc) == 1) { // If it insert OK
                         echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white;
                             margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                  <strong>Successful !!!</strong> Changed !
                               </div>';
                     }
                     else{
                         echo '<div class="alert" style="padding: 10px; color: white; 
                                      margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                      <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                      <strong>Not Successful !!!</strong> Please try again !
                                </div>'; 
                      }
                 } //  bookid same with database' book id
            } // end if for mysqli_num_rows($result) == 1
            else { 
                echo '<div class="alert" style="padding: 10px; color: white; 
                          margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                          <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                          <strong>Not Exist in database !!!</strong>  
                          Please enter the exist book ID !
                       </div>';
                }
         } // ALL user entered is ok
    } // end if $_server['request_method']
}
else {
    echo '<div class="alert" style="padding: 10px; color: white;
             margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
             <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
             <strong>Not Sign in !!!</strong> Please sign in first ! 
          </div>'; 
}

mysqli_close($dbc);
?>
<link rel="stylesheet" href="BRSSFCSS.css">
<style>
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<h1>Booking Repair Grip or Stringing Service Form</h1>
<form action="BookEditServiceForm.php" method="POST">
    <div class="form-group">
        <b><label for="ID" style="padding-right: 20px;">Book ID : </label>
            <input type="text" name="ID" placeholder="Please enter need to edit book ID" required autofocus></b>
    </div>
    <div class="form-group">
        <b><label for="name" style="padding-right: 20px;">Full Name : </label>
            <input type="text" name="name" placeholder="Please enter full name" required></b>
    </div>
    <div class="form-group" style="padding-left: 57px;">
        <b><label style="padding-right: 33px;">Gender : </label></b>
                <label class="radio-inline" style="padding-right: 30px;">
                    <input type="radio" name="gender" 
                           value="Male">Male
                </label>
                <label class="radio-inline" style="padding-right: 30px;">
                    <input type="radio" name="gender" 
                           value="Female" checked="">Female
                </label>
        </div>
    <div class="form-group" style="padding-right: 5px;">
        <b><label for="tel" style="padding-right:20px;">Phone No. : </label>
            <input type="tel" name="phoneno" placeholder="eg. 0123456789" pattern="[0-9]{10}" required></b>
    </div>
    <div class="form-group" style="padding-right: 42px;">
        <b><label for="email" style="padding-right:20px;">Email Address : </label>
        <input type="text" name="email" placeholder="eg. panda6@gmail.com" 
               pattern="[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required></b>
    </div>
    <div class="form-group" style="padding-left: 135px;">
        <b><label style="padding-right: 26px;">Service Type : </label></b>
        <label class="radio-inline" style="padding-right: 30px;">
            <input type="radio" name="ST" value="Repair Grip">Repair Grip
        </label>
        <label class="radio-inline" style="padding-right: 30px;">
            <input type="radio" name="ST" value="Repair Stringing" checked="">Repair Stringing
        </label>
    </div>
    <div class="form-group" style="padding-right: 110px;">
        <b><label>Booking Date : </label></b>
        <input type="date" name="date" placeholder="dd-mm-yyyy" value=""
        min="2000-01-01" max="2100-12-31" required="">
    </div>
    <div class="form-group" style="padding-right: 140px;">
        <b><label>Booking Start Time : </label></b>
        <input type="time" name="startTime" required="">
    </div>
    <div class="form-group" style="padding-right: 140px;">
        <b><label>Booking End Time : </label></b>
        <input type="time" name="endTime" required="">
    </div>
    <div class="form-group">
        <button type="submit" name="update">Update</button>
    </div>
</form>