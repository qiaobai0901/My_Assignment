<?php
include('include/Sheader.php');
$mysqli = new mysqli('localhost', 'root', '', 'fyp');
if (isset($_GET['date'])) {
    $date = $_GET['date'];
//    $stmt = $mysqli->prepare("select * from booking where BookDate = ?");
//    $stmt->bind_param('s', $date);
//    $booking = array();
//    if ($stmt->execute()) {
//        $result = $stmt->get_result();
//    }
}

echo '<center><h1 class="text-center"  style="font-size: 30px;">Booking Date: '.$_GET['date'].'</h1><hr></center>';
echo'
       <table class="center">
       <tbody>
        <th>Booking slot</th>
    ';
$mysqli = new mysqli('localhost', 'root', '', 'fyp');
             $que = "SELECT * FROM badmintoncourt";
             $re = $mysqli->query($que);
        while($ro = $re->fetch_array()){ 
            
           echo '<th style="color: white;">' . $ro['CourtName']  . '</th>';
         }

$mysqli = new mysqli('localhost', 'root', '', 'fyp');

$res = "SELECT    c.CourtID
                             , concat(p.start_time, ' - ', p.end_time) as slot
                             , m.MName
                             , m.MID
                             , v.BookDate
                        FROM badmintoncourt c 
                             CROSS JOIN 
                             bookingperiod p 
                             LEFT JOIN 
                             booking v ON c.CourtID = v.CourtID
                                               AND TIME(v.BookStartTime) < p.end_time
                                               AND TIME(v.BookEndTime) > p.start_time
                                               AND BookDate
                             LEFT JOIN member m USING (MID)
                        ORDER BY slot,v.CourtID";

 $result = $mysqli->query($res);

 $slots = [];
      while($r = $result->fetch_array()){
         $rows[]=$r;
        
      } 
      
// arrange results into an array
//if(is_array($res)){
foreach ($rows as $r) {
   
if (isset($slots[$r['slot']])) {
      $r['BookDate']==$date && $slots[$r['slot']][$r['CourtID']]= $r['MName'] ? "{$r['MID']}" : '';;   
    }else{
      $slots[$r['slot']] = array_fill_keys(range(1,8),'');// empty room array
}
}


// output array to table
foreach ($slots as $s => $courts) {

    echo "<tr><td>$s</td>";
    foreach ($courts as $member) {
        $cls = $member ? 'booked' : '';
        echo"<td class='$cls'>$member</td>";
    }
    echo "</tr>\n";
}


$mysqli->close();

 echo "</tbody></table>";
?>


          
         <center><a class="btn btn-info my-2 my-sm-0" href="MBManage.php">Manage</a></center>

<style type='text/css'>
    body{
            background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
            background-attachment: fixed;
            background-size: 100% 100%;
            background-repeat: no-repeat;
            width: 100%; 
            color: skyblue;
        }
        

    .table {
      
      margin: 0 auto;
      width: 500px;
      color: skyblue;
     
    }
    
    .empty {
        display: none;
    }

    /* Hide table headers (but not display: none;, for accessibility) */
    th {
      white-space: nowrap;
      border:1px solid skyblue;
      text-align: center;
      font-size: 24px;
      color: skyblue;
      
    }

    tr {
        border: 1px solid #ccc;
    }
    
    td {
        padding: 10px;
        white-space: nowrap;
        border:1px solid skyblue;
        text-align: right;
        color: #ccc;
        width:12px;
        font-size: 20px;

    }


    .center {
        margin-left: auto;
        margin-right: auto;
    }
    
    
    td.booked {
        background-color: skyblue;
        color: white
    }
    
</style>

