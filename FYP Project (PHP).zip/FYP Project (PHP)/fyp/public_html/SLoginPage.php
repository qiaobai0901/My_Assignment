<?php
include('include/header.php');
?>
<style>
    /* Center the avatar image inside this container */
    .imgcontainer {
      text-align: center;
      margin: 15px 0 20px 0;
    }
    /* Avatar image */
    img.avatar {
      width: 30%;
      border-radius: 25%;
    }
    .card{
        /* border-radius: 50px; */
        width: 500px;
        height: 500px;
        padding-top: 50px;
        padding-bottom: 150px;
        background-color: transparent;
        border: none;
    }
    label, input, button, a{
        color: lightblue; 
        font-size: 16px; 
        font-family: comic sans ms;
    }
    body {
        background-image: url('pic/background.jpg');
        background-size: 100% 100%;
        background-repeat: no-repeat;
        background-attachment: fixed;
        backdrop-filter: blur(5px);
    }
    /* The alert message box */
.alert {
  padding: 10px;
  background-color: #f25555; /* Red */
  color: white;
  margin-bottom: 15px;
  /*<!-- Alert message--> */
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}

/* The close button */
.closebtn {
  margin-left: 5px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 15px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

/* When moving the mouse over the close button */
.closebtn:hover {
  color: black;
}

.page-footer {
    
   position:absolute;
            bottom:0;
            width:100%;
     
}
</style>
<script type="text/javascript">
    //popup window code
    function PopupForgetPassword(path){
        popupWindow = window.open(path, 'popUpWindow','height=500,width=500,left=520,top=150,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
    }
    function PopupSignUp(path){
        popupWindow = window.open(path, 'popUpWindow','height=900,width=700,left=460,top=20,resizable=yes,scrollbars=yes,toolbar=yes,menubar=no,location=no,directories=no,status=yes')
    }
</script>
<script>
    $(function(){
        $('#eye').click(function(){
            if($(this).hasClass('fa-eye-slash')){
                $(this).removeClass('fa-eye-slash');
                $(this).addClass('fa-eye');
                $('#password').attr('type','text');
            }else{
                $(this).removeClass('fa-eye');
                $(this).addClass('fa-eye-slash');  
                $('#password').attr('type','password');
            }
        });
    });
</script>
<center>
<br><br>
<div class="bg-img"></div>
<div class="card">
    <?php
    if(isset($errors)&&!empty($errors)){
        foreach($errors as $msg){
            echo"$msg<br/>";
            }
     }
     ?>
    <div class="imgcontainer">
        <img src="pic/S.png" alt="Login" class="avatar">
    </div>
    <br><br>
    <form action="SLogin.php" method="POST">
    <div class="form-group">
        <b><label for="email" style="padding-right:5px;">Email &nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;</label>
            <input type="text" name="email" style="color: black; border-radius: 10px;" 
                   placeholder="Please enter email" required></b>
    </div>
    <br><br>
    <div class="form-group">
        <div class="input-group mb-2 mr-sm-2" style="width: 360px;">
            <b><label for="pass" style="padding-right:20px;">Password&nbsp;&nbsp; :&nbsp; </label></b>
            <input type="password" class="form-control" id="password" placeholder="Type Your Password" 
                   name="pass" style="border-radius: 20px;" required="">
            <div class="input-group-prepend">
                <div class="input-group-text" style="background-color: #F7F7F7; border: none; border-radius: 20px;">
                    <i class="fas fa-eye-slash" id="eye" style="color: #396EB0;"></i>
                </div>
            </div>
        </div>
    </div>
    <br><br>
    <button type="submit" name="submit" style="border-radius: 12px; padding: 5px 16px; background-color: #004d99;">Login</button>
    </form>
    <br><br>
    <div class="form-group">
        <a href="JavaScript:PopupForgetPassword('SForgetPassword.php');" style="padding-right: 66px; text-decoration: none;">Forget Password ?</a>
        <button style="border-radius: 12px; padding: 5px 16px; background-color: #004d99;">
            <a href="JavaScript:PopupSignUp('SSignUp.php');" style="text-decoration: none;">Sign up</a>
        </button>
    </div>
</div>

</center>
<?php
//include('include/footer.php');
?>