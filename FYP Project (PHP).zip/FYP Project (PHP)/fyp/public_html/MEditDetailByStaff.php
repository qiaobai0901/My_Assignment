<?php
//define page title as Login
$page_title = 'Edit Member Details page';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
     // Database Connection. 
    require ('mysqli_connect.php');

    $MID = $_POST['MID'];
    $getname = $_POST['name'];
    $getgender = $_POST["gender"]; 
    $getbirthdate = $_POST["birthdate"];
    $getphoneno = $_POST["phoneno"]; 
    $getaddress = $_POST["address"]; 
    $getemail = $_POST["email"];
    $getusername = $_POST["username"]; 
    $getpass = $_POST["pass"]; 
    $getpassc = $_POST["passc"];

    // Need to verify all variable
    if (!preg_match("/^[a-zA-Z-' ]*$/", $getname) || !preg_match("/^[0-9a-zA-Z-' ]*$/", $getusername)) {
        echo '<div class="alert">
                     <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                     <strong>Only letters and white space allowed !!!</strong> Please enter again !
               </div>';
    }
    else{
        $name = mysqli_real_escape_string($dbc, $getname);
        $username = mysqli_real_escape_string($dbc, $getusername);
    }
    $gender = mysqli_real_escape_string($dbc, $getgender);
    if (!preg_match("/\d{4}\-\d{2}-\d{2}/", $getbirthdate)) {
        echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Error !!!</strong> Please enter again ! eg. xx-xx-xxx 
               </div>';
     }
     else{
        $birthdate = mysqli_real_escape_string($dbc, $getbirthdate);
     }
     if(!preg_match("/^[0-9]{10}$/", $getphoneno)) {
         echo '<div class="alert">
                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                   <strong>Error !!!</strong> Please enter again ! eg. phone
                </div>';
     }
     else{
         $phoneno = mysqli_real_escape_string($dbc, $getphoneno);
     }
     $address = mysqli_real_escape_string($dbc, $getaddress);
     if (!filter_var($getemail, FILTER_VALIDATE_EMAIL)) {
         echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Invalid email format !!!</strong> Please enter a valid email address !
                </div>';
     }
     else{
         $email = mysqli_real_escape_string($dbc, $getemail);
     }
     if (!preg_match ('/^\w{4,20}$/', $getpass) || !preg_match ('/^\w{4,20}$/', $getpassc)) {
         echo '<div class="alert">
                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                   <strong>Invalid !!!</strong> Please enter a password containing uppercase letters, 
                   lowercase letters and numbers. !
               </div>';
     } 
     else{
        $pass = mysqli_real_escape_string($dbc, $getpass);
     }
       // Make sure the email address is available:
        $query = "SELECT * FROM member WHERE MID='$MID'";
        $result = mysqli_query($dbc, $query) or trigger_error("\n\nQuery: $query\n<br />MySQL Error: ".mysqli_error($dbc));
        if (mysqli_num_rows($result) == 1) {
            $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
            $id = $row['MID'];
            if($MID == $id){
//                 $hash = password_hash($password, PASSWORD_DEFAULT);
                 // Insert the staff details to the database:
                $q = "UPDATE member SET MName='$name', MGender='$gender', MBirthDate='$birthdate',"
                        . "MPhoneNo='$phoneno', MAddress='$address', MEmailAddress='$email', "
                        . "MUsername='$username', MPassword='$pass' WHERE MID='$MID'";
                $rq = mysqli_query($dbc, $q) or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
                if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                    echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white;
                        margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                             <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                             <strong>Successful !!!</strong> Changed !
                          </div>';
                }
           }
           else { // The staff ID not match from database.
               echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                         margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                        <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                        <strong>Not exist !!!</strong>   
                     </div>';
          }
       } // end if for mysqli_num_rows($result) == 1
}// end if for $_server['request_method']
?>
<style>
    label, input, button, h1, textarea{
        color: lightblue; 
        font-size: 16px; 
        font-family: comic sans ms;
    }
    div {
        padding: 16px;
    }
    body {
        background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
        background-size: 100% 100%;
        background-repeat: no-repeat;
        background-attachment: fixed;
        backdrop-filter: blur(5px);
    }
    small {
        color: lightskyblue;
        font-size: 12px; 
        font-family: comic sans ms;
    }
    /* The alert message box */
.alert {
  padding: 10px;
  background-color: #f25555; /* Red */
  color: white;
  margin-bottom: 15px;
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}

/* The close button */
.closebtn {
  margin-left: 5px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 15px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

/* When moving the mouse over the close button */
.closebtn:hover {
  color: black;
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<center>
    <h1 style="padding-top: 20px;">Edit Member Details</h1>
    <form action="SEditDetail.php" method="POST">
       <!-- Use this instead for the time being -->
        <div class="form-group">
            <b><label for="MID" style="padding-right: 20px;">Member ID : </label>
                <input type="text" name="MID"  
                       style="color: black; border-radius: 10px;" 
                       placeholder="Please enter need to edit member ID" required autofocus></b>
        </div>
       <!-- -->
        <div class="form-group">
            <b><label for="name" style="padding-right: 20px;">Full Name : </label>
                <input type="text" name="name"  
                       style="color: black; border-radius: 10px;" 
                       
                       placeholder="Please enter full name" required></b>
        </div>
        <div class="form-group">
            <b>
                <label style="padding-right: 33px;">Gender : </label>
                <label class="radio-inline" style="padding-right: 30px;">
                    <input type="radio" name="gender" 
                           value="Male">Male
                </label>
                <label class="radio-inline" style="padding-right: 30px;">
                    <input type="radio" name="gender" 
                           value="Female" checked>Female
                </label>
            </b>
        </div>
        <div class="form-group" style="padding-right: 77px;">
            <b><label for="date" style="padding-right: 20px;">Birth Date : </label>
                <input type="date" name="birthdate" 
                       
                       style="color: black; border-radius: 10px;" required></b>
        </div>
        <div class="form-group" style="padding-right: 25px;">
            <b><label for="tel" style="padding-right:20px;">Phone No. : </label>
                <input type="tel" name="phoneno" style="color: black; border-radius: 10px;" 
                       
                       placeholder="eg. 0123456789" pattern="[0-9]{10}" required></b>
        </div>
        <div class="form-group" style="padding-left: 93px;">
            <b><label for="address" style="padding-right:20px;">Address : </label>
                <textarea name="address" style="color: black; border-radius: 10px; width: 300px; height: 100px;" 
                          
                          placeholder="Please enter address" required></textarea></b>
        </div>
        <div class="form-group" style="padding-right: 70px;">
            <b><label for="email" style="padding-right:20px;">Email Address : </label>
            <input type="text" name="email" style="color: black; border-radius: 10px;" 
                   
                   placeholder="eg. panda6@gmail.com" pattern="[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required></b>
        </div>
        <div class="form-group" style="padding-left: 5px;">
            <b><label for="username" style="padding-right:20px;">Username : </label>
                <input type="text" name="username" style="color: black; border-radius: 10px;" 
                       
                       placeholder="Please enter username" required></b>
        </div>
        <div class="form-group" style="padding-left: 5px;">
            <b><label for="pass" style="padding-right:20px;">Password : </label>
                <input type="text" name="pass" style="color: black; border-radius: 10px;" 
                       
                       placeholder="Please enter passwords" required></b>
                <!--<br><b><small id="passwordHelpBlock" class="form-text text-muted">
                    Your password must be 8-20 characters long, contain letters and numbers,<br> and must not contain spaces, special characters, or emoji.
                </small></b>-->
        </div>
            <div class="form-group" style="padding-right: 96px;">
            <b><label for="passc" style="padding-right:20px;">Confirm Password : </label>
                <input type="text" name="passc" style="color: black; border-radius: 10px;" 
                       
                       placeholder="Please enter passwords again" required></b>
        </div>
        <div class="form-group">
            <button type="submit" name="save"
                    style="border-radius: 12px; padding: 5px 16px; background-color: #004d99; ">Save</button>
        </div>
    </form>
</center>