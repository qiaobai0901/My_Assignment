<?php // not done
require ('mysqli_connect.php');
ob_clean();
include ('include/header.php');
if (isset($_COOKIE['MID'])){
    $MID = $_COOKIE['MID'];
    $query = "SELECT MID FROM member WHERE MID='$MID';";
    $result = mysqli_query($dbc, $query) or trigger_error("\n\nQuery: $query\n<br />MySQL Error: ".mysqli_error($dbc));
    if (mysqli_num_rows($result) == 1) {
//        $row = mysqli_fetch_array($result);
//        $memberID = $row['MID'];
//        require ('mysqli_connect.php');
//        ob_end_clean();
        $Total =0;
        // Add products into the cart table
        if (isset($_GET['myid'])) {
            $aid = $_GET['myid'];
            $qty = $_POST['quantity'];
            $date = $_POST['date'];
        //    echo "<p>" . $aid . "</p>";
        //    echo "<p>" . $qty . "</p>";
        //    echo "<p>" . $date . "</p>";
            $stmt = mysqli_prepare($dbc, "SELECT * FROM accessories WHERE AID LIKE '$aid';");
            mysqli_stmt_execute($stmt);
            $res = mysqli_stmt_get_result($stmt);
            $r = mysqli_fetch_array($res);
            $code = $r['AID'];
            $name = $r['AName'];
            $status = $r['AStatus'];
            $Aqty = $r['AQty'];
            $price = $r['APrice'];
            $type = "Accessories";

            $Total += number_format($qty * $price, 2);
            $Aqty -= $qty;

            $stmt1 = mysqli_prepare($dbc, "SELECT BookID FROM booking ORDER BY BookID DESC LIMIT 1;");
            mysqli_stmt_execute($stmt1);
            $res1 = mysqli_stmt_get_result($stmt1);
            $i = 1;
            while($r1 = mysqli_fetch_array($res1)){
                $o = preg_replace('/[^0-9]/', '', $r1['BookID']); //php get only numbers from string
                $an = $o + $i;
                $id = str_pad($an, 6, "B0000", STR_PAD_LEFT); // combine int and string
            }
            $bookstatus = "Booked";

            if ($aid == $code) {
                $sql = "INSERT INTO booking (BookID, BookType, BookDate, BookStartTime, BookEndTime, BookStatus, timeID, MID, CourtID) "
                        . "VALUES (?,?,?,'','',?,'','','')";
                $stmt2 = mysqli_prepare($dbc, $sql);
                mysqli_stmt_bind_param($stmt2,'ssss',$id,$type,$date,$bookstatus);
                mysqli_stmt_execute($stmt2);

                $stmt3 = mysqli_prepare($dbc,"INSERT INTO bookaccessories (BookID,AID,ATotalQty,ATotalPrice,UserID) "
                        . "VALUES (?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt3,'ssdds',$id,$aid,$qty,$Total,$MID);
                mysqli_stmt_execute($stmt3);
                
                $sql8 = "UPDATE accessories SET AQty = '$Aqty' WHERE AID = '$aid';";
                $stmt8 = mysqli_prepare($dbc, $sql8);
                mysqli_stmt_execute($stmt8);
                
                if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                    echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                               <strong>Booking Successful !!!</strong> Thank you for Booking ! 
                           </div>';
                    }
                    else{
                        echo '<div class="alert" style="padding: 10px; color: white; 
                                    margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                    <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                    <strong>Not Successful !!!</strong> Please try again !
                              </div>'; 
                    }
                }
        }
    } // END if (mysqli_num_rows($result) == 1)
//    mysqli_close($dbc);
} // sign in alreaady
elseif (isset($_COOKIE['SID'])){
    $SID = $_COOKIE['SID'];
    $query1 = "SELECT SID FROM staff WHERE SID='$SID';";
    $result1 = mysqli_query($dbc, $query1) or trigger_error("\n\nQuery: $query1\n<br />MySQL Error: ".mysqli_error($dbc));
    if (mysqli_num_rows($result1) == 1) {
//        $row = mysqli_fetch_array($result);
//        $memberID = $row['MID'];
//        require ('mysqli_connect.php');
//        ob_end_clean();
        $Total2 =0;
        // Add products into the cart table
        if (isset($_GET['myid'])) {
            $aid1 = $_GET['myid'];
            $qty1 = $_POST['quantity'];
            $date1 = $_POST['date'];
//            echo "<p>" . $aid1 . "</p>";
//            echo "<p>" . $qty1 . "</p>";
//            echo "<p>" . $date1 . "</p>";
            $stmt4 = mysqli_prepare($dbc, "SELECT * FROM accessories WHERE AID LIKE '$aid1';");
            mysqli_stmt_execute($stmt4);
            $res2 = mysqli_stmt_get_result($stmt4);
            $r3= mysqli_fetch_array($res2);
            $code1 = $r3['AID'];
            $name1 = $r3['AName'];
            $status1 = $r3['AStatus'];
            $Aqty1 = $r3['AQty'];
            $price1 = $r3['APrice'];
            $type1 = "Accessories";

            $Total2 += number_format(($qty1 * $price1), 2);
            $Aqty1 -= $qty1;

            $stmt5 = mysqli_prepare($dbc, "SELECT BookID FROM booking ORDER BY BookID DESC LIMIT 1;");
            mysqli_stmt_execute($stmt5);
            $res3 = mysqli_stmt_get_result($stmt5);
            $i2 = 1;
            while($r4 = mysqli_fetch_array($res3)){
                $o1 = preg_replace('/[^0-9]/', '', $r4['BookID']); //php get only numbers from string
                $an1 = $o1 + $i2;
                $id1 = str_pad($an1, 6, "B0000", STR_PAD_LEFT); // combine int and string
            }
            $bookstatus1 = "Booked";

            if ($aid1 == $code1) {
                $sql = "INSERT INTO booking (BookID, BookType, BookDate, BookStartTime, BookEndTime, BookStatus, timeID, MID, CourtID) "
                        . "VALUES (?,?,?,'','',?,'','','')";
                $stmt6 = mysqli_prepare($dbc, $sql);
                mysqli_stmt_bind_param($stmt6,'ssss',$id1,$type1,$date1,$bookstatus1);
                mysqli_stmt_execute($stmt6);

                $stmt7 = mysqli_prepare($dbc,"INSERT INTO bookaccessories (BookID,AID,ATotalQty,ATotalPrice,UserID) "
                        . "VALUES (?,?,?,?,?)");
                mysqli_stmt_bind_param($stmt7,'ssdds',$id1,$aid1,$qty1,$Total2,$SID);
                mysqli_stmt_execute($stmt7);
                
                $sql9 = "UPDATE accessories SET AQty = '$Aqty1' WHERE AID = '$aid1';";
                $stmt9 = mysqli_prepare($dbc, $sql9);
                mysqli_stmt_execute($stmt9);
                
                if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                    echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                               <strong>Booking Successful !!!</strong> Thank you for Booking !
                           </div>';
                    }
                    else{
                        echo '<div class="alert" style="padding: 10px; color: white; 
                                    margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                    <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                    <strong>Not Successful !!!</strong> Please try again !
                              </div>'; 
                    }
                }
        }
    } // END if (mysqli_num_rows($result) == 1)
}// sign in alreaady
else {
    echo '<div class="alert" style="padding: 10px; color: white; 
              margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
              <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
               <strong>Not Sign in !!!</strong> Please sign in first ! 
           </div>'; 
//    header("Location: demo.php");
}
//mysqli_close($dbc);
?>
<!-- For icon -->
<!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.1/font/bootstrap-icons.css">-->
<!-- For add and minus -->
<script data-require="jquery@3.1.1" data-semver="3.1.1" src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
    function wcqib_refresh_quantity_increments() {
        jQuery("p.quantity:not(.buttons_added), td.quantity:not(.buttons_added)").each(function(a, b) {
            var c = jQuery(b);
            c.addClass("buttons_added"), c.children().first().before('<i class=\"bi bi-patch-minus-fill\" id=\"minus\" value=\"-\" class=\"minus\"></i>'), c.children().last().after('<i class=\"bi bi-patch-plus-fill\" id=\"plus\" value=\"+\" class=\"plus\"></i>')
        })
    }
    String.prototype.getDecimals || (String.prototype.getDecimals = function() {
        var a = this,
            b = ("" + a).match(/(?:\.(\d+))?(?:[eE]([+-]?\d+))?$/);
        return b ? Math.max(0, (b[1] ? b[1].length : 0) - (b[2] ? +b[2] : 0)) : 0
    }), jQuery(document).ready(function() {
        wcqib_refresh_quantity_increments()
    }), jQuery(document).on("updated_wc_div", function() {
        wcqib_refresh_quantity_increments()
    }), jQuery(document).on("click", ".plus, .minus", function() {
        var a = jQuery(this).closest(".quantity").find(".qty"),
            b = parseFloat(a.val()),
            c = parseFloat(a.attr("max")),
            d = parseFloat(a.attr("min")),
            e = a.attr("step");
        b && "" !== b && "NaN" !== b || (b = 0), "" !== c && "NaN" !== c || (c = ""), "" !== d && "NaN" !== d || (d = 0), "any" !== e && "" !== e && void 0 !== e && "NaN" !== parseFloat(e) || (e = 1), jQuery(this).is(".plus") ? c && b >= c ? a.val(c) : a.val((b + parseFloat(e)).toFixed(e.getDecimals())) : d && b <= d ? a.val(d) : b > 0 && a.val((b - parseFloat(e)).toFixed(e.getDecimals())), a.trigger("change")
    });
</script>
<style>
    body{
        background-image: url('pic/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg');
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: skyblue;
        font-weight: bolder;
    }
    h2 {
        margin-top: -5px;
    }
    h1, h2, h5 {
        text-align: center;
    }
    /*---  For Card ---*/
    *{
        box-sizing: border-box;
    }
    /* Float four columns side by side */
    .col {
        float: left;
        width: 20%;
        padding: 0 10px;
        margin-right: 15px;
        margin-left: 15px;
    }
    /* Remove extra left and right margins, due to padding in columns */
    .row {
        margin: 0 -5px;
        padding-top: 30px;
        padding-right: 100px;
    }
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    /* Style the counter cards */
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
      padding: 16px;
      text-align: center;
      background-color: rgb(41, 82, 163, 0.8); /*rgb(?, ?, ?, opacity); */
      border-radius: 60px;
      width: 330px;
    }
    .minus{
        color: skyblue;
    }
    .minus:hover{
        color: white;
    }
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }
    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<h1>Services</h1>
<h2>Accessories</h2>
    <?php
    $sql = "SELECT AID, AImage, AName, ADescription, AStatus, AQty, APrice FROM accessories ORDER BY AID ASC;";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    ?>
    <div class="row">
        <?php
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $id = $row['AID'];
        $img = $row['AImage'];
        $name = $row['AName'];
        $description = $row['ADescription'];
        $status = $row['AStatus'];
        $qty = $row['AQty'];
        $price = $row['APrice'];
        ?>
        <div class="col" style="padding-left: 50px;">
            <div class="card">
                <center>
                    <img class="card-img-top" src="<?= $img; ?>" alt="" 
                     style="width: 250px; height: 250px; padding-top: 15px; border-radius: 25px;">
                </center>
                <div class="card-body">
                    <h5 class="card-title"><?= $name; ?></h5>
                    <div class="card-text">
                        <ul style="text-align: left;">
                            <li><?= $description; ?></li>
                        </ul>
                    </div>
                    <p>Price : RM <?= $price; ?></p>
                    <p>Stock Status : <?= $status; ?></p>
                    <form action="ServiceAccessories.php?myid=<?php echo $id; ?>" method="POST">
                        <input type="hidden" class="AID" name="AID" id="AID" value="<?= $id ?>">
                        <input type="hidden" name="date" value="<?php echo date('d-m-Y'); ?>">
<!--                        <i class="bi bi-patch-plus-fill" id="plus"></i>-->
                    <?php 
                    if ($qty == 0){
                        echo "<p class=\"quantity buttons_added\"disabled>
                                 <input type=\"button\" value=\"-\" class=\"minus\" 
                                 style=\"border-radius: 100%; width: 30px; height: 30px; text-align: center; 
                                 background-color: skyblue; color: black; font-weight:bold; font-size: 15px;\" disabled>
                                 <input type=\"number\" step=\"1\" min=\"1\" max=\"\" name=\"quantity\" value=\"0\" 
                                   title=\"Qty\" class=\"input-text qty text\" size=\"4\" pattern=\"\" inputmode=\"\"
                                   style=\"width: 50px; border-radius: 12px; text-align: center;\" disabled>
                                 <input type=\"button\" value=\"+\" class=\"plus\"
                                 style=\"border-radius: 100%; width: 30px; height: 30px; text-align: center; 
                                 background-color: skyblue; color: black; font-weight:bold; font-size: 15px;\" disabled>
                              </p>";
                        echo "<p style=\"text-align: center; padding-top: 10px;\">"
                              . "<button class=\"btn btn-primary\" style=\"background-color: #DC143C;\">Book</button>"
                            . "</p>";
                    }
                    else{
                        if (isset($_COOKIE['MID'])){
                            echo "<p class=\"quantity buttons_added\">
                                     <input type=\"button\" value=\"-\" class=\"minus\" name=\"minus\"
                                     style=\"border-radius: 100%; width: 30px; height: 30px; text-align: center; 
                                     background-color: skyblue; color: black; font-weight:bold; font-size: 15px;\">
                                <input type=\"number\" step=\"1\" min=\"1\" max=\"30\" name=\"quantity\" value=\"1\" 
                                       title=\"Qty\" class=\"input-text qty text\" size=\"4\" pattern=\"\" inputmode=\"\"
                                       style=\"width: 50px; border-radius: 12px; text-align: center;\">
                                <input type=\"button\" value=\"+\" class=\"plus\" name=\"plus\"
                                style=\"border-radius: 100%; width: 30px; height: 30px; text-align: center; 
                                     background-color: skyblue; color: black; font-weight:bold; font-size: 15px;\">
                                  </p>";
                            echo "<p style=\"text-align: center; padding-top: 10px;\">"
                                  . "<button type=\"ServiceAccessories.php?myid=<?php echo $id; ?>\" "
                                    . "class=\"btn btn-primary\" name=\"add\">Book</button>"
                                . "</p>";
                            }
                            else {
                                echo "<p class=\"quantity buttons_added\"disabled>
                                     <input type=\"button\" value=\"-\" class=\"minus\" 
                                     style=\"border-radius: 100%; width: 30px; height: 30px; text-align: center; 
                                     background-color: skyblue; color: black; font-weight:bold; font-size: 15px;\" disabled>
                                     <input type=\"number\" step=\"1\" min=\"1\" max=\"\" name=\"quantity\" value=\"0\" 
                                       title=\"Qty\" class=\"input-text qty text\" size=\"4\" pattern=\"\" inputmode=\"\"
                                       style=\"width: 50px; border-radius: 12px; text-align: center;\" disabled>
                                     <input type=\"button\" value=\"+\" class=\"plus\"
                                     style=\"border-radius: 100%; width: 30px; height: 30px; text-align: center; 
                                     background-color: skyblue; color: black; font-weight:bold; font-size: 15px;\" disabled>
                                  </p>";
                            echo "<p style=\"text-align: center; padding-top: 10px;\">"
                                  . "<button class=\"btn btn-primary\" style=\"background-color: #DC143C;\">Book</button>"
                                . "</p>";
                            }
                    }
                    ?>
                    </form>
                </div>
            </div>
        </div>
        <?php
        }
        ?>
    </div>
<br><br><br>
 <?php
mysqli_close($dbc);
include ('include/footer.php');
 ?>