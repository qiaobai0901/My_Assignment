<?php
//define page title as Login
$page_title = 'Sign Up page';

// register config.inc.php to be used in this page
include('function/config.inc.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
     // Database Connection. 
    require ('mysqli_connect.php');
    $name = $gender = $birthdate = $phoneno = $address = $email = $username = $pass = FALSE;
    $getname = $_POST['name'];
    $getgender = $_POST["gender"]; 
    $getbirthdate = $_POST["birthdate"];
    $getphoneno = $_POST["phoneno"]; 
    $getaddress = $_POST["address"]; 
    $getemail = $_POST["email"];
    $getusername = $_POST["username"]; 
    $getpass = $_POST["pass"]; 
    $getpassc = $_POST["passc"];

    // Need to verify all variable
    if (!preg_match("/^[a-zA-Z-' ]*$/", $getname) || !preg_match("/^[a-zA-Z-' ]*$/", $getusername)) {
        echo '<div class="alert">
                     <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                     <strong>Only letters and white space allowed !!!</strong> Please enter again !
               </div>';
    }
    else{
        $name = mysqli_real_escape_string($dbc, $getname);
        $username = mysqli_real_escape_string($dbc, $getusername);
    }
    $gender = mysqli_real_escape_string($dbc, $getgender);
    if (!preg_match("/\d{4}\-\d{2}-\d{2}/", $getbirthdate)) {
        echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Error !!!</strong> Please enter again ! eg. xx-xx-xxx 
               </div>';
     }
     else{
        $birthdate = mysqli_real_escape_string($dbc, $getbirthdate);
     }
     if(!preg_match("/^[0-9]{10}$/", $getphoneno)) {
         echo '<div class="alert">
                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                   <strong>Error !!!</strong> Please enter again ! eg. phone
                </div>';
     }
     else{
         $phoneno = mysqli_real_escape_string($dbc, $getphoneno);
     }
     $address = mysqli_real_escape_string($dbc, $getaddress);
     if (!filter_var($getemail, FILTER_VALIDATE_EMAIL)) {
         echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Invalid email format !!!</strong> Please enter a valid email address !
                </div>';
     }
     else{
         $email = mysqli_real_escape_string($dbc, $getemail);
     }
     if (!preg_match ('/^\w{4,20}$/', $getpass) || !preg_match ('/^\w{4,20}$/', $getpassc)) {
         echo '<div class="alert">
                   <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                   <strong>Invalid !!!</strong> Please enter a password containing uppercase letters, 
                   lowercase letters and numbers. !
               </div>';
     } 
     else{
        $pass = mysqli_real_escape_string($dbc, $getpass);
     }
     if($name && $gender && $birthdate && $phoneno && $address && $email && $username && $pass){ // IF ALL OK
         // Make sure the email address is available:
        $query = "SELECT MEmailAddress, MUsername FROM member "
                . "WHERE MEmailAddress='$email'AND MUsername='$username'";
        $result = mysqli_query($dbc, $query) or trigger_error("\n\nQuery: $query\n<br />MySQL Error: ".mysqli_error($dbc));
        if (mysqli_num_rows($result) == 0) {
            if ($pass == $getpassc){
                $stmt = mysqli_prepare($dbc,"SELECT MID FROM member ORDER BY MID DESC LIMIT 1;");
                mysqli_stmt_execute($stmt);
                $res = mysqli_stmt_get_result($stmt);
                $i = 1;
                while($r = mysqli_fetch_array($res)){
                    $o = preg_replace('/[^0-9]/', '', $r['MID']); //php get only numbers from string
                    $an = $o + $i;
                    $id = str_pad($an, 6, "M0000", STR_PAD_LEFT); // combine int and string
                }
//                 $hash = password_hash($password, PASSWORD_DEFAULT);
                // Insert the staff details to the database:
                $q = "INSERT INTO member (MID, MName, MGender, MBirthDate, MPhoneNo, MAddress, MEmailAddress, "
            . "MUsername, MPassword) VALUES ('$id', '$name', '$gender', '$birthdate', '$phoneno', '$address', '$email', "
            . "'$username', '$pass')";
                $rq = mysqli_query($dbc, $q) or trigger_error("\n\nQuery: $q\n<br/>MySQL Error: ".mysqli_error($dbc));
                if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
                    echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                               <strong>Successful !!!</strong> Thank you for registering !
                           </div>';
                }
            }
            else { // The email address is not available.
                echo '<div class="alert" style="padding: 10px; color: white; 
                                margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                            <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                            <strong>Passwords not match !!!</strong>   Please enter again !
                      </div>';
            }
       }
        else { // The email address or username is not available.
                echo '<div class="alert" style="padding: 10px; color: white; 
                                margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                            <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                            <strong>Not available !!!</strong>   That email address or username has already been registered.
                      </div>';
            }
     } // END IF FOR ALL OK
} // END IF FOR $_SERVER['REQUEST_METHOD']
?>
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<style>
    label, input, button, h1, textarea{
        color: lightblue; 
        font-size: 16px; 
        font-family: comic sans ms;
    }
    div {
        padding: 16px;
    }
    body {
        background-image: url('pic/background.jpg');
        background-size: 100% 100%;
        background-repeat: no-repeat;
        background-attachment: fixed;
        backdrop-filter: blur(5px);
    }
    small {
        color: lightskyblue;
        font-size: 12px; 
        font-family: comic sans ms;
    }
    /* The alert message box */
    .alert {
        padding: 10px;
        background-color: #f25555; /* Red */
        color: white;
        margin-bottom: 15px;
    }
    /* The close button */
    .closebtn {
        margin-left: 5px;
        color: white;
        font-weight: bold;
        float: right;
        font-size: 15px;
        line-height: 20px;
        cursor: pointer;
        transition: 0.3s;
    }
    /* When moving the mouse over the close button */
    .closebtn:hover {
        color: black;
    }
</style>
<!-- Alert message-->
<style>
.alert {
  opacity: 1;
  transition: opacity 0.6s; /* 600ms to fade out */
}
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script type="text/javascript">
    $(function(){
        $('#eye1').click(function(){
            if($(this).hasClass('fa-eye-slash')){
                $(this).removeClass('fa-eye-slash');
                $(this).addClass('fa-eye');
                $('#pass').attr('type','text');
            }else{
                $(this).removeClass('fa-eye');
                $(this).addClass('fa-eye-slash');  
                $('#pass').attr('type','password');
            }
        });
    });
</script>
<script type="text/javascript">
    $(function(){
        $('#eye2').click(function(){
            if($(this).hasClass('fa-eye-slash')){
                $(this).removeClass('fa-eye-slash');
                $(this).addClass('fa-eye');
                $('#passc').attr('type','text');
            }else{
                $(this).removeClass('fa-eye');
                $(this).addClass('fa-eye-slash');  
                $('#passc').attr('type','password');
            }
        });
    });
</script>
<center>
    <h1 style="padding-top: 20px;">Sign Up Account</h1>
    <form action=" " method="POST">
       
        <div class="form-group">
            <b><label for="name" style="padding-right: 20px;">Full Name : </label>
                <input type="text" name="name"  
                       style="color: black; border-radius: 10px;" 
                       placeholder="Please enter full name" required autofocus></b>
        </div>
        <div class="form-group">
            <b>
                <label style="padding-right: 33px;">Gender : </label>
                <label class="radio-inline" style="padding-right: 30px;">
                    <input type="radio" name="gender" 
                           value="Male">Male
                </label>
                <label class="radio-inline" style="padding-right: 30px;">
                    <input type="radio" name="gender" 
                           value="Female" checked>Female
                </label>
            </b>
        </div>
        <div class="form-group" style="padding-right: 77px;">
            <b><label for="date" style="padding-right: 20px;">Birth Date : </label>
                <input type="date" name="birthdate" 
                       
                       style="color: black; border-radius: 10px;" required></b>
        </div>
        <div class="form-group" style="padding-right: 25px;">
            <b><label for="tel" style="padding-right:20px;">Phone No. : </label>
                <input type="tel" name="phoneno" style="color: black; border-radius: 10px;" 
                       
                       placeholder="eg. 0123456789" pattern="[0-9]{10}" required></b>
        </div>
        <div class="form-group" style="padding-left: 93px;">
            <b><label for="address" style="padding-right:20px;">Address : </label>
                <textarea name="address" style="color: black; border-radius: 10px; width: 300px; height: 100px;" 
                          
                          placeholder="Please enter address" required></textarea></b>
        </div>
        <div class="form-group" style="padding-right: 70px;">
            <b><label for="email" style="padding-right:20px;">Email Address : </label>
            <input type="text" name="email" style="color: black; border-radius: 10px;" 
                   
                   placeholder="eg. panda6@gmail.com" pattern="[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required></b>
        </div>
        <div class="form-group" style="padding-left: 5px;">
            <b><label for="username" style="padding-right:20px;">Username : </label>
                <input type="text" name="username" style="color: black; border-radius: 10px;" 
                       
                       placeholder="Please enter username" required></b>
        </div>
        <div class="form-group" style="padding-right: 70px;">
            <!--<div class="input-group mb-2 mr-sm-2" style="width: 100px;">-->
            <b><label for="pass" style="background-color: transparent;">Password&nbsp; : &nbsp;</label></b>
                <input type="password" id="pass" placeholder="Type Your New Password" 
                       name="pass" style="border-radius: 10px; color: black; width: 200px;" required="">
                <i class="fas fa-eye-slash" id="eye1" 
                           style="color: #396EB0; background-color: #F7F7F7;"></i>
                <!--<div class="input-group-prepend">-->
<!--                    <div class="input-group-text" 
                         style="background-color: #F7F7F7; border-radius: 100px; 
                         width: 6px; height: 6px; padding-left: 10px; padding-top: 10px;">
                        <i class="fas fa-eye-slash" id="eye1" 
                           style="color: #396EB0; background-color: #F7F7F7;"></i>
                    </div>-->
                <!--</div>-->
            <!--</div>-->
                <!--<br><b><small id="passwordHelpBlock" class="form-text text-muted">
                    Your password must be 8-20 characters long, contain letters and numbers,<br> and must not contain spaces, special characters, or emoji.
                </small></b>-->
        </div>
        <div class="form-group" style="padding-right: 150px;">
            <b><label>Confirm New Password :</label></b>
            <!--<div class="input-group mb-2 mr-sm-2" style="width: 100px;">-->
                <input type="password" class="form-control" id="passc" placeholder="Type Your New Password again" 
                       name="passc" style="border-radius: 10px; color: black;" required="">
                <!--<div class="input-group-prepend">-->
<!--                    <div class="input-group-text"
                         style="background-color: #F7F7F7; border: none; border-radius: 50px; width: 20px;">-->
                        <i class="fas fa-eye-slash" id="eye2" style="color: #396EB0; background-color: #F7F7F7;"></i>
                    <!--</div>-->
                <!--</div>-->
            <!--</div>-->
        </div>
        <div class="form-group">
            <button type="submit" name="submit"
                    style="border-radius: 12px; padding: 5px 16px; background-color: #004d99; ">Submit</button>
        </div>
    </form>
</center>

