<?php
include ('include/header.php');
//include ('function/footer.html');
?>
<style>
*{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}
    body{
        background-image: url('pic/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg');
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: skyblue;
        font-weight: bolder;
    }
    /*---  For Serivce ---*/
    *{
        box-sizing: border-box;
    }
    /* Float four columns side by side */
    .col {
        float: left;
        width: 30%;
        padding: 0 10px;
        margin-right: 100px;
        margin-left: 100px;
        padding-top: 30px;
    }
    /* Remove extra left and right margins, due to padding in columns */
    .row {
        /* margin: 0 -5px;*/
        padding-left: 50px;
    }
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    /* Style the counter cards */
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
      padding: 16px;
      text-align: center;
      background-color: rgb(41, 82, 163, 0.8); /*rgb(?, ?, ?, opacity); */
      border-radius: 60px;
    }
    /* Responsive columns - one column layout (vertical) on small screens */
    @media screen and (max-width: 600px) {
      .column {
        width: 100%;
        display: block;
        margin-bottom: 20px;
      }
    }
    h1,h3{
        text-align: center;
    }
</style>    
<br><br><br>
<h1>Service</h1>
<h3>Choose the service you want</h3>
<div>
<div class="row">
    <div class="col">
        <div class="card">
            <center>
                <img class="card-img-top" src="pic/ServiceHomeAccessories.png" alt="" 
                     style="width: 300px; height: 300px; padding: 5px; border-radius: 25px;">
            </center>
            <div class="card-body">
                <div class="card-title"><b style="font-size: 20px;">Accessories Service</b></div>
                <div class="card-text">
                    <p style="text-align: left;">Our spare parts service is to allow customers to order their 
                        favorite parts to repair their damaged parts. 
                        Therefore, we only provide two kinds of accessories at present.</p>
                </div>
            </div>
            <div class="card-footer">
                <p style="text-align: center;"><a href="ServiceAccessories.php" class="btn btn-primary">Go</a></p>
                <!--<p style="text-align: center;"><a href="demo.php" class="btn btn-primary">Go</a></p>-->
            </div>
        </div>
    </div>
    <div class="col">
        <div class="card">
            <center>
                <img class="card-img-top" src="pic/ServiceHomeRepair.jpg" alt="" 
                     style="width: 300px; height: 300px; padding: 5px; border-radius: 25px;">
            </center>
            <div class="card-body">
                <div class="card-title"><b style="font-size: 20px;">Repair Service</b></div>
                <div class="card-text">
                    <p>Our services have provided two services is repair stringing service and repair 
                        grip service for customers.</p>
                </div>
            </div>
            <div class="card-footer">
                <p style="text-align: center;"><a href="ServiceRepair.php" class="btn btn-primary">Go</a></p>
            </div>
        </div>
    </div>
</div></div>
<br><br><br><br>
<?php
include ('include/footer.php');
?>