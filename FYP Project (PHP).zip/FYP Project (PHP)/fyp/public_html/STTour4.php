<?php
include('include/Sheader.php');
require ('mysqli_connect.php');

$search_query = "SELECT * FROM tournament WHERE TCategories = 'Child' AND TID = '4.1'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $TDate = $rows['TDate'];
                        $TCategories = $rows['TCategories'];
                        $TTime = $rows['TTime'];

                    }
                }
            }

$RegID = "";
$PlayerName = "";
$NoOfPlayer = "";
$RegDate = "";
$RegPrice = "";
$ContactNo = "";
$TID = "";
$Score = "";
$MID = "";

 function getData()
{
    $data = array();
    $data[0] = $_POST['RegID'];
    $data[1] = $_POST['PlayerName'];
//    $data[2] = $_POST['NoOfPlayers'];
    $data[3] = $_POST['RegDate'];
//    $data[4] = $_POST['RegPrice'];
    $data[5] = $_POST['ContactNo'];
    $data[6] = $_POST['TID'];
    $data[7] = $_POST['Score'];
    $data[8] = $_POST['MID'];
    
    return $data;
    
}

//search
if(isset($_POST['search']))
{
    $info = getData();
    $search_query = "SELECT * FROM registration WHERE TID = '$info[6]'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $RegID = $rows['RegID'];
                        $PlayerName = $rows['PlayerName'];
                        $NoOfPlayer = $rows['NoOfPlayers'];
                        $RegDate = $rows['RegDate'];
                        $RegPrice = $rows['RegPrice'];
                        $ContactNo = $rows['ContactNo'];
                        $TID = $rows['TID'];
                        $Score = $rows['Score'];
                        $MID = $rows['MID'];
                    }
                }else
                {
                
                    echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>No Data are Available</strong></div>";
                }
                
            } else{
                echo("result error");
            }
}

if(isset($_POST['insert'])){
    
    if(!empty($_POST['RegID'])){
       echo '<div class="alert" style="background-color: #FFBC97; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Must be Empty</strong><br> 
                                                 Dear, you need to remove it. ‘Reg ID’ <br></div>';
    }else{
        
        $PlayerName = $_POST['PlayerName'];
    $RegDate = $_POST['RegDate'];
    $ContactNo = $_POST['ContactNo'];
    $MID = $_POST['MID'];
    $Score = $_POST['Score'];
    if (!preg_match("/^[a-zA-Z-' ]*$/", $PlayerName)) {
            echo '<div class="alert">
                         <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                         <strong>Only letters and white space allowed !!!</strong> Please enter again !
                   </div>';
        }
        else{
//            $PlayerName = mysqli_real_escape_string($dbc, $PlayerName);
        
    if(!preg_match("/^[0-9]{10}$/", $ContactNo)) {
             echo '<div class="alert">
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                       <strong>Error for Contact No!!!</strong> Please enter again ! eg. 01XXXXXXXX
                    </div>';
         }
         else{
//            $ContactNo = mysqli_real_escape_string($dbc, $ContactNo);
         
    if(!(is_numeric($_POST['Score']))) {
             echo '<div class="alert">
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                       <strong>Error !!!</strong> Please enter again ! must key in number
                    </div>';
         }
         else{
//             $Score = mysqli_real_escape_string($dbc, $Score);
         
        
       

    
    if(isset( $_POST['TID'])){
        $TID = $_POST['TID'];
        
 $query = "SELECT * FROM `Registration` WHERE `TID` ='$TID'";
 $result = mysqli_query($dbc,$query); 

 if (mysqli_num_rows($result)) {
            echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>Tournament No '$TID' is already exists</strong></div>";
        } 
    }
        $stmt = mysqli_prepare($dbc, "SELECT RegID FROM registration ORDER BY RegID DESC LIMIT 1;");
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $i = 1;
        while ($r = mysqli_fetch_array($res)) {
            $o = preg_replace('/[^0-9]/', '', $r['RegID']); //php get only numbers from string
            $an = $o + $i;
            $id = str_pad($an, 6, "R0000", STR_PAD_LEFT); // combine int and string
        }
    
    
        $m = mysqli_connect('localhost', 'root', '', 'fyp');
        $stmt = mysqli_prepare($m, "INSERT INTO registration(RegID,PlayerName,NoOfPlayers,RegDate,RegPrice,ContactNo,TID,Score,MID)VALUES(?,?,'2',?,'20',?,?,?,?)");
        mysqli_stmt_bind_param($stmt, 'sssssis',$id, $PlayerName, $RegDate, $ContactNo, $TID, $Score, $MID);
        if (mysqli_stmt_execute($stmt)){
            echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Added !</strong> 
                             </div>';
        }
            
                    
        
        mysqli_stmt_close($stmt);
        mysqli_close($m);
        
    
         }
    }  
        }
    }
   
}


if(isset($_POST['delete'])){
    $info = getData();
    $delete_query = "DELETE FROM `registration` WHERE RegID = '$info[0]'";
    try{
        $delete_result = mysqli_query($dbc, $delete_query);
        if($delete_result){
            echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Data Deleted !</strong> 
                             </div>';
            
        }else{
            echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>Data Not Deleted</strong></div>";
            
        }
    } catch (Exception $ex) {
        echo("error in delete".$ex->getMessage());

    }
}

if(isset($_POST['update'])){
    $PlayerName = $_POST['PlayerName'];
    $RegDate = $_POST['RegDate'];
    $ContactNo = $_POST['ContactNo'];
    $MID = $_POST['MID'];
    $Score = $_POST['Score'];
    if (!preg_match("/^[a-zA-Z-' ]*$/", $PlayerName)) {
            echo '<div class="alert">
                         <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                         <strong>Only letters and white space allowed !!!</strong> Please enter again !
                   </div>';
        }
        else{
//            $PlayerName = mysqli_real_escape_string($dbc, $PlayerName);
        
    if(!preg_match("/^[0-9]{10}$/", $ContactNo)) {
             echo '<div class="alert">
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                       <strong>Error for Contact No!!!</strong> Please enter again ! eg. 01XXXXXXXX
                    </div>';
         }
         else{
//            $ContactNo = mysqli_real_escape_string($dbc, $ContactNo);
         
    if(!(is_numeric($_POST['Score']))) {
             echo '<div class="alert">
                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                       <strong>Error !!!</strong> Please enter again ! must key in number
                    </div>';
         }
         else{
//             $Score = mysqli_real_escape_string($dbc, $Score);
         
        
       

    
    if(isset( $_POST['TID'])){
        $TID = $_POST['TID'];
        
 $query = "SELECT * FROM `Registration` WHERE `TID` ='$TID'";
 $result = mysqli_query($dbc,$query); 

 if (mysqli_num_rows($result)) {
            echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>Tournament No '$TID' is already exists</strong></div>";
        } 
    }
    $info = getData();
    $update_query = "UPDATE `registration` SET `PlayerName`='$info[1]',`RegDate`='$info[3]',`ContactNo`='$info[5]',`TID`='$info[6]',`Score`='$info[7]', MID = '$info[8]' WHERE RegID = '$info[0]'";
    try{
        $update_result = mysqli_query($dbc,$update_query);
        if($update_result){
            if(mysqli_affected_rows($dbc)>0){
                echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Data Updated !</strong> 
                             </div>';
            }else{
                echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>Data Not Updated</strong></div>";
            }
        }
    } catch (Exception $ex) {
        echo("error in update".$ex -> getMessage());

    }
}
         }
        }
}

?>

    
    <div class="regform"><h2> Tournament Information</h2></div>
    <div class="main">
        
        <form id="myForm" action="STTour4.php" method="post">
             
            <div class="form-group">
                <br>
                <label class="Price">Tournament Date:</label>
                <label><?php echo $TDate; ?></label><br>
                <label class="Price">Tournament Time:</label>
                <label><?php echo $TTime; ?></label><br>
                <label class="Price">Categories:</label>
                <label><?php echo $TCategories; ?></label><br>
                
                <label class="Price">No of Player:</label>
                <label name="NoOfPlayers">2</label><br>
                <label class="Price">Register Price:</label>
                <label name="RegPrice" >20</label><br><br>
                
               <label class="label">Register ID:</label>
               <input type="text" name="RegID" value="<?php echo $RegID; ?>"><br>(when ADD no need to fill up 'RegID')<br><br>
                 
               <label class="firstlabel">Member ID:</label>
                <input class="MID" name="MID" value="<?php echo $MID; ?>"><br><br>
                
          <label for="TID">Tournament No:</label>

          <select class="TID" name="TID">
              <option value="<?php echo $TID; ?>"><?php echo $TID; ?></option>
              <option value="4.1">4.1</option>
              <option value="4.2">4.2</option>
              <option value="4.3">4.3</option>
              <option value="4.4">4.4</option>
              <option value="4.5">4.5</option>
              <option value="4.6">4.6</option>
              <option value="4.7">4.7</option>
              <option value="4.8">4.8</option>
              <option value="4.1.1">4.1.1</option>
              <option value="4.1.2">4.1.2</option>
              <option value="4.1.3">4.1.3</option>
              <option value="4.1.4">4.1.4</option>
              <option value="4.1.1.1">4.1.1.1</option>
              <option value="4.1.1.2">4.1.1.2</option>
             
              
            </select><br><br>

                <label class="firstlabel">Player Name:</label>
                <input type="text" name="PlayerName" placeholder="Please type name" value="<?php echo $PlayerName; ?>"><br><br>
                <label class="CN">Contact No:</label>
                <input  type="text" name="ContactNo" placeholder="eg. 01245569871" value="<?php echo $ContactNo; ?>"><br><br>
                <label class="Date">Register Date:</label>
                <input  type="date" name="RegDate" placeholder="yyyy-mm-dd" value="<?php echo $RegDate; ?>"><br><br>
                <label class="score">Score:</label>
                <input  type="text" name="Score" placeholder="1-100" value="<?php echo $Score; ?>"><br><br>
                
                <input type="submit" name="search" class="btn btn-info btn-md" value="Search">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" name="insert" class="btn btn-info btn-md" value="Add">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" name="update" class="btn btn-info btn-md" value="Update">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" name="delete" class="btn btn-info btn-md" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;
                <button onclick="myFunction()" value="Reset">Reset</button><br>
                
                
            </div>
            <a href='STourShow4.php' class="btn btn-info btn-md" value="Cancel">Cancel</a>
                
   
            </form>
        
        </div>
    
    <script>
function myFunction() {
    document.getElementById("myForm").reset();
}
    </script>
    
<section class="contact bg-transparent pt-5 text-center">
    <div class="container">
        <div class="row py-3">
            <div class="col-lg-7 mx-auto">

            </div>
        </div>
    </div>

<style>
        
body {
  background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
    background-attachment: fixed;
    background-size: 100% 100%;
    background-repeat: no-repeat;
    width: 100%; 
}  

        .regform{
            
            width: 500px;
            background-color: transparent;
            margin: auto;
            color: #ffffff;
            padding:10px 0px 10px 0px;
            text-align: center;
            
        }
        
        .main{
            
            background-color: #343a40;
            width: 500px;
            margin: auto;
            height: 900px;
            border-radius: 15px 15px 15px 15px;
            text-align: center;
            

        }
        
        
        #name{
            height:100px ;
            width: 100%;
            
        }
        
        .form-group{
            color: skyblue;
            font-family: inherit;
            font-size: 20px;
            
            
        }

        .contact{
            height: 120px;
            width: 100%;
            outline: none;
            border: none;
            color: gray;
            background-color: black;
            padding: 10px;
        }

 </style>
 </body>
 </html>