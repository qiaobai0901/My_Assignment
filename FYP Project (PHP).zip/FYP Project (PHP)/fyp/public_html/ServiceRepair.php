<?php // done but footer have problem
require ('mysqli_connect.php');
ob_end_clean();
include ('include/header.php');
?>
<style>
    body {
        background-image: url('pic/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg');
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: skyblue;
        font-weight: bolder;
        text-align: center;
    }
    /*---  For Serivce ---*/
    *{
        box-sizing: border-box;
    }
    /* Float four columns side by side */
    .col {
        float: left;
        width: 30%;
        padding: 0 10px;
        margin-right: 100px;
        margin-left: 100px;
        padding-top: 30px;
    }
    /* Remove extra left and right margins, due to padding in columns */
    .row {
        /* margin: 0 -5px;*/
        padding-left: 50px;
    }
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    /* Style the counter cards */
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
      padding: 16px;
      text-align: center;
      background-color: rgb(41, 82, 163, 0.8); /*rgb(?, ?, ?, opacity); */
      border-radius: 60px;
    }
    /* Responsive columns - one column layout (vertical) on small screens */
    @media screen and (max-width: 600px) {
      .column {
        width: 100%;
        display: block;
        margin-bottom: 20px;
      } 
    }
</style>
<br>
<h1>Repair Service</h1>
<h3>Choose your want to repair what thing</h3>
<div class="row">
    <?php
    $sql = "SELECT * FROM service";
    $stmt = mysqli_prepare($dbc, $sql);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
        $img = $row['ServiceImage'];
        $name = $row['ServiceName'];
        $type = $row['ServiceType'];
        $price = $row['ServicePrice'];
        $status = $row['ServiceStatus'];
    ?>
    <div class="col">
        <div class="card">
            <center>
                <img class="card-img-top" src="<?= $img ?>" alt="" 
                     style="width: 270px; height: 270px; padding: 5px; border-radius: 25px;">
            </center>
            <div class="card-body">
                <div class="card-title"><b style="font-size: 20px;"><?= $name ?></b></div>
                <div class="card-text">
                    <p>Price : RM <?= $price ?></p>
                    <p>Service Status : <?= $status ?></p>
                </div>
            </div>
            <div class="card-footer">
                <?php
                if ($type == 'Repair Grip'){
                    echo '<p style="text-align: center;">'
                    . '<a href="BookRGripService.php" class="btn btn-primary">Book</a>'
                            . '</p>';
                }
                 else {
                     if ($status == 'Not Available'){
                         echo '<p style="text-align: center;">'
                         . '<button class="btn btn-primary" style="background-color: #DC143C;">Not Available</button>'
                                 . '</p>';
                     }
                     else {
                         echo '<p style="text-align: center;">'
                         . '<a href="BookRStringingService.php" class="btn btn-primary">Book</a>'
                                 . '</p>';
                     }
                 }
                ?>
            </div>
        </div>
    </div>
    <?php
    }
    mysqli_close($dbc);
    ?>
</div>
<br><br><br><br><br><br>
<?php
include ('include/footer.php');
?>