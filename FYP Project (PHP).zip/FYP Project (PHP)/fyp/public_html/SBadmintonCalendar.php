<?php
include('include/Sheader.php');
function build_calendar($month,$year){
    
    $mysqli = new mysqli('localhost','root','','fyp');
    $stmt = $mysqli->prepare('SELECT * FROM booking WHERE MONTH(BookDate)=? AND YEAR(BookDate)=?');
    $stmt->bind_param('ss',$month,$year);
    $booking = array();
    if($stmt->execute()){
        $result = $stmt->get_result();
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $booking[] = $row['BookDate'];
                
            }
            $stmt->close();
            
        }
    }
    
    //first of all we'll create an array containing names of all days in a week
    $daysOfWeek = array('Sunday', 'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday');
    
   

    //Then we'll get the first day of the month that is in the argument of this function
    $firstDayOfMonth = mktime(0,0,0,$month,1,$year);
    
    //Now getting the number of days this month contains
    $numberDays = date('t',$firstDayOfMonth);
    
    //Getting some information about the first day of this month
    $dateComponents = getdate($firstDayOfMonth);
    
    //Getting the name of this month
    $monthName = $dateComponents['month'];
    
    //Getting the index value 0-6 of the first day of this month
    $dayOfWeek = $dateComponents['wday'];
    
    //Getting the current date
    $dateToday = date('Y-m-d');
    
    $prev_month = date('m',mktime(0,0,0,$month-1,1,$year));
    $prev_year = date('Y',mktime(0,0,0,$month-1,1,$year));
    $next_month = date('m',mktime(0,0,0,$month+1,1,$year));
    $next_year = date('Y',mktime(0,0,0,$month+1,1,$year));
    
    //Now creating the HTML table
    $calendar = "<table class='table table-bordered'>";
    $calendar.= "<center><h2>$monthName $year</h2></center>";
    $calendar.= "<center><a class='btn btn-xs btn-primary' style='background-color:skyblue;' href='?month=".$prev_month."&year=".$prev_year."'>Previous Month</a>";
    
    $calendar.= "<a class='btn btn-xs btn-primary'style='background-color:skyblue;' href='?month=".date('m')."&year=".date('Y')."'>Current Month</a>";
    
    $calendar.= "<a class='btn btn-xs btn-primary'  style='background-color:skyblue;' href='?month=".$next_month."&year=".$next_year."'>Next Month</a></center><br></center>";
    
    
    $calendar.= "<table class='table table-bordered'>";
    
    $calendar.= "<tr>";
    
    //Creating the calendar headers
    foreach($daysOfWeek as $day){
        $calendar.= "<th class='header'>$day</th>";
    }
         
   $calendar.="</tr><tr>"; 
   //Initiaing the day counter
   $currentDay = 1;
   //The variable $dayOfWeek will make sure that there must be only 7 columns on our table
   if($dayOfWeek > 0){
       for($k=0;$k<$dayOfWeek;$k++){
           $calendar.="<td></td>";
       }
   }
   
   //Getting the month number 
   
   $month = str_pad($month,2,"0",STR_PAD_LEFT);
   
   while($currentDay <= $numberDays){
       
       //if seventh column (saturday) reached, start a new row
       if($dayOfWeek == 7){
           $dayOfWeek = 0;
           $calendar.= "</tr><tr>";
       }
       
       $currentDayRel = str_pad($currentDay,2,"0",STR_PAD_LEFT);
       $date = "$year-$month-$currentDayRel";
       $dayName = strtolower(date('l',strtotime($date)));
       $today = $date==date('Y-m-d')? "today":"";
       if($date<date('Y-m-d')){
           $calendar.="<td><h4>$currentDay</h4> <button class='btn btn-danger btn-xs' style='  background-color: grey;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;'>N/A</button>";
//       }elseif(in_array($date, $booking)){
//           $calendar.="<td><h4>$currentDay</h4> <button class='btn btn-danger btn-xs'>Booked</button>";
       }else{
           $calendar.="<td class='$today'><h4>$currentDay</h4> <a style='background-color: skyblue;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;' href='SBBookingSlot.php?date=".$date."' class='btn btn-success btn-xs' onclick='passvalue();'>Book</a>";
       }

       $calendar.= "</td>";
       
       //Incrementing the counters
       $currentDay++;
       $dayOfWeek++;
          
   }
   
   //Completing the row of the last week in month, if necessary
   if($dayOfWeek != 7){
       $remainingDays = 7 - $dayOfWeek;
       for($l=0;$l<$remainingDays;$l++){
           $calendar.= "<td class='empty'></td>";
       }
   }
       
   $calendar.= "</tr>";
   $calendar.= "</table>";
   
   return $calendar;

    
}

?>


        <style>


body{
    background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
    background-attachment: fixed;
    background-size: 100% 100%;
    background-repeat: no-repeat;
    width: 100%; 
    color: skyblue;
        }
        

.table {
  margin: 0 auto;
  width: 700px;
  color: skyblue;
}
.empty {
    display: none;
}

/* Hide table headers (but not display: none;, for accessibility) */
th {
      white-space: nowrap;
  border:1px solid skyblue;
  text-align: right;
  color: skyblue;
}

tr {
    
    border: 1px solid #ccc;
}

td {
      white-space: nowrap;
  border:1px solid skyblue;
  text-align: right;
  color: skyblue;
}



/*
Label the data
*/
/*td:nth-of-type(1):before {
    content: "Sunday";
}
td:nth-of-type(2):before {
    content: "Monday";
}
td:nth-of-type(3):before {
    content: "Tuesday";
}
td:nth-of-type(4):before {
    content: "Wednesday";
}
td:nth-of-type(5):before {
    content: "Thursday";
}
td:nth-of-type(6):before {
    content: "Friday";
}
td:nth-of-type(7):before {
    content: "Saturday";
}*/

label{
    font-size: 20px;
}

/*a:link, a:visited {
  background-color: skyblue;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

a:hover, a:active {
  background-color: #007bff;
}*/

.box select {
  background-color: skyblue;
  color: white;
  padding: 10px;
  width: 100px;
  border: none;
  font-size: 16px;
  box-shadow: 0 5px 25px rgba(0, 0, 0, 0.2);

}

button{
  background-color: grey;
  color: white;
  padding: 14px 25px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

.today{
    background-color: whitesmoke;
}


        </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <?php
                    
                    $dateComponents = getdate();
                    if(isset($_GET['month'])&&isset($_GET['year'])){
                        $month = $_GET['month'];
                        $year = $_GET['year'];
                    }else{
                    $month = $dateComponents['mon'];
                    $year = $dateComponents['year'];
                    }
                    
                    
                    echo build_calendar($month,$year);
                    ?>
                </div>
            </div>
        </div>
        
        <!--<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>-->


   


