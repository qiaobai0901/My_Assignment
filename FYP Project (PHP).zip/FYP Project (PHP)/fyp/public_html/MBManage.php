<?php
include('include/Sheader.php');
require ('mysqli_connect.php');

$BookID = "";
$BookDate = "";
$BookStartTime = "";
$BookEndTime = "";
$MID = "";
$CourtID = "";


 function getData()
{
    $data = array();
    $data[0] = $_POST['BookID'];
    $data[1] = $_POST['BookDate'];
    $data[2] = $_POST['BookStartTime'];
    $data[3] = $_POST['BookEndTime'];
    $data[4] = $_POST['MID'];
    $data[5] = $_POST['CourtID'];

    
    return $data;
    
}

//search
if(isset($_POST['search']))
{
    $info = getData();
    $search_query = "SELECT * FROM booking WHERE MID = '$info[4]' AND CourtID = '$info[5]' AND BookDate = '$info[1]'";
    $search_result = mysqli_query($dbc, $search_query);
            if($search_result)
            {
                if(mysqli_num_rows($search_result))
                {
                    while($rows = mysqli_fetch_array($search_result))
                    {
                        $BookID = $rows['BookID'];
                        $BookDate = $rows['BookDate'];
                        $BookStartTime = $rows['BookStartTime'];
                        $BookEndTime = $rows['BookEndTime'];
                        $MID = $rows['MID'];
                        $CourtID = $rows['CourtID'];
                        
                    }
                }else
                {
                
                   echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>No Data</strong></div>";
                }
                
            } else{
                echo("result error");
            }
}

if(isset($_POST['insert'])){
    
    if(!empty($_POST['BookID'])){
       echo '<div class="alert" style="background-color: #FFBC97; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Must be Empty</strong><br> 
                                                 Dear, you need to remove it. ‘Book ID’ <br></div>';
    }else{
        if ($_POST['BookDate'] < date("Y-m-d")){
        echo '<div class="alert" style="background-color: orrange; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Date was Expired</strong><br> 
                                                 Dear, you need to choose available date<br></div>';
    
    }else{
        if ($_POST['BookStartTime'] >= $_POST['BookEndTime']){
            echo '<div class="alert" style="background-color: orrange; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Book time is incorrect</strong><br> 
                                                 Please try again<br></div>';
            
            
        }else{
            
        
   
        
        $BookDate = $_POST['BookDate'];

        $starttime = $_POST['BookStartTime'];
        $endtime = $_POST['BookEndTime'];
        $CourtID = $_POST['CourtID'];
        $MID = $_POST['MID'];
       
        $query = "SELECT * FROM `booking` WHERE CourtID = '$CourtID' AND `BookDate` ='$BookDate' AND BookStartTime = '$starttime' AND BookEndTime = '$endtime'";
        $result = mysqli_query($dbc, $query);

        $checkrows= mysqli_num_rows($result);
           
        if($checkrows>0) {
            
      echo '<div class="alert" style="background-color: orrange; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Already Existed</strong><br> 
                                                 Dear, you need to choose another court, date or time. <br>
                                                 
                                          </div>';
   } else { 
        
        $stmt = mysqli_prepare($dbc, "SELECT BookID FROM booking ORDER BY BookID DESC LIMIT 1;");
        mysqli_stmt_execute($stmt);
        $res = mysqli_stmt_get_result($stmt);
        $i = 1;
        while ($r = mysqli_fetch_array($res)) {
            $o = preg_replace('/[^0-9]/', '', $r['BookID']); //php get only numbers from string
            $an = $o + $i;
            $id = str_pad($an, 6, "B0000", STR_PAD_LEFT); // combine int and string
        }

        $m = mysqli_connect('localhost', 'root', '', 'fyp');
        $stmt = mysqli_prepare($m, "INSERT INTO booking(BookID, BookType, BookDate, BookStartTime, BookEndTime, "
                . "BookStatus, timeID,MID,CourtID)VALUES(?,'Badminton',?,?,?,'Booked','',?,?)");
        mysqli_stmt_bind_param($stmt, 'sssssi', $id, $BookDate, $starttime, $endtime, $MID, $CourtID);

        mysqli_stmt_execute($stmt);

        mysqli_stmt_close($stmt);
        mysqli_close($m);
  
echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Booking Successfull !!!</strong> 
                             </div>';
   
}
}
}

}
}

if(isset($_POST['delete'])){
    
    $info = getData();
    $delete_query = "DELETE FROM `booking` WHERE BookID = '$info[0]'";
    try{
        $delete_result = mysqli_query($dbc, $delete_query);
        if($delete_result){
            echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Data Deleted !</strong> 
                             </div>';
            
        }else{
            echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>Data Not Deleted</strong></div>";
            
        }
    } catch (Exception $ex) {
        echo("error in delete".$ex->getMessage());

    }
}

if(isset($_POST['update'])){
    $BookDate = $_POST['BookDate'];

        $starttime = $_POST['BookStartTime'];
        $endtime = $_POST['BookEndTime'];
        $CourtID = $_POST['CourtID'];
        $MID = $_POST['MID'];
   
        if ($_POST['BookStartTime'] >= $_POST['BookEndTime']){
            echo '<div class="alert" style="background-color: orrange; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Book time is incorrect</strong><br> 
                                                 Please try again<br></div>';
            
            
        }else{
            $query1 = "SELECT * FROM `booking` WHERE CourtID = '$CourtID' AND `BookDate` ='$BookDate' AND BookStartTime = '$starttime' AND BookEndTime = '$endtime'";
        $result1 = mysqli_query($dbc, $query1);

        $checkrows1= mysqli_num_rows($result1);
           
        if($checkrows1>0) {
            
      echo '<div class="alert" style="background-color: orrange; padding: 10px; color: white; 
                                               margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                               <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                               <strong>Already Existed</strong><br> 
                                                 Dear, you need to choose another court, date or time. <br>
                                                 
                                          </div>';
   } else { 
    $info = getData();
    $update_query = "UPDATE `booking` SET `BookDate`='$info[1]',`BookStartTime`='$info[2]',`BookEndTime`='$info[3]',`MID`='$info[4]',`CourtID`='$info[5]' WHERE BookID = '$info[0]'";
    try{
        $update_result = mysqli_query($dbc,$update_query);
        if($update_result){
            if(mysqli_affected_rows($dbc)>0){
                echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                                 <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                                 <strong>Data Updated !</strong> 
                             </div>';
            }else{
                echo "<div class='alert' style='background-color: #FFBC97; padding: 10px; color: white; 
                                 margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;'>
                                 <span class='closebtn' onclick='this.parentElement.style.display='none'';'>&times;</span> 
                                 <strong>Data Not Updated</strong></div>";
            }
        }
    } catch (Exception $ex) {
        echo("error in update".$ex -> getMessage());

    }
}
        }
}

?>

    <div class="regform"><h2> Booking Information</h2></div>
    <div class="main">
        
        <form class="form" action="MBManage.php" method="post">
            <div class="form-group">
                 <br>
                 <label class="s">Book ID :</label>
                    <input type="type" name="BookID" value="<?php echo $BookID; ?>"><br>
                    (when ADD no need to fill up 'BookID')
                    <br><br>
                    
                    <label for="">Member ID :</label>
                <input class="MID" name="MID" value="<?php echo $MID; ?>" required><br><br>
                <label class="Court">Court ID:</label>
                
                <select class="CourtID" name="CourtID" required>
                    <option value="<?php echo $CourtID;?>"><?php echo $CourtID;?></option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                </select><br><br>
                
                <div class="form-group">
                    <label class="stlabel">Book Date:</label>
                    <input type="date" name="BookDate" value="<?php echo $BookDate; ?>" required><br><br>
                </div>
                <label class="label">Start Time:</label>
                <input type="time" name="BookStartTime" value="<?php echo $BookStartTime; ?>" >&nbsp;&nbsp;&nbsp;
                <label class="label">End Time:</label>
                <input type="time" name="BookEndTime" value="<?php echo $BookEndTime; ?>" ><br><br>
            </div>
            <div class="form-group">
                
                
                
             
                <input type="submit" name="search" class="btn btn-info btn-md" value="Search">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" name="insert" class="btn btn-info btn-md" value="Add">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" name="update" class="btn btn-info btn-md" value="Update">&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" name="delete" class="btn btn-info btn-md" value="Delete">&nbsp;&nbsp;&nbsp;&nbsp;
                
                
                
            </div>
            <button onclick="myFunction()" value="Reset">Reset</button>&nbsp;&nbsp;&nbsp;&nbsp;
            <a href='SBadmintonCalendar.php' class="btn btn-info btn-md" value="Cancel">Cancel</a>
                
   
            </form>
                
          
        </div>
    
    <script>
function myFunction() {
    document.getElementById("myForm").reset();
}
    </script>
    
<section class="contact bg-transparent pt-5 text-center">
    <div class="container">
        <div class="row py-3">
            <div class="col-lg-7 mx-auto">

            </div>
        </div>
    </div>

<style>
        
body {
  background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
    background-attachment: fixed;
    background-size: 100% 100%;
    background-repeat: no-repeat;
    width: 100%; 
}  

        .regform{
            
            width: 500px;
            background-color: transparent;
            margin: auto;
            color: #ffffff;
            padding:10px 0px 10px 0px;
            text-align: center;
            
        }
        
        .main{
            
            background-color: #343a40;
            width: 500px;
            margin: auto;
            height: 600px;
            border-radius: 15px 15px 15px 15px;
            text-align: center;
            

        }
        
        
        #name{
            height:100px ;
            width: 100%;
            
        }
        
        .form-group{
            color: skyblue;
            font-family: inherit;
            font-size: 20px;
            
            
        }

        .contact{
            height: 120px;
            width: 100%;
            outline: none;
            border: none;
            color: gray;
            background-color: black;
            padding: 10px;
        }

 </style>
 </body>
 </html>