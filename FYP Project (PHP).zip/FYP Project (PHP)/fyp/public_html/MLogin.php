<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    //For processing the login
    require('function/MLogin_function.php');
    //define connection to your database
    require('mysqli_connect.php');
    ob_end_clean();
        $email = $_REQUEST['email'];
        $pass = $_REQUEST['pass'];
        
        list($check,$data)=check_login($dbc,$_REQUEST['email'],$_REQUEST['pass']);
        
        if($check){ //OK
//            echo"<br>OK!!!,email=,$email and pass=,$pass";
            if(!empty($data['MID'])){
                setcookie ('MID',$data['MID'],time()+3600,'/','',0,0);
                setcookie ('MName',$data['MName'],time()+3600,'/','',0,0);
                setcookie ('MGender',$data['MGender'],time()+3600,'/','',0,0);
                setcookie ('MBirthDate',$data['MBirthDate'],time()+3600,'/','',0,0);
                setcookie ('MPhoneNo',$data['MPhoneNo'],time()+3600,'/','',0,0);
                setcookie ('MAddress',$data['MAddress'],time()+3600,'/','',0,0);
                setcookie ('MEmailAddress',$data['MEmailAddress'],time()+3600,'/','',0,0);
                setcookie ('MUsername',$data['MUsername'],time()+3600,'/','',0,0);
                redirect_user("MLogged.php");
            }
            
        }
        else{//Unsuccessful
            $errors=$data;
        }

include('MLoginPage.php');
}// End if of $_SERVER['REQUEST_METHOD']
?>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>