<?php

include('include/header.php');

?>
      <section class="contact bg-img pt-5 text-center">
        <div class="container">
 
            <a class="button" href="MTourShow3.php">1 Player</a>
            
            
            <br><br><br><br><br><br><br><br><br>
       
            <a class="button" href="MTourShow4.php">2 Players</a>
        </div> 

       </section>

        
<style>
    body{
        background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
            background-attachment: fixed;
            background-size: 100% 100%;
            background-repeat: no-repeat;
            width: 100%;
       
    }
    
    .container{
        
        position: absolute;
        top: 40%;
        left: 50%;
        transform: translate(-50%,-50%);
        
    }
    
    .button{
        position: relative;
        text-align: center;
        width: 250px;
        padding: 40px;
        font-size: 35px;
        color: #15f4ee;
        font-family: poppins;
        font-weight:400;
        border: 5px solid #15f4ee;
        text-transform: uppercase;
        Letter-spacing: 15px;
        cursor: pointer;
        border-radius: 100px;
        margin: auto;
    }
    
    .button:hover{
        box-shadow: 0 5px 5px 0 #15f4ee inset, 0 5px 5px 0 #15f4ee,
                    0 5px 5px 0 #15f4ee inset, 0 5px 5px 0 #15f4ee;
        text-shadow: 0 0 5px #15f4ee, 0 0 5px #15f4ee;
    }
    
    .page-footer {
     position:absolute;
     bottom:0;
     width:100%;

}
    </style>

<?php

include('include/footer.php');

?>

