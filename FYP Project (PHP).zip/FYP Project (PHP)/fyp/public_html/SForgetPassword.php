<?php // this only send staff password to email
// Load Composer's autoloader
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// This only sends the member password to email
require ('mysqli_connect.php');

if (isset($_POST['submit'])) {
    $email = $_POST['email'];

    $result = mysqli_query($dbc, "SELECT * FROM staff WHERE SEmailAddress='$email'");
    
    if (mysqli_num_rows($result) > 0) { 
    // Check if the Query Returned Results: Before accessing the elements of $row, check if the result contains any rows using mysqli_num_rows($result) > 0. This ensures that the email address exists in the database.
    // Only Proceed if a Result is Found: Only if a result is found, fetch the row and proceed to send the email. If no results are found, display an error message indicating that the email address is not found.
        $row = mysqli_fetch_assoc($result);
        $fetch_SEmailAddress = $row['SEmailAddress'];
        $SPassword = $row['SPassword'];

        if ($email == $fetch_SEmailAddress) {
            $mail = new PHPMailer(true);
            
            try {
                // Server settings
                $mail->isSMTP();
                $mail->Host = 'sandbox.smtp.mailtrap.io'; // // Your Mailtrap HOST
                $mail->SMTPAuth = true;
                $mail->Username = '054a9050e5928a'; // Your Mailtrap username
                $mail->Password = '96e9150d02321c'; // Your Mailtrap password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port = 2525;

                // Recipients
                $mail->setFrom('xiiaolee901@gmail.com', 'Mailer');
                $mail->addAddress($email);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Receive Password';
                $mail->Body    = 'Your password is: ' . $SPassword;
                $mail->AltBody = 'Your password is: ' . $SPassword;

                $mail->send();
                echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                          <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>
                          <strong>Successful !!!</strong> Password already sent to your email account.
                          <br> Please check your email account.
                      </div>';
            } catch (Exception $e) {
                echo '<div class="alert">
                          <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>
                          <strong>Error !!!</strong> Message could not be sent. Mailer Error: ', $mail->ErrorInfo, '
                      </div>';
            } // end try
        }
    } else {
        echo '<div class="alert">
                  <span class="closebtn" onclick="this.parentElement.style.display=\'none\';">&times;</span>
                  <strong>Error !!!</strong> Please enter your email again!
              </div>';
    } // end if for if (mysqli_num_rows($result) > 0)
} // end if for if[isset($_POST['submit'])]

// First version
//require ('mysqli_connect.php');
//if(isset($_POST['submit'])){
//    $email = $_POST['email'];
//    
//    $result = mysqli_query($dbc, "SELECT * FROM staff WHERE SEmailAddress='$email'");
//    $row = mysqli_fetch_assoc($result);
//        $fetch_SEmailAddress = $row['SEmailAddress'];
//        $SPassword = $row['SPassword'];
//        if ($email == $fetch_SEmailAddress){
//            $to = $email;
//            $subject = "Receive Password";
//            $txt = "Your password is : ". $SPassword;
//            $headers = "From : xiiaolee901@gmail.com";
//            mail($to,$subject,$txt,$headers);
//            echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
//                margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
//                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
//                       <strong>Successful !!!</strong> Password already send to your email account. 
//                       <br> Please check your email account. 
//                   </div>';
//        }
//        else {
//            echo '<div class="alert">
//                       <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
//                       <strong>Error !!!</strong> Please enter your email again !
//                   </div>';
//        }
//}
?>
<style>
    label, input, button, h2, h3 {
        color: lightblue; 
        font-size: 16px; 
        font-family: comic sans ms;
    }
    button {
        border-radius: 12px; 
        padding: 5px 16px; 
        background-color: #004d99;
    }
    center, h3 {
        padding: 12px;
    }
    body{
        background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%; 
    }
    .page-footer {
       position:absolute;
       bottom:0;
       width:100%;
    }
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      /*<!-- Alert message--> */
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }

    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }

    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<center>
    <br><br><br><br><br><br>
    <h2>Forget Your Passwords ???</h2>
    <h3><p>Please enter your email address that you use to sign up to your account.</p></h3>
    <div class="container">
        <form action=" " method="POST">
        <b><label for="email" style="padding-right:20px;">Email Address: </label>
            <input type="text" name="email" style="color: black; border-radius: 10px;" 
                   placeholder="Enter ur email" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$" required></b>
            <!-- this button is when username submit their email. 
            If their email is correct and have in database, 
            then the system will send their password to their email -->
            <div style="padding-left: 225px; padding-top: 28px;">
                <button type="submit" name="submit">Submit</button>
            </div>
        </form>
    </div>
</center>