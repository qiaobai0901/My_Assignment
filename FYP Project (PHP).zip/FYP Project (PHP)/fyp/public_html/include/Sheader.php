<?php
ob_start();
session_start();
if (!isset($page_title)) {
$page_title = 'The Challenger Sport Centre';
}

?>
<html>
    
    <head> 
        <title> The Challenger Sports Centre</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
      
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
         <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


        <script src="https://kit.fontawesome.com/a076d05399.js"></script>

<!--        <script>
        $(document).ready(function () {
            $('.dropdown-toggle').dropdown();
        });
</script>-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
        <script src="https://code.jquery.com/ui/1.12.4/jquery-ui.js"></script>

        <!-- icon -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
  
    </head>
    


    <body>
      
      
        <header>
       <nav class="navbar navbar-expand-lg navbar-transparent bgimg">
            <a class="navbar-brand" style="color:#ccc; font-family:fantasy;" href="Shomepage.php">The Challenger Sports Centre</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarsExampleDefault">
    <ul class="navbar-nav mr-auto">

      <li class="nav-item dropdown">
       <a class="nav-link dropdown-toggle" style="color:grey;" href="#" id="navbarDropdown" onclick="myFunction()" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Maintenance
         </a>

        <div class="dropdown-menu" style="background-color:transparent" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" style="color:grey;" href="ManageStaffAccount.php"><i class="fas fa-users"></i>&nbsp;&nbsp;&nbsp; Manage Staff Account</a>
          <a class="dropdown-item" style="color:grey;" href="ManageUserAccountByStaff.php"><i class="fas fa-users"></i>&nbsp;&nbsp;&nbsp; Manage Member Account</a>
          <a class="dropdown-item" style="color:grey;" href="ManageRepairService.php"> <i class="fas fa-briefcase-medical"></i>&nbsp;&nbsp;&nbsp; Manage Repair Service</a>
          <a class="dropdown-item" style="color:grey;" href="ManageAccessories.php"><img src="pic/badminton.png" alt="accessories" class="avatar">&nbsp;&nbsp; Manage Accessories</a>
          <a class="dropdown-item" style="color:grey;" href="SBadmintonCalendar.php">Badminton Court</a>
          <a class="dropdown-item" style="color:grey;" href="STournament.php">Tournament</a>
          
        </div>
       </li>

             <li class="nav-item dropdown">
       <a class="nav-link dropdown-toggle" style="color:grey;" href="#" id="navbarDropdown" onclick="myFunction()" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Account
         </a>
        <div class="dropdown-menu" style="background-color:transparent" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" style="color:grey;" href="StaffProfile.php"><i class="bi bi-person-video2"></i>&nbsp;&nbsp;&nbsp;&nbsp; Staff Profile</a>
          <a class="dropdown-item" style="color:grey;" href="SLogout.php"><i class="fas fa-sign-out-alt"></i>&nbsp;&nbsp;&nbsp;&nbsp; log Out</a>

        </div>
       </li>

    </ul>
 
 
  

  </div>
         
</nav>
</header>
