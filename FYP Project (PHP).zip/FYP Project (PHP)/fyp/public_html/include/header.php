<?php
// Start output buffering
ob_start();

//check for a $page_title value
if (!isset($page_title)) {
$page_title = 'The Challenger Sport Centre';
}
?>
<!DOCTYPE html>

    <html>
    <head> 
        <title> The Challenger Sports Centre</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="st.css"/>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        
        <!--<script src="https://code.jquery.com/jquery-3.7.1.slim.min.js" integrity="sha256-kmHvs0B+OpCW5GVHUNjv9rOmY0IvSIRcf7zGUDTDQM8=" crossorigin="anonymous"></script>-->
        
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


        <script src="https://kit.fontawesome.com/a076d05399.js"></script>

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.5.0/font/bootstrap-icons.css"><!-- comment -->
        
<!--        <script>
            $(document).ready(function () {
                $('.dropdown-toggle').dropdown();
            });
    </script>-->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
<!--        <script src="https://code.jquery.com/jquery-1.12.4.js"></script>-->
        <script src="https://code.jquery.com/jquery-1.12.4.min.js" integrity="sha256-ZosEbRLbNQzLpnKIkEdrPv7lOy9C27hHQ+Xp8a4MxAQ=" crossorigin="anonymous"></script>
        <!--<script src="https://code.jquery.com/ui/1.12.4/jquery-ui.js"></script>-->
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30=" crossorigin="anonymous"></script>
  
    </head>

    <header>
    <nav class="navbar navbar-expand-lg navbar-transparent bg-img">
    <a class="navbar-brand" style="color:skyblue; font-family:fantasy;" href="homepage.php">The Challenger Sports Centre</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>
            
    <div class="collapse navbar-collapse" id="navbarsExampleDefault">
    <ul class="navbar-nav mr-auto">

      <li class="nav-item">
        <a class="nav-link" style="color:skyblue;" href="homepage.php">Home</a>
      </li>
       <li class="nav-item">
        <a class="nav-link" style="color:skyblue;" href="MBadmintonCalendar.php">Court Booking</a>
      </li>
        <li class="nav-item">
        <a class="nav-link" style="color:skyblue;" href="ServiceHomePage.php">Services</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" style="color:skyblue;" href="MTournament.php">Tournaments</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" style="color:skyblue;" href="AboutUs.php">About Us</a>
      </li>
      
      <li class="nav-item dropdown">
                           <a class="nav-link dropdown-toggle" style="color:skyblue;" href="#" id="navbarDropdown" 
                              onclick="myFunction()" role="button" data-toggle="dropdown" aria-haspopup="true" 
                              aria-expanded="false">Account</a>
                           <?php 
                          if (isset($_COOKIE['MID'])){
                             echo '<div class="dropdown-menu" style="background-color:transparent" aria-labelledby="navbarDropdown">
                                       <a class="dropdown-item" style="color:skyblue;" href="MemberProfile.php">
                                          <i class="bi bi-person-video2"></i>&nbsp;&nbsp;&nbsp; Profile
                                       </a>
                                       <a class="dropdown-item" style="color:skyblue;" href="Payment.php">
                                          <i class="bi bi-cart-fill"></i>&nbsp;&nbsp;&nbsp; My Cart
                                       </a>
                                       <a class="dropdown-item" style="color:skyblue;" href="MyReward.php">
                                          <i class="fas fa-award"></i>&nbsp;&nbsp;&nbsp; My Rewards
                                       </a>
                                       <a class="dropdown-item" style="color:skyblue;" href="MLogout.php">
                                          <i class="fas fa-sign-out-alt"></i>&nbsp;&nbsp;&nbsp; Log Out
                                       </a>
                                    </div>';
                          }
                          else { // user haven't login
                             echo '<div class="dropdown-menu" style="background-color:transparent" aria-labelledby="navbarDropdown">
                                       <a class="dropdown-item" style="color:skyblue;" href="SLoginPage.php">
                                          <i class="fas fa-sign-in-alt fa-9x" style="font-size: 16px;"></i>
                                          &nbsp;&nbsp;Staff Login
                                       </a>
                                       <a class="dropdown-item" style="color:skyblue;" href="MLoginPage.php">
                                       <i class="fas fa-sign-in-alt fa-9x" style="font-size: 16px;"></i>
                                          &nbsp;&nbsp;Member Login</a>
                                    </div>';
                          }
                          ?>
                       </li>
           
    </ul>
  
          <!--  for live chat icon  -->
<!--    <script type="text/javascript">
//    function openForm() {
//            document.getElementById("myForm").style.display = "block";
//        }
//
//        function closeForm() {
//            document.getElementById("myForm").style.display = "none";
//        }
//
//        function sendMessage(event) {
//            event.preventDefault();
//
//            const messageInput = document.getElementById("message");
//            const messageText = messageInput.value.trim();
//
//            if (messageText === "") {
//                return; // Do not send empty messages
//            }
//
//            const messageContainer = document.createElement("div");
//            messageContainer.className = "member-message";
//            messageContainer.innerText = messageText;
//
//            const chatMessages = document.getElementById("chatMessages");
//            chatMessages.appendChild(messageContainer);
//
//            // Clear the message input field
//            messageInput.value = "";
//
//            // Scroll to the bottom of the chat messages
//            chatMessages.scrollTop = chatMessages.scrollHeight;
//
//            // Send the message to the server using AJAX
//            const xhr = new XMLHttpRequest();
//            xhr.open("POST", "homepage.php", true);
//            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
//            xhr.onreadystatechange = function () {
//                if (xhr.readyState === 4 && xhr.status === 200) {
//                    console.log(xhr.responseText);
//                }
//            };
//            xhr.send("message=" + encodeURIComponent(messageText));
//        }
    </script> -->
   
    <!-- Other head content for live chat -->
<!--    <script src="refreshChat.js"></script>-->
         
</nav>
</header>
    <body><!-- comment -->
<style>
          
   .contact{
    height: 500px;
    width: 100%;
    outline: none;
    border: none;
    color: gray;
    background-color: black;
    padding: 10px;
}
</style>     