<style>    
    /* Footer styling */
    footer {
        color: skyblue;
        padding: 25px 0; /* Below footer that line blank */
        text-align: center;
    }

    footer .container {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
    }

    footer .container .explore,
    footer .container .follows {
        display: flex;
        flex-direction: column;
        align-items: center;
    }

    footer .container .explore a,
    footer .container .follows a {
        color: skyblue;
        text-decoration: none;
        margin: 5px 0;
    }

    .page-footer {
        bottom: 0;
        width: 100%;
        padding-bottom: 0;
    }
</style>           
    </body>
    <footer class="page-footer text-light bg-img mt-auto">
        <div class="container-fluid text-center text-md-left">
            <div class="row">
                <div class="col-md-4 mx-auto p-4">
                    <h5 class="text-uppercase" style="color:skyblue; font-family:fantasy;">The Challenger Sports Centre</h5>
                    <p style="color:skyblue;">Let you enjoy our badminton services</p>
                </div>
                <hr class="clearfix w-100 d-md-none pb-3">
                <div class="col-md-2 mx-auto p-3">
                    <h5 class="text-uppercase" style="color:skyblue;">Explore</h5>
                    <ul class="list-unstyled">
                        <li><a id="home" style="color:skyblue;" href="homepage.php">Home</a></li>
                        <li><a id="contactus" style="color:skyblue;" href="ContactUs.php">Contact Us</a></li>
                        <li><a id="aboutus" style="color:skyblue;" href="AboutUs.php">About Us</a></li>
                    </ul>
                </div>
                <div class="col-md-2 mx-auto p-3">
                    <h5 class="text-uppercase" style="color:skyblue;">Follow Us</h5>
                    <ul class="list-unstyled">
                        <li><a href="https://www.facebook.com/challengersportscentre/" style="color:skyblue;">Facebook</a></li>
                        <li><a href="https://twitter.com/intent/tweet?text=Welcome%20to%20The%20Challenger%20Sports%20Centre&url=http%3A%2F%2Fsite.thechallenger.com.my%2Fmain%2F3074%2Findex.asp%3Fpageid%3D78789%26AccId%3D8493%23.YN841nDZb5c.twitter&related=" style="color:skyblue;">Twitter</a></li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="footer-copyright text-center py-3" style="color:skyblue;">
            2021 Copyright:
            <a href="#" style="color:skyblue;">© The Challenger Sports Centre. All rights reserved</a>
        </div>
    </footer>
</html>
