<?php 
include('include/header.php');
?>
<div class="wrapper" style="background-color: black;">
                        
                        <div class="album py-5 ">
                        <h1 class="text-uppercase" style="color:skyblue; font-family:fantasy; text-align: center;">Contact Us</h1>
                        
                        <div class="container">
                        <div class="branch">
                            
                        <div class="row">  
                            
                                
                            <div class="branch_name" style="background: #343a40;">
                                <h4 style="color:skyblue;">G SPORT SDN BHD</h4>
                                <p class="role" style="color:skyblue;">Sg Long Branch</p>
                                <p style="color:skyblue;">Address:</p>
                                <p style="color:skyblue;">LOT 1716-2, Sungai Long, Batu 11, Cheras, 43000 Klang, Selangor Darul Ehsam, Malaysia</p>
                                <p style="color:skyblue;">Tel:</p>
                                <p style="color:skyblue;">03-8733 9969, 012-7873 394</p>
                                <p style="color:skyblue;">Email:</p>
                                <p style="color:skyblue;">chan@thechallenger.com.my</p>
                            </div>
                          
                        
                            <div class="branch_name" style="background: #343a40;">
                                <h4 style="color:skyblue;">BHANMIN SDN BHD</h4>
                                <p class="role" style="color:skyblue;">PJ Branch</p>
                                <p style="color:skyblue;">Address:</p>
                                <p style="color:skyblue;">118, Jalan Semangat,46200, Petaling Jaya,Selangor Darul Ehsan,Malaysia.</p>
                                <p style="color:skyblue;">Tel:</p>
                                <p style="color:skyblue;">03-7955 3311 , 03-7955 0033</p>
                                <p style="color:skyblue;">Email:</p>
                                <p style="color:skyblue;">heng@thechallenger.com.my</p>
                            </div>
                            
                             <div class="branch_name" style="background: #343a40;">
                                <h4 style="color:skyblue;">CHALLENGER SPORTS CENTRE SDN BHD</h4>
                                <p class="role" style="color:skyblue;">Kepong Branch</p>
                                <p style="color:skyblue;">Address:</p>
                                <p style="color:skyblue;">Lot 686, Jalan Kuang Bertam,(Jalan 24),Taman Kepong,52100,Kuala Lumpur,Malaysia.</p>
                                <p style="color:skyblue;">Tel:</p>
                                <p style="color:skyblue;">03-6272 7131 , 03-6272 7151</p>
                                <p style="color:skyblue;">Email:</p>
                                <p style="color:skyblue;">heng@thechallenger.com.my</p>
                            </div>
                        </div>
                       </div>   
                            <div class="branch">
                        <div class='row' style="display: flex;"> 
                             <div class="branch_name" style="background: #343a40;">
                                <h4 style="color:skyblue;">POWERINE SDN BHD</h4>
                                <p class="role" style="color:skyblue;">Ampang Branch</p>
                                <p style="color:skyblue;">Address:</p>
                                <p style="color:skyblue;">No.2 Challenger Sports Centre, Jalan Taman Putra, Taman Dagang Permai,68000, Ampang,Selangor.</p>
                                <p style="color:skyblue;">Tel:</p>
                                <p style="color:skyblue;">03-42881911</p>
                                <p style="color:skyblue;">Email:</p>
                                <p style="color:skyblue;">khekmong@thechallenger.com.my</p>
                            </div>
                            
                             <div class="branch_name" style="background: #343a40;">
                                <h4 style="color:skyblue;">THE CHALLENGER SPORTS CENTRE</h4>
                                <p class="role" style="color:skyblue;">Taman Cuepacs Branch</p>
                                <p style="color:skyblue;">Address:</p>
                                <p style="color:skyblue;">Lot 997, Jalan Koop Cuepacs 3F,Taman Cuepacs,43200,Selangor Darul Ehsan,Malaysia</p>
                                <p style="color:skyblue;">Tel:</p>
                                <p style="color:skyblue;">03-90762727, 03-90756999</p>
                                <p style="color:skyblue;">Email:</p>
                                <p style="color:skyblue;">heng@thechallenger.com.my</p>
                            </div>
                            

                            </div>
                        </div>
                        </div>
                        </div>
                </div>
        
               

<style>
          
            
.wrapper{
    margin-top:auto;
    
}


.branch{
    display: flex; 
    text-align: center; 
    width: auto; 
    justify-content: center;
    margin: auto;
}

.branch_name{
    background: #fff;
    margin:5px;
    margin-bottom: 30px;
    width: 300px;
    
}

.branch .branch_name h3{
    color: activecaption;
   
}

   .page-footer {
     
     bottom:0;
     width:100%;

}
</style>
<?php 
include('include/footer.php');
?>