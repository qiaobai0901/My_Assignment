<?php
$page_title = 'Manage Staff Account';
require('mysqli_connect.php');
ob_end_clean();
include('include/Sheader.php');
// delete staff account

if (isset($_POST['delete'])){
    $SID = $_POST['SID'];
    $delete = mysqli_prepare($dbc, "DELETE FROM staff WHERE SID='$SID'");
    mysqli_stmt_execute($delete);
    if (mysqli_affected_rows($dbc) == 1) { // If it ran OK
        echo '<div class="alert" style="background-color: #90EE90; padding: 10px; color: white; 
                margin-bottom: 15px; opacity: 1; transition: opacity 0.6s;">
                  <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                  <strong>Successful !!!</strong> Delete data from database successfully !
              </div>';
    }
    else{
        echo '<div class="alert">
                     <span class="closebtn" onclick="this.parentElement.style.display="none";">&times;</span> 
                     <strong>Unsuccessful !!!</strong> Please try again !
               </div>';
    }
} // end if for isset()
?>
<link rel="stylesheet" href="ManageStaffAccount.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<style>
    body{
        background-image: url(https://cdn1.epicgames.com/ue/item/Badminton_Screenshot_1-1920x1080-2cf8892509c158692884b8d9548cf005.png?resize=1&w=1600);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: white;
        font-weight: bolder;
    }

    table, th, td {
      border: 2px solid rgb(217, 179, 140, 0.2);
      border-collapse: collapse;
      background-color: rgb(0, 102, 204, 0.3);
    }
    table, th, td {
      border: 2px solid rgb(217, 179, 140, 0.2);
      border-collapse: collapse;
      background-color: rgb(0, 102, 204, 0.3);
    }
    th{
        padding-left: 30px;
        padding-right: 30px;
    }
    td{
        padding-left: 30px;
        padding-right: 30px;
    }
    .col {
        padding-left: 30px;
        padding-right: 30px;
    }
    i {
        padding-left: 5px;
        padding-right: 5px;
    }
    div {
        margin-left: 10px;
        margin-bottom: 20px;
    }
    a {
        color: white;
    }
    a:hover{
        color: #A2D2FF;
    }
    /* no style for button */
    button {
        background: transparent;
        box-shadow: 0px 0px 0px transparent;
        border: 0px solid transparent;
        text-shadow: 0px 0px 0px transparent;
        color: white;
    }
    button:hover {
        background: transparent;
        box-shadow: 0px 0px 0px transparent;
        border: 0px solid transparent;
        text-shadow: 0px 0px 0px transparent;
        color: #A2D2FF;
    }
    /* The alert message box */
    .alert {
      padding: 10px;
      background-color: #f25555; /* Red */
      color: white;
      margin-bottom: 15px;
      /*<!-- Alert message--> */
      opacity: 1;
      transition: opacity 0.6s; /* 600ms to fade out */
    }

    /* The close button */
    .closebtn {
      margin-left: 5px;
      color: white;
      font-weight: bold;
      float: right;
      font-size: 15px;
      line-height: 20px;
      cursor: pointer;
      transition: 0.3s;
    }

    /* When moving the mouse over the close button */
    .closebtn:hover {
      color: black;
    }
</style>
<script>
// Get all elements with class="closebtn"
var close = document.getElementsByClassName("closebtn");
var i;

// Loop through all close buttons
for (i = 0; i < close.length; i++) {
  // When someone clicks on a close button
  close[i].onclick = function(){

    // Get the parent of <span class="closebtn"> (<div class="alert">)
    var div = this.parentElement;

    // Set the opacity of div to 0 (transparent)
    div.style.opacity = "0";

    // Hide the div after 600ms (the same amount of milliseconds it takes to fade out)
    setTimeout(function(){ div.style.display = "none"; }, 600);
  }
}
</script>
<div class="col">
    <h1><b>Staff Account Management</b></h1>
    <h4>manage all the staffs</h4>

    <form action=" " method="POST">
        <table>
            <?php 
                    $q = "SELECT * FROM staff";
                    $stmt = mysqli_prepare($dbc, $q);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                ?>
            <thead>
                <tr>
                    <th scope="col">Staff ID</th>
                    <th scope="col" style="text-align: left;">Username</th>
                    <th scope="col" style="width: 26%; text-align: left;">Staff Name</th>
                    <th scope="col" style="width: 26%; text-align: left;">Email</th>
                    <th scope="col">Phone No.</th>
                    <th scope="col">Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    echo "<tr>"
                    . "<th scope=\"row\">{$row['SID']}</th>"
                    . "<td>{$row['SUsername']}</td>"
                    . "<td>{$row['SName']}</td>"
                    . "<td>{$row['SEmailAddress']}</td>"
                    . "<td>{$row['SPhoneNo']}</td>"
                    . "<td>
                         <a href=\"SSignUp.php\"><i class=\"bi bi-plus-circle\" aria-hidden=\"true\" ></i></a>
                         <a href=\"SEditDetail.php\"><i class=\"bi bi-pencil-square\"></i></a>
                         <button type=\"submit\" name=\"delete\"><i class=\"bi bi-x-circle\"></i></button>
                       </td>
                       <input type=\"hidden\" name=\"SID\" value=\"{$row['SID']}\">
                          </tr>"; 
                }
                mysqli_close($dbc);
                 ?>
            </tbody>
        </table>
    </form>
</div>