<?php //done
$page_title = 'Member Profile';
//include('include/header.php');
?>
<!--<link rel="stylesheet" href="MemberProfileCSS.css">-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
<style>
    body {
        background-image: url(https://cutewallpaper.org/21/badminton-wallpaper/Badminton-Wallpapers-Badminton-Wallpaper-Hd-Black-Hd-.jpg);
        background-attachment: fixed;
        background-size: 100% 100%;
        background-repeat: no-repeat;
        width: 100%;
        color: skyblue;
        font-weight: bolder;
        text-align: center;
    }
    img {
        border-radius: 500px;
        width: 160%;
        height: 160%;
        display: flex;
    }
    center {
        padding-top: 38px;
    }

    *{
        box-sizing: border-box;
    }
    /* Float two columns side by side */
    .col2 {
        float: left;
        width: 30%;
        padding-left: 50px;
        padding-top: 30px;
        display: flex;
    }
    .col3 {
        float: left;
        padding-left: 50px;
        padding-top: 30px;
    }
    /* Remove extra left and right margins, due to padding in columns */
    .row {
        /* margin: 0 -5px;*/
        padding-left: 50px;
    }
    /* Clear floats after the columns */
    .row:after {
      content: "";
      display: table;
      clear: both;
    }
    /* Style the counter cards */
    .card {
      box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2); /* this adds the "card" effect */
      padding: 16px;
      text-align: center;
      background-color: rgb(41, 82, 163, 0.8); /*rgb(?, ?, ?, opacity); */
      border-radius: 60px;
      width: 30%;
    }
    /* Style of card body */
    .card-body {
        padding-top: 38px;
        padding-bottom: 38px;
    }
    .form-group {
        padding-top: 16px;
        padding-bottom: 16px;
    }

    /* For icon space */
    i {
        padding-right: 16px;
    }

    /* Responsive columns - one column layout (vertical) on small screens */
    @media screen and (max-width: 600px) {
      .column {
        width: 100%;
        display: block;
        margin-bottom: 20px;
      }
    }
    a {
        padding: 10px 20px;
        border-radius: 30px;
    }
    a:link, a:visited {
        background-color: #3399ff;
        color: white;
        text-align: center;
        text-decoration: none;
        display: inline-block;
    }
    a:hover, a:active {
        background-color: #994d00;
    }

    
</style>
<center>
    <div class="col">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col2">
                        <img class="card-img-top" src="pic/userProfile.jpg" alt="User Profile Pic">
                    </div>
                    <div class="col3">
                        <?php
                          if(isset($_COOKIE['MID'])){
                              echo "<h2><b>{$_COOKIE['MUsername']}</b></h2>"
                                   . "<h4>{$_COOKIE['MEmailAddress']}</h4>";
                           }
                        ?>
                    </div>
                </div>
                <br><br>
                <div class="card-body">
                    <div class="form-group">
                        <a href="MAccountSettings.php" class="btn btn-primary"><i class='fas fa-user-cog'></i> Account Settings </a>
                    </div>
                    <div class="form-group">
                        <a href="MAccountSettings.php" class="btn btn-primary"><i class="fa fa-lock"></i> Change Password</a>
                    </div>
                    <div class="form-group">
                        <a href="MyReward.php" style="padding-left: 40px; padding-right: 40px;" class="btn btn-primary">
                            <i class="fas fa-award" style="font-size: 20px;"></i> 
                            My Rewards
                        </a>
                    </div>
                    <div class="form-group">
                        <a href="MLogout.php" style="padding-left: 55px; padding-right: 55px;" class="btn btn-primary"><i class="fas fa-sign-out-alt"></i> Logout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</center>
<?php

//
//include('include/footer.php');

?>